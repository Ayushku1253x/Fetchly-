package com.ayush.fetchly

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateMapOf

object Prefs {
    private lateinit var sp: SharedPreferences
    val state = mutableStateMapOf<String, String>()
    private var inited = false

    fun init(ctx: Context) {
        if (inited) return
        sp = ctx.applicationContext.getSharedPreferences("fetchly", Context.MODE_PRIVATE)
        for ((k, v) in sp.all) {
            if (v != null) state[k] = v.toString()
        }
        inited = true
    }

    fun str(key: String): String = state[key] ?: SETTINGS_BY_KEY[key]?.def ?: ""
    fun bool(key: String): Boolean = str(key) == "true"
    fun int(key: String, def: Int = 0): Int = str(key).toIntOrNull() ?: def
    fun set(key: String, value: String) {
        state[key] = value
        sp.edit().putString(key, value).apply()
    }
    fun setBool(key: String, v: Boolean) = set(key, v.toString())
    fun reset() {
        state.clear()
        sp.edit().clear().apply()
    }
}

enum class SType { TOGGLE, CHOICE, TEXT }

class SDef(
    val key: String,
    val title: String,
    val type: SType,
    val def: String,
    val section: String,
    val choices: List<String> = emptyList(),
    val desc: String = ""
)

private fun tg(key: String, title: String, def: Boolean, section: String, desc: String = "") =
    SDef(key, title, SType.TOGGLE, def.toString(), section, emptyList(), desc)

private fun ch(key: String, title: String, def: String, choices: List<String>, section: String, desc: String = "") =
    SDef(key, title, SType.CHOICE, def, section, choices, desc)

private fun tx(key: String, title: String, def: String, section: String, desc: String = "") =
    SDef(key, title, SType.TEXT, def, section, emptyList(), desc)

val ACCENT_NAMES = listOf("Blue", "Indigo", "Purple", "Pink", "Red", "Orange", "Green", "Teal")

val SETTINGS: List<SDef> = listOf(
    // ---------------- Appearance ----------------
    ch("theme_mode", "Theme", "Auto", listOf("Auto", "Light", "Dark"), "Appearance"),
    ch("accent", "Accent colour", "Blue", ACCENT_NAMES, "Appearance"),
    ch("glass_strength", "Glass thickness", "Thick", listOf("Light", "Medium", "Thick", "Extra thick"), "Appearance"),
    ch("corner_style", "Corner style", "Rounder", listOf("Round", "Rounder", "Pill"), "Appearance"),
    tg("bg_blobs", "Colour blobs in background", true, "Appearance"),
    ch("blob_intensity", "Blob intensity", "Normal", listOf("Soft", "Normal", "Vivid"), "Appearance"),
    ch("ui_scale", "Text and UI size", "Default", listOf("Small", "Default", "Large", "Extra large"), "Appearance"),
    tg("animations", "Animations", true, "Appearance"),
    tg("haptics", "Haptic feedback", true, "Appearance"),
    ch("show_intro", "Welcome intro", "First 2 launches", listOf("First 2 launches", "Always", "Never"), "Appearance"),
    tg("tab_labels", "Show tab labels", true, "Appearance"),
    tg("compact_mode", "Compact mode", false, "Appearance", "Smaller spacing"),
    tg("keep_screen_on", "Keep screen on while app is open", false, "Appearance"),
    tg("fetch_thumbs", "Show thumbnails in previews", true, "Appearance"),
    tg("clipboard_detect", "Detect copied links", true, "Appearance"),
    tg("show_mini_bar", "Show download mini-bar", true, "Appearance"),

    // ---------------- Downloads ----------------
    ch("save_mode", "Save location", "Auto (Movies, Music, Pictures)", listOf("Auto (Movies, Music, Pictures)", "Downloads/Fetchly", "Custom folder"), "Downloads"),
    tg("platform_subfolders", "Sub-folder per platform", true, "Downloads", "YouTube, Instagram, Web"),
    ch("filename_template", "File name", "Title", listOf("Title", "Title + ID", "Uploader - Title", "Date - Title", "ID only"), "Downloads"),
    tg("restrict_filenames", "Simple file names (ASCII only)", false, "Downloads"),
    ch("max_concurrent", "Downloads at the same time", "2", listOf("1", "2", "3", "4", "5"), "Downloads"),
    ch("fragments", "Parallel connections per download", "8", listOf("1", "2", "4", "8", "16", "32"), "Downloads"),
    ch("speed_limit", "Speed limit", "Unlimited", listOf("Unlimited", "500K", "1M", "2M", "5M", "10M", "20M"), "Downloads"),
    ch("retries", "Retries", "10", listOf("3", "5", "10", "20", "50"), "Downloads"),
    tg("auto_repair", "Auto-repair failed downloads", true, "Downloads", "Retries with other methods"),
    ch("repair_attempts", "Auto-repair attempts", "4", listOf("1", "2", "3", "4", "5"), "Downloads"),
    tg("auto_update_engine", "Auto-update download engine", true, "Downloads"),
    ch("update_channel", "Engine update channel", "Stable", listOf("Stable", "Nightly"), "Downloads"),
    tg("wifi_only", "Wi-Fi only", false, "Downloads"),
    tg("auto_start", "Start downloads immediately", true, "Downloads"),
    ch("overwrite", "If file exists", "Rename", listOf("Rename", "Skip existing", "Overwrite"), "Downloads"),
    tg("single_video", "Single video only (ignore playlist)", true, "Downloads"),
    tx("playlist_items", "Playlist items (example 1-5)", "", "Downloads"),
    ch("max_filesize", "Maximum file size", "None", listOf("None", "50M", "100M", "500M", "1G", "2G"), "Downloads"),
    tg("write_info_json", "Save info file (.json)", false, "Downloads"),
    tg("write_description", "Save description file", false, "Downloads"),
    tg("write_thumb_file", "Save thumbnail as separate file", false, "Downloads"),
    ch("sleep_interval", "Pause between downloads (sec)", "None", listOf("None", "1", "2", "5", "10"), "Downloads"),
    tg("use_archive", "Skip already downloaded videos", false, "Downloads"),
    tg("set_mtime", "Use upload date as file date", false, "Downloads"),
    tg("open_when_done", "Open file when finished", false, "Downloads"),
    tg("delete_partial", "Delete temporary files on failure", true, "Downloads"),
    tg("save_history", "Save download history", true, "Downloads"),

    // ---------------- Video ----------------
    ch("video_quality", "Default video quality", "Best", listOf("Best", "8K", "4K", "1440p", "1080p", "720p", "480p", "360p", "240p", "144p"), "Video"),
    ch("video_container", "Video format", "MP4", listOf("MP4", "MKV", "WEBM", "Original"), "Video"),
    ch("prefer_codec", "Preferred codec", "Any", listOf("Any", "H.264 (compatible)", "VP9", "AV1", "HEVC"), "Video"),
    ch("prefer_fps", "Frame rate", "Any", listOf("Any", "Max 30fps"), "Video"),
    ch("hdr", "HDR", "Allow", listOf("Allow", "Avoid"), "Video"),
    tg("embed_thumb_video", "Embed thumbnail in video", true, "Video"),
    tg("embed_metadata", "Embed title and info", true, "Video"),
    tg("embed_chapters", "Embed chapters", true, "Video"),
    tg("subtitles", "Download subtitles", false, "Video"),
    tx("sub_langs", "Subtitle languages (example en,hi)", "en,hi", "Video"),
    ch("sub_format", "Subtitle format", "srt", listOf("srt", "vtt", "ass", "best"), "Video"),
    tg("embed_subs", "Embed subtitles in video", false, "Video"),
    tg("auto_subs", "Include auto-generated subtitles", false, "Video"),
    tg("sponsorblock", "Remove sponsor segments (YouTube)", false, "Video"),
    ch("sb_categories", "Segments to remove", "Sponsor only", listOf("Sponsor only", "Sponsor + Self-promo", "All categories"), "Video"),
    tg("sb_mark", "Mark segments as chapters instead", false, "Video"),
    tg("split_chapters", "Split video by chapters", false, "Video"),
    tg("force_keyframes", "Accurate trimming (slower)", true, "Video"),

    // ---------------- Audio ----------------
    ch("audio_format", "Default audio format", "MP3", listOf("MP3", "M4A", "OPUS", "FLAC", "WAV", "AAC", "OGG", "Original"), "Audio"),
    ch("audio_quality", "Audio quality", "Best", listOf("Best", "320K", "256K", "192K", "128K", "96K", "64K"), "Audio"),
    tg("audio_embed_thumb", "Embed cover art (thumbnail)", true, "Audio", "Shows the source thumbnail in your music player"),
    tg("audio_embed_meta", "Embed title and artist", true, "Audio"),
    ch("audio_source", "Audio source", "Best", listOf("Best", "M4A source", "Opus source"), "Audio"),

    // ---------------- Network ----------------
    tx("proxy", "Proxy (optional)", "", "Network"),
    tg("force_ipv4", "Force IPv4", false, "Network"),
    tg("geo_bypass", "Bypass geo restriction", true, "Network"),
    tx("geo_country", "Fake country code (example IN)", "", "Network"),
    ch("user_agent", "Browser identity", "Default", listOf("Default", "Chrome Desktop", "Chrome Android", "Safari iPhone"), "Network"),
    ch("yt_client", "YouTube client", "Auto", listOf("Auto", "android", "ios", "web", "mweb", "tv"), "Network"),
    ch("socket_timeout", "Timeout (sec)", "30", listOf("10", "20", "30", "60", "120"), "Network"),
    tg("no_check_cert", "Skip certificate check", false, "Network"),
    tg("use_cookies", "Use logged-in cookies", true, "Network"),
    ch("chunk_size", "Download chunk size", "Default", listOf("Default", "5M", "10M", "25M"), "Network"),
    ch("extractor_retries", "Page fetch retries", "3", listOf("1", "3", "5", "10"), "Network"),

    // ---------------- Notifications ----------------
    tg("notify_enabled", "Notifications", true, "Notifications"),
    tg("notify_progress", "Show progress", true, "Notifications"),
    tg("notify_done", "Notify when finished", true, "Notifications"),
    tg("notify_error", "Notify on failure", true, "Notifications"),
    tg("notify_sound", "Sound", false, "Notifications"),
    tg("notify_vibrate", "Vibrate", false, "Notifications"),

    // ---------------- Privacy ----------------
    tg("incognito", "Incognito (no history)", false, "Privacy"),
    tg("secure_window", "Hide app in recent apps and screenshots", false, "Privacy"),
    tg("auto_clear_cache", "Clear cache on start", false, "Privacy"),
    tg("clear_history_exit", "Clear history on start", false, "Privacy"),
    tg("hide_thumbs_history", "Hide thumbnails in history", false, "Privacy"),

    // ---------------- Instagram ----------------
    tg("ig_original", "Always original quality", true, "Instagram", "No limits, no re-encoding"),
    tg("ig_dp_hd", "Profile photo in highest size", true, "Instagram"),
    tg("ig_caption", "Save caption as text file", false, "Instagram"),
    tg("ig_story_all", "Download all stories of a user", true, "Instagram"),
    tg("ig_audio_reel", "Reels as audio by default", false, "Instagram"),
    tg("ig_carousel_all", "All items of a multi-photo post", true, "Instagram"),

    // ---------------- YouTube ----------------
    ch("yt_default_mode", "Default mode", "Video", listOf("Video", "Audio"), "YouTube"),
    tg("yt_auto_thumb", "Also save thumbnail with every download", false, "YouTube"),
    tg("yt_trim_default", "Trimming on by default", false, "YouTube"),
    ch("yt_thumb_choice", "Thumbnail size", "Largest", listOf("Largest", "1280", "640", "320"), "YouTube"),
    tg("yt_copy_toast", "Show message after copying", true, "YouTube"),

    // ---------------- Website ----------------
    ch("web_min_size", "Minimum image size", "Any", listOf("Any", "100 KB", "300 KB", "1 MB"), "Website"),
    tg("web_images", "Find images", true, "Website"),
    tg("web_videos", "Find videos", true, "Website"),
    tg("web_audio", "Find audio", true, "Website"),
    tg("web_srcset", "Pick the largest image version", true, "Website"),
    tg("web_og", "Include social preview media", true, "Website"),
    ch("web_ua", "Website browser identity", "Chrome Desktop", listOf("Chrome Desktop", "Chrome Android", "Safari iPhone"), "Website"),
    tg("web_referer", "Send referer", true, "Website")
)

val SETTINGS_BY_KEY: Map<String, SDef> = SETTINGS.associateBy { it.key }
val SECTIONS: List<String> = SETTINGS.map { it.section }.distinct()
