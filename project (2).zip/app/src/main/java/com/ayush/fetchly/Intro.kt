package com.ayush.fetchly

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun IntroFlow(onDone: () -> Unit) {
    var page by remember { mutableIntStateOf(0) }
    val prog by animateFloatAsState(
        if (page >= 1) 1f else 0f, tween(1100, easing = CubicBezierEasing(0.7f, 0f, 0.2f, 1f)), label = "p"
    )
    val out by animateFloatAsState(
        if (page >= 2) 1f else 0f, tween(450), label = "o",
        finishedListener = { if (it >= 1f) onDone() }
    )
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val h = constraints.maxHeight.toFloat()
        Box(Modifier.fillMaxSize().graphicsLayer { translationY = -prog * h }) {
            Page1 { if (page == 0) page = 1 }
        }
        Box(Modifier.fillMaxSize().graphicsLayer { translationY = (1f - prog) * h; alpha = 1f - out }) {
            Page2(page >= 1) { if (page == 1) page = 2 }
        }
    }
}

@Composable
fun SwipeHint(modifier: Modifier, color: Color) {
    val inf = rememberInfiniteTransition(label = "sw")
    val dy by inf.animateFloat(4f, -6f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "dy")
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Image(Icons.Default.KeyboardArrowUp, null, Modifier.size(28.dp).offset(y = dy.dp), colorFilter = ColorFilter.tint(color))
        BasicText("Swipe up", style = TextStyle(color = color.copy(alpha = 0.85f), fontSize = 12.sp, fontFamily = Fonts.ui))
    }
}

@Composable
fun Page1(onNext: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xFF59607A))
            .drawBehind {
                val w = size.width
                val h = size.height
                fun blob(c: Color, cx: Float, cy: Float, r: Float) {
                    drawCircle(
                        brush = Brush.radialGradient(listOf(c.copy(alpha = 0.95f), Color.Transparent), center = Offset(cx * w, cy * h), radius = r * w),
                        radius = r * w, center = Offset(cx * w, cy * h)
                    )
                }
                blob(Color(0xFFFFB000), 0.15f, 0.06f, 0.65f)
                blob(Color(0xFF5F7898), 0.95f, 0.2f, 0.7f)
                blob(Color(0xFF454B66), 0.1f, 0.38f, 0.65f)
                blob(Color(0xFFCFC9DC), 0.65f, 0.62f, 0.6f)
                blob(Color(0xFFFF2D3D), 0.15f, 0.97f, 0.75f)
                blob(Color(0xFF7FB0C0), 0.98f, 0.82f, 0.5f)
            }
            .pointerInput(Unit) { detectTapGestures(onTap = { onNext() }) }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -60f) onNext() },
                    onDragCancel = {},
                    onVerticalDrag = { _, dy -> total += dy }
                )
            }
    ) {
        HelloLoop()
        SwipeHint(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 28.dp), Color.White)
    }
}

@Composable
fun HelloLoop() {
    var idx by remember { mutableIntStateOf(0) }
    var prev by remember { mutableIntStateOf(-1) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(2600)
            prev = idx
            idx = (idx + 1) % GREETINGS.size
        }
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        if (prev >= 0) {
            key("out$prev") { HelloWord(GREETINGS[prev], true) }
        }
        key("in$idx") { HelloWord(GREETINGS[idx], false) }
    }
}

@Composable
fun HelloWord(g: Greeting, leaving: Boolean) {
    val wipe = remember { Animatable(if (leaving) 1f else 0f) }
    val aA = remember { Animatable(if (leaving) 1f else 0f) }
    val bB = remember { Animatable(if (leaving) 0f else 16f) }
    val sS = remember { Animatable(if (leaving) 1f else 0.97f) }
    LaunchedEffect(Unit) {
        if (leaving) {
            launch { aA.animateTo(0f, tween(1000)) }
            launch { bB.animateTo(22f, tween(1000)) }
            launch { sS.animateTo(1.06f, tween(1200)) }
        } else {
            launch { wipe.animateTo(1f, tween(1900, easing = CubicBezierEasing(0.45f, 0.05f, 0.3f, 1f))) }
            launch { aA.animateTo(1f, tween(400)) }
            launch { bB.animateTo(0f, tween(700)) }
            launch { sS.animateTo(1f, tween(1200)) }
        }
    }
    val skel = Fonts.skeletal
    // Skeletal font covers most scripts. For the ones it lacks, use a similar handwriting-style font.
    val fam: FontFamily? = when (g.script) {
        "bn" -> Fonts.galada
        "ar" -> Fonts.lateef
        "he" -> Fonts.amatic
        "plain" -> null
        else -> skel ?: when (g.script) {
            "latin" -> Fonts.borel
            "deva" -> Fonts.kalamBold ?: Fonts.kalam
            else -> null
        }
    }
    val weight = when {
        g.script == "plain" -> FontWeight.SemiBold
        g.script in listOf("bn", "ar", "he") -> FontWeight.Normal
        skel != null -> FontWeight.Normal
        g.script == "other" -> FontWeight.SemiBold
        else -> FontWeight.Bold
    }
    val blurMod = if (bB.value > 0.6f) Modifier.blur(bB.value.dp) else Modifier
    BasicText(
        g.text,
        modifier = Modifier.fillMaxWidth()
            .graphicsLayer { alpha = aA.value; scaleX = sS.value; scaleY = sS.value }
            .then(blurMod)
            .featherMask(wipe.value),
        style = TextStyle(
            color = Color.White, fontSize = 50.sp, fontFamily = fam, fontWeight = weight, textAlign = TextAlign.Center,
            shadow = Shadow(Color(0x26000000), Offset(0f, 2f), 14f)
        ),
        maxLines = 1, softWrap = false
    )
}

@Composable
fun Page2(started: Boolean, onNext: () -> Unit) {
    val pal = LocalPal.current
    val tile = remember { Animatable(0f) }
    val drop = remember { Animatable(0f) }
    val gloss = remember { Animatable(0f) }
    val arrow = remember { Animatable(0f) }
    val name = remember { Animatable(0f) }
    val hello = remember { Animatable(0f) }
    val desc = remember { Animatable(0f) }
    val foot = remember { Animatable(0f) }
    LaunchedEffect(started) {
        if (!started) return@LaunchedEffect
        launch { delay(500); tile.animateTo(1f, tween(600)) }
        launch { delay(1100); drop.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 120f)) }
        launch { delay(2100); gloss.animateTo(1f, tween(800)) }
        launch { delay(2500); arrow.animateTo(1f, tween(900)) }
        launch { delay(3400); name.animateTo(1f, tween(1100)) }
        launch { delay(4200); hello.animateTo(1f, tween(600)) }
        launch { delay(4600); desc.animateTo(1f, tween(600)) }
        launch { delay(5000); foot.animateTo(1f, tween(600)) }
    }
    val inf = rememberInfiniteTransition(label = "logo")
    val morph by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2500, easing = LinearEasing), RepeatMode.Reverse), label = "m")
    val bob by inf.animateFloat(-2f, 3f, infiniteRepeatable(tween(1000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    val titleFont: FontFamily? = Fonts.pacifico ?: Fonts.borel
    val helloFont: FontFamily? = Fonts.skeletal ?: Fonts.borel

    AppBackground(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.weight(1f))
            Canvas(Modifier.size(132.dp)) {
                // always the default icon (1st one), original animation
                drawLogo(
                    0, tile = tile.value, blobY = -80f * (1f - drop.value),
                    blobA = (drop.value * 4f).coerceIn(0f, 1f), gloss = gloss.value, arrow = arrow.value,
                    morph = if (arrow.value > 0.99f) morph else 0f, arrowDy = if (arrow.value > 0.99f) bob else 0f
                )
            }
            Spacer(Modifier.height(26.dp))
            T(
                "Fetchly", 46f, pal.text, FontWeight.Normal, titleFont, TextAlign.Center, 1,
                Modifier.fillMaxWidth()
                    .graphicsLayer { translationY = (1f - name.value) * 14f }
                    .featherMask(name.value)
            )
            Spacer(Modifier.height(10.dp))
            T(
                "Hello", 26f, pal.text, FontWeight.Normal, helloFont, TextAlign.Center, 1,
                Modifier.fillMaxWidth().graphicsLayer { alpha = hello.value; translationY = (1f - hello.value) * 18f }
            )
            Spacer(Modifier.height(16.dp))
            T(
                "Save videos, music and photos from YouTube, Instagram and the web, in original quality.",
                14f, pal.sub, FontWeight.Normal, null, TextAlign.Center, 3,
                Modifier.widthIn(max = 300.dp).graphicsLayer { alpha = desc.value; translationY = (1f - desc.value) * 18f }
            )
            Spacer(Modifier.weight(1.1f))
            Column(
                Modifier.fillMaxWidth().graphicsLayer { alpha = foot.value; translationY = (1f - foot.value) * 24f },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                PrimaryButton("Get started", Modifier.fillMaxWidth()) { onNext() }
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T("Made in India ", 11f, pal.sub)
                    T("\u2665", 11f, Color(0xFFE5566D))
                    T("  \u00B7  Designed by Ayush", 11f, pal.sub)
                }
            }
            Spacer(Modifier.height(22.dp))
        }
    }
}
