package com.ayush.fetchly

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import coil.compose.AsyncImage
import java.io.File

object SettingsState {
    var sub by mutableStateOf("")
    var choiceKey by mutableStateOf("")
    var showIcons by mutableStateOf(false)
    var customBmp by mutableStateOf<Bitmap?>(null)
    var open by mutableStateOf(setOf<String>())
}

object IconManager {
    fun apply(ctx: Context, idx: Int) {
        val pm = ctx.packageManager
        val target = ComponentName(ctx.packageName, "com.ayush.fetchly.Alias" + (idx + 1))
        pm.setComponentEnabledSetting(target, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
        for (i in 1..20) {
            if (i == idx + 1) continue
            val cn = ComponentName(ctx.packageName, "com.ayush.fetchly.Alias$i")
            pm.setComponentEnabledSetting(cn, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
        }
        Prefs.set("icon_idx", idx.toString())
    }

    fun pinCustom(ctx: Context, bmp: Bitmap, label: String): Boolean {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) return false
        val i = Intent(ctx, MainActivity::class.java).setAction(Intent.ACTION_MAIN)
        val info = ShortcutInfoCompat.Builder(ctx, "custom_" + System.currentTimeMillis())
            .setShortLabel(label.ifBlank { "Fetchly" })
            .setIcon(IconCompat.createWithBitmap(bmp))
            .setIntent(i)
            .build()
        return ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
    }
}

fun toastMain(ctx: Context, msg: String) {
    Handler(Looper.getMainLooper()).post { Util.toast(ctx, msg) }
}

@Composable
fun ActionRow(title: String, sub: String = "", onClick: () -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().tap(onClick).padding(vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            T(title, 14f)
            if (sub.isNotEmpty()) T(sub, 12f, p.sub)
        }
        T("\u203A", 20f, p.sub)
    }
}

@Composable
fun SettingRow(d: SDef) {
    val p = LocalPal.current
    when (d.type) {
        SType.TOGGLE -> PrefToggle(d.title, d.key, d.desc)
        SType.CHOICE -> Row(Modifier.fillMaxWidth().tap { SettingsState.choiceKey = d.key }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T(d.title, 14f)
                if (d.desc.isNotEmpty()) T(d.desc, 12f, p.sub)
            }
            Spacer(Modifier.width(8.dp))
            T(Prefs.str(d.key), 13f, p.accent, FontWeight.Medium, maxLines = 1)
        }
        SType.TEXT -> Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            T(d.title, 14f)
            Spacer(Modifier.height(6.dp))
            Field(Prefs.str(d.key), { Prefs.set(d.key, it) }, "Not set")
        }
    }
}

@Composable
fun ChoiceDialog(d: SDef, onClose: () -> Unit) {
    val p = LocalPal.current
    Dialog(onDismissRequest = onClose) {
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(p.solid).padding(16.dp)) {
            T(d.title, 17f, weight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(d.choices) { c ->
                    val on = Prefs.str(d.key) == c
                    Row(Modifier.fillMaxWidth().tap { Prefs.set(d.key, c); onClose() }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        T(c, 15f, if (on) p.accent else p.text, if (on) FontWeight.Medium else FontWeight.Normal, modifier = Modifier.weight(1f))
                        if (on) T("\u2713", 16f, p.accent)
                    }
                }
            }
        }
    }
}

@Composable
fun IconDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPal.current
    val cur = Prefs.int("icon_idx", 0)
    var label by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val raw = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (raw != null) {
                    val side = minOf(raw.width, raw.height)
                    val sq = Bitmap.createBitmap(raw, (raw.width - side) / 2, (raw.height - side) / 2, side, side)
                    SettingsState.customBmp = Bitmap.createScaledBitmap(sq, 256, 256, true)
                }
            } catch (_: Throwable) {
                Util.toast(ctx, "Could not load that photo")
            }
        }
    }
    Dialog(onDismissRequest = onClose) {
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(p.solid).padding(16.dp)) {
            T("App icon", 18f, weight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            T("Tap an icon to change it. Some phones refresh the home screen after a few seconds.", 12f, p.sub)
            Spacer(Modifier.height(10.dp))
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items((0 until 20).toList().chunked(4)) { row ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        row.forEach { i ->
                            Box(
                                Modifier.clip(RoundedCornerShape(18.dp))
                                    .border(if (i == cur) 2.dp else 0.dp, if (i == cur) p.accent else Color.Transparent, RoundedCornerShape(18.dp))
                                    .tap { IconManager.apply(ctx, i); Util.toast(ctx, "Icon changed") }.padding(3.dp)
                            ) { BlobIcon(i, 56.dp) }
                        }
                    }
                }
                item {
                    Spacer(Modifier.height(10.dp))
                    T("Your own photo and name", 14f, weight = FontWeight.Medium)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val bmp = SettingsState.customBmp
                        Box(
                            Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)).background(p.accentSoft).tap { picker.launch("image/*") },
                            contentAlignment = Alignment.Center
                        ) {
                            if (bmp != null) {
                                androidx.compose.foundation.Image(bmp.asImageBitmap(), null, Modifier.size(64.dp), contentScale = ContentScale.Crop)
                            } else T("+", 26f, p.accent)
                        }
                        Spacer(Modifier.width(12.dp))
                        Box(Modifier.weight(1f)) { Field(label, { label = it }, "Name on home screen") }
                    }
                    Spacer(Modifier.height(10.dp))
                    PrimaryButton("Add to home screen", Modifier.fillMaxWidth(), SettingsState.customBmp != null) {
                        val b = SettingsState.customBmp
                        if (b != null) {
                            val ok = IconManager.pinCustom(ctx, b, label)
                            Util.toast(ctx, if (ok) "Confirm on the next screen" else "Your launcher does not support this")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    SoftButton("Close", Modifier.fillMaxWidth()) { onClose() }
                }
            }
        }
    }
}

@Composable
fun BackRow(title: String) {
    Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        SoftButton("Back") { SettingsState.sub = "" }
        Spacer(Modifier.width(12.dp))
        T(title, 24f, weight = FontWeight.SemiBold)
    }
}

@Composable
fun HistoryScreen() {
    val ctx = LocalContext.current
    val p = LocalPal.current
    BackHandler { SettingsState.sub = "" }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        BackRow("History")
        if (History.items.isEmpty()) {
            Spacer(Modifier.height(20.dp))
            T("Nothing downloaded yet.", 14f, p.sub)
        } else {
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                SoftButton("Clear all history") { History.clear() }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(History.items.toList()) { h ->
                    Row(Modifier.fillMaxWidth().glass(18.dp).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(p.accentSoft), contentAlignment = Alignment.Center) {
                            if (h.thumb.isNotEmpty() && Prefs.bool("fetch_thumbs") && !Prefs.bool("hide_thumbs_history")) {
                                AsyncImage(model = h.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(56.dp))
                            } else T(h.kind.take(1).uppercase(), 18f, p.accent, FontWeight.Medium)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            T(h.title, 14f, maxLines = 2)
                            T(h.site.replaceFirstChar { it.uppercase() } + (if (h.size > 0) "  \u00B7  " + Util.size(h.size) else ""), 12f, p.sub)
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Chip("Open", false) { Util.open(ctx, h.uri, h.mime) }
                                Chip("Share", false) { Util.share(ctx, h.uri, h.mime) }
                                Chip("Remove", false) { History.remove(h) }
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(20.dp)) }
            }
        }
    }
}

@Composable
fun LoginScreen(site: String) {
    val ctx = LocalContext.current
    val p = LocalPal.current
    BackHandler { SettingsState.sub = "" }
    val loginUrl = if (site == "instagram") "https://www.instagram.com/accounts/login/"
    else "https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fwww.youtube.com%2F"
    val urls = if (site == "instagram") listOf("https://www.instagram.com", "https://i.instagram.com")
    else listOf("https://www.youtube.com", "https://accounts.google.com", "https://www.google.com")
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        BackRow(if (site == "instagram") "Login Instagram" else "Login YouTube")
        T("Log in below, then tap Save login. Your login stays on this phone and is only used for your downloads.", 12f, p.sub)
        Spacer(Modifier.height(8.dp))
        AndroidView(
            factory = { c ->
                WebView(c).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.userAgentString = Http.UA_ANDROID
                    CookieManager.getInstance().setAcceptCookie(true)
                    webViewClient = WebViewClient()
                    loadUrl(loginUrl)
                }
            },
            modifier = Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(16.dp))
        )
        Spacer(Modifier.height(10.dp))
        PrimaryButton("Save login", Modifier.fillMaxWidth()) {
            val n = Cookies.saveFromWebView(ctx, site, urls)
            if (n > 3) {
                Util.toast(ctx, "Login saved")
                SettingsState.sub = ""
            } else Util.toast(ctx, "No login found yet. Finish logging in first.")
        }
        Spacer(Modifier.height(12.dp))
    }
}

private val STEPS = listOf(
    Triple("Copy the link", "Open YouTube or Instagram, tap Share, then Copy link.", "\u0932\u093F\u0902\u0915 \u0915\u0949\u092A\u0940 \u0915\u0930\u0947\u0902"),
    Triple("Open Fetchly and paste", "Tap Paste, or share the link straight to Fetchly.", "Fetchly \u0916\u094B\u0932\u0947\u0902 \u0914\u0930 \u092A\u0947\u0938\u094D\u091F \u0915\u0930\u0947\u0902"),
    Triple("Tap Fetch", "Fetchly reads the title, thumbnail and available qualities.", "Fetch \u0926\u092C\u093E\u090F\u0901"),
    Triple("Choose quality", "Pick Video or Audio, then the quality and format you want.", "\u0915\u094D\u0935\u093E\u0932\u093F\u091F\u0940 \u091A\u0941\u0928\u0947\u0902"),
    Triple("Tap Download", "Watch the progress. Tap Open when it finishes.", "Download \u0926\u092C\u093E\u090F\u0901"),
    Triple("Find it in your gallery", "Videos go to Movies, music to Music, photos to Pictures.", "\u0917\u0948\u0932\u0930\u0940 \u092E\u0947\u0902 \u0926\u0947\u0916\u0947\u0902")
)

// finger positions (dp) inside the 110 x 190 mini phone, per step
private val FINGER = listOf(Offset(70f, 150f), Offset(50f, 40f), Offset(50f, 78f), Offset(30f, 112f), Offset(50f, 150f), Offset(50f, 110f))

@Composable
fun MiniPhone(step: Int) {
    val p = LocalPal.current
    val inf = rememberInfiniteTransition(label = "finger")
    val s by inf.animateFloat(1f, 1.25f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "s")
    val line = p.sub.copy(alpha = 0.5f)
    val hi = p.accent
    Box(Modifier.size(width = 110.dp, height = 190.dp)) {
        Canvas(Modifier.size(width = 110.dp, height = 190.dp)) {
            val r = 18.dp.toPx()
            drawRoundRect(line, Offset.Zero, size, CornerRadius(r, r), style = Stroke(2.dp.toPx()))
            fun bar(x: Float, y: Float, w: Float, h: Float, c: Color) {
                drawRoundRect(c, Offset(x.dp.toPx(), y.dp.toPx()), Size(w.dp.toPx(), h.dp.toPx()), CornerRadius(6.dp.toPx(), 6.dp.toPx()))
            }
            val faint = p.sub.copy(alpha = 0.18f)
            bar(12f, 28f, 86f, 22f, if (step == 1) hi.copy(alpha = 0.35f) else faint)
            bar(12f, 66f, 86f, 22f, if (step == 2) hi.copy(alpha = 0.55f) else faint)
            bar(12f, 100f, 40f, 18f, if (step == 3) hi.copy(alpha = 0.45f) else faint)
            bar(58f, 100f, 40f, 18f, faint)
            bar(12f, 138f, 86f, 24f, if (step == 4) hi.copy(alpha = 0.7f) else faint)
            if (step == 0) bar(60f, 138f, 38f, 24f, hi.copy(alpha = 0.55f))
            if (step == 5) {
                for (i in 0 until 3) for (j in 0 until 2) bar(12f + i * 30f, 100f + j * 30f, 26f, 26f, hi.copy(alpha = 0.3f))
            }
        }
        val f = FINGER[step.coerceIn(0, 5)]
        T("\uD83D\uDC46", 30f, modifier = Modifier.offset(f.x.dp, f.y.dp).graphicsLayer { scaleX = s; scaleY = s })
    }
}

@Composable
fun HowToScreen() {
    val p = LocalPal.current
    BackHandler { SettingsState.sub = "" }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { BackRow("How to use") }
        items(STEPS.indices.toList()) { i ->
            val st = STEPS[i]
            Row(Modifier.fillMaxWidth().glass().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                MiniPhone(i)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    T("Step " + (i + 1), 12f, p.accent, FontWeight.Medium)
                    T(st.first, 16f, weight = FontWeight.SemiBold)
                    T(st.third, 13f, p.sub)
                    Spacer(Modifier.height(6.dp))
                    T(st.second, 13f)
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
}

@Composable
fun SettingsScreen() {
    when (SettingsState.sub) {
        "history" -> HistoryScreen()
        "howto" -> HowToScreen()
        "login_instagram" -> LoginScreen("instagram")
        "login_youtube" -> LoginScreen("youtube")
        else -> SettingsHome()
    }
    val key = SettingsState.choiceKey
    if (key.isNotEmpty()) {
        val d = SETTINGS_BY_KEY[key]
        if (d != null) ChoiceDialog(d) { SettingsState.choiceKey = "" } else SettingsState.choiceKey = ""
    }
    if (SettingsState.showIcons) IconDialog { SettingsState.showIcons = false }
}

@Composable
fun SettingsHome() {
    val ctx = LocalContext.current
    val p = LocalPal.current
    val clip = LocalClipboardManager.current
    val crash = File(ctx.filesDir, "crash.txt")
    var crashTick by remember { mutableStateOf(0) }
    val tree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (_: Throwable) {}
            Prefs.set("custom_tree", uri.toString())
            Util.toast(ctx, "Folder saved")
        }
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(Modifier.padding(top = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                Image2()
                Spacer(Modifier.width(10.dp))
                T("Settings", 30f, weight = FontWeight.SemiBold)
            }
        }
        item {
            GlassCard {
                T("Engine", 12f, p.sub)
                T(Engine.status + (if (Engine.version.isNotEmpty()) "  \u00B7  " + Engine.version else ""), 14f)
                Spacer(Modifier.height(8.dp))
                SoftButton("Update engine now", Modifier.fillMaxWidth()) {
                    Util.toast(ctx, "Updating...")
                    Engine.updateAsync(ctx) { toastMain(ctx, "Engine: $it") }
                }
            }
        }
        item {
            GlassCard {
                ActionRow("Download history", History.items.size.toString() + " saved") { SettingsState.sub = "history" }
                ActionRow("App icon and name", "20 icons, or your own photo") { SettingsState.showIcons = true }
                ActionRow("Login Instagram", if (Cookies.has(ctx, "instagram")) "Logged in" else "Needed for stories") { SettingsState.sub = "login_instagram" }
                ActionRow("Login YouTube", if (Cookies.has(ctx, "youtube")) "Logged in" else "Helps with 'confirm you are not a bot'") { SettingsState.sub = "login_youtube" }
                ActionRow("Remove saved logins") { Cookies.clear(ctx); Util.toast(ctx, "Logins removed") }
                ActionRow("How to use", "Step by step guide") { SettingsState.sub = "howto" }
            }
        }
        item {
            GlassCard {
                ActionRow("Clear cache") { Util.toast(ctx, "Cleared " + Manager.clearCache(ctx)) }
                ActionRow("Clear history") { History.clear(); Util.toast(ctx, "History cleared") }
                ActionRow("Reset all settings") {
                    val l = Prefs.str("launches")
                    val ic = Prefs.str("icon_idx")
                    Prefs.reset()
                    if (l.isNotEmpty()) Prefs.set("launches", l)
                    if (ic.isNotEmpty()) Prefs.set("icon_idx", ic)
                    Util.toast(ctx, "Settings reset")
                }
                if (crash.exists() && crashTick >= 0) ActionRow("Copy last crash report", "Send this to Claude if the app closes by itself") {
                    clip.setText(AnnotatedString(crash.readText()))
                    Util.toast(ctx, "Copied")
                }
            }
        }
        for (sec in SECTIONS) {
            val defs = SETTINGS.filter { it.section == sec }
            val open = sec in SettingsState.open
            item {
                Row(
                    Modifier.fillMaxWidth().glass().tap { SettingsState.open = if (open) SettingsState.open - sec else SettingsState.open + sec }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    T(sec, 16f, weight = FontWeight.Medium, modifier = Modifier.weight(1f))
                    T(defs.size.toString(), 12f, p.sub)
                    Spacer(Modifier.width(8.dp))
                    T(if (open) "\u2303" else "\u2304", 16f, p.sub)
                }
            }
            if (open) {
                item {
                    GlassCard {
                        defs.forEach { SettingRow(it) }
                        if (sec == "Downloads" && Prefs.str("save_mode") == "Custom folder") {
                            SoftButton("Choose folder", Modifier.fillMaxWidth()) { tree.launch(null) }
                            if (Prefs.str("custom_tree").isNotEmpty()) T("Folder is set", 12f, p.sub)
                        }
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                BlobIcon(Prefs.int("icon_idx", 0), 64.dp)
                Spacer(Modifier.height(8.dp))
                T("Fetchly", 18f, weight = FontWeight.SemiBold)
                T("Version 1.0", 12f, p.sub)
                Spacer(Modifier.height(10.dp))
                T("Made by Ayush Kumar", 13f, align = TextAlign.Center)
                T("Designed by Claude", 13f, p.sub, align = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Row {
                    T("Made in India ", 12f, p.sub)
                    T("\u2665", 12f, Color(0xFFE5566D))
                }
            }
        }
    }
}

@Composable
fun Image2() {
    androidx.compose.foundation.Image(
        Icons.Default.Settings, null, Modifier.size(32.dp),
        colorFilter = ColorFilter.tint(LocalPal.current.accent)
    )
}
