val vc: Int = (project.findProperty("vc") as String?)?.toIntOrNull() ?: 1

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.ayush.fetchly"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ayush.fetchly"
        minSdk = 26
        targetSdk = 34
        versionCode = vc
        versionName = "1.0.$vc"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    // Fixed signing key: every build is signed the same way, so a new APK can update the installed app.
    signingConfigs {
        create("fetchly") {
            storeFile = file("fetchly.jks")
            storePassword = "fetchly123"
            keyAlias = "fetchly"
            keyPassword = "fetchly123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fetchly")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fetchly")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }

    packaging {
        jniLibs { useLegacyPackaging = true }
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("io.github.junkfood02.youtubedl-android:library:0.17.2")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.17.2")
}
