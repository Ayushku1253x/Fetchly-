Inter (UI font) and MacintoshSkeletalFilled.otf (hello font) are bundled here.
Borel, Kalam, Pacifico, Galada, Lateef and Amatic SC are downloaded by the GitHub workflow (system font if missing).
