package com.ayush.fetchly

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Fallback for sites that yt-dlp has no extractor for.
 * Opens the page in a hidden WebView, lets the page's own player start, and watches the network
 * for the real stream address (.m3u8, .mpd, .mp4 ...). That address is then handed to yt-dlp
 * together with the same referer, user-agent and cookies the page used.
 * DRM streams are not touched: yt-dlp refuses them and the app shows a clear message.
 */
object Sniffer {
    class Hit(val url: String, val referer: String, val ua: String, val cookie: String, val title: String)

    private val MEDIA = Regex("\\.(m3u8|mpd|mp4|webm|m4v|mov|mp3|m4a)(\\?|#|$)", RegexOption.IGNORE_CASE)
    private val STREAM = Regex("\\.(m3u8|mpd)(\\?|#|$)", RegexOption.IGNORE_CASE)
    private val BAD = Regex("(doubleclick|googlesyndication|adservice|adsystem|/ads?/|analytics|pixel|beacon|tracking|widevine|license|preview|thumb|sprite)", RegexOption.IGNORE_CASE)
    private const val PLAY_JS =
        "(function(){try{document.querySelectorAll('video,audio').forEach(function(v){v.muted=true;var p=v.play();if(p&&p.catch)p.catch(function(){});});" +
            "var sel=['.vjs-big-play-button','.jw-icon-display','.plyr__control--overlaid','.ytp-large-play-button','[aria-label=\"Play\"]','[class*=\"play-btn\"]','[class*=\"playBtn\"]','[class*=\"play_button\"]','button[class*=\"play\"]'];" +
            "sel.forEach(function(s){var e=document.querySelector(s);if(e)e.click();});}catch(e){}})();"
    private const val SRC_JS =
        "(function(){try{var v=document.querySelector('video');if(!v)return '';var s=v.currentSrc||v.src||'';if(!s){var so=v.querySelector('source');if(so)s=so.src||'';}return s;}catch(e){return '';}})();"

    fun isMedia(u: String): Boolean = MEDIA.containsMatchIn(u) && !BAD.containsMatchIn(u)

    fun best(found: List<String>): String? = pick(found)

    private fun pick(found: List<String>): String? {
        val streams = found.filter { STREAM.containsMatchIn(it) }
        // a master playlist usually has no "chunk/segment/audio-only" hint in its name
        streams.firstOrNull { !it.contains("chunk", true) && !it.contains("segment", true) }?.let { return it }
        streams.firstOrNull()?.let { return it }
        return found.firstOrNull()
    }

    @SuppressLint("SetJavaScriptEnabled")
    suspend fun sniff(ctx: Context, pageUrl: String, waitMs: Long = 12000L): Hit? = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<Hit?> { cont ->
            val app = ctx.applicationContext
            val handler = Handler(Looper.getMainLooper())
            val done = AtomicBoolean(false)
            val found = CopyOnWriteArrayList<String>()
            val ua = Http.UA_DESKTOP
            var web: WebView? = null

            fun finish(hit: Hit?) {
                if (!done.compareAndSet(false, true)) return
                handler.removeCallbacksAndMessages(null)
                try { web?.stopLoading(); web?.destroy() } catch (_: Throwable) {}
                web = null
                if (cont.isActive) cont.resumeWith(Result.success(hit))
            }

            fun build(title: String): Hit? {
                val best = pick(found.toList()) ?: return null
                val cookie = try { CookieManager.getInstance().getCookie(pageUrl) ?: "" } catch (_: Throwable) { "" }
                return Hit(best, pageUrl, ua, cookie, title)
            }

            try {
                val w = WebView(app)
                web = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.mediaPlaybackRequiresUserGesture = false
                w.settings.userAgentString = ua
                try { CookieManager.getInstance().setAcceptCookie(true) } catch (_: Throwable) {}
                w.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                        val u = request?.url?.toString() ?: return null
                        if (MEDIA.containsMatchIn(u) && !BAD.containsMatchIn(u) && !found.contains(u)) {
                            found.add(u)
                            if (STREAM.containsMatchIn(u)) {
                                // give the page a moment to ask for a better playlist, then stop
                                handler.postDelayed({ finish(build(view?.title ?: "")) }, 1500)
                            }
                        }
                        return null
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        view?.evaluateJavascript(PLAY_JS, null)
                        handler.postDelayed({ view?.evaluateJavascript(PLAY_JS, null) }, 2000)
                        handler.postDelayed({ view?.evaluateJavascript(PLAY_JS, null) }, 5000)
                        handler.postDelayed({
                            view?.evaluateJavascript(SRC_JS) { raw ->
                                val s = (raw ?: "").trim('"').replace("\\u0026", "&").replace("\\/", "/")
                                if (s.startsWith("http") && !s.startsWith("blob:") && !found.contains(s)) found.add(s)
                            }
                        }, 7000)
                    }
                }
                handler.postDelayed({
                    val t = try { web?.title ?: "" } catch (_: Throwable) { "" }
                    finish(build(t))
                }, waitMs)
                cont.invokeOnCancellation { handler.post { finish(null) } }
                w.loadUrl(pageUrl, mapOf("Referer" to (Uri.parse(pageUrl).let { it.scheme + "://" + it.host + "/" })))
            } catch (t: Throwable) {
                finish(null)
            }
        }
    }
}
