package com.ayush.fetchly

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Share a link from any app to Fetchly and it is saved in the background in the best format,
 * with no taps. Everything it uses comes from Settings > Share & Auto.
 */
object AutoShare {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var lastUrl = ""
    private var lastTime = 0L

    fun enabled(): Boolean = Prefs.bool("share_auto") && Prefs.str("share_mode") != "Ask me (open app)"

    fun start(app: Context, url: String) {
        val now = System.currentTimeMillis()
        if (Prefs.bool("share_dedupe") && url == lastUrl && now - lastTime < 60000) {
            toastMain(app, "Fetchly: this link is already being saved")
            return
        }
        lastUrl = url
        lastTime = now
        try { ContextCompat.startForegroundService(app, Intent(app, DownloadService::class.java)) } catch (_: Throwable) {}
        if (Prefs.bool("share_toast")) toastMain(app, "Fetchly: saving in the background")
        scope.launch { run(app, url) }
    }

    private suspend fun run(app: Context, url: String) {
        try {
            var waited = 0
            while (!Engine.ready && waited < 60000) { delay(500); waited += 500 }
            if (!Engine.ready) throw Exception("Engine is still starting. Open Fetchly once and share again.")
            when (Util.detect(url)) {
                "youtube" -> youtube(app, url)
                "instagram" -> instagram(app, url)
                else -> web(app, url)
            }
        } catch (t: Throwable) {
            toastMain(app, "Fetchly: " + Engine.friendly(t.message ?: t.toString()))
            if (Manager.activeCount() == 0) {
                try { app.stopService(Intent(app, DownloadService::class.java)) } catch (_: Throwable) {}
            }
        }
    }

    private fun heightOf(label: String): Int? = when (label) {
        "Best", "" -> null
        "8K" -> 4320
        "4K" -> 2160
        else -> label.filter { it.isDigit() }.toIntOrNull()
    }

    private fun wantedHeight(): Int? {
        val q = Prefs.str("share_quality")
        return heightOf(if (q == "Same as default" || q.isEmpty()) Prefs.str("video_quality") else q)
    }

    private suspend fun enqueueYt(app: Context, info: MediaInfo, o: DlOptions) {
        withContext(Dispatchers.Main) {
            Manager.enqueueYt(app, info, o)
            if (!Prefs.bool("auto_start")) Manager.items.firstOrNull()?.let { Manager.start(it) }
            Unit
        }
    }

    private suspend fun enqueueDirect(app: Context, urls: List<String>, ref: String?, title: String, site: String, kind: String) {
        if (urls.isEmpty()) return
        withContext(Dispatchers.Main) {
            val before = Manager.items.size
            Manager.enqueueDirect(app, urls, ref, title, site, kind)
            if (!Prefs.bool("auto_start")) {
                val added = Manager.items.size - before
                Manager.items.take(added).forEach { Manager.start(it) }
            }
            Unit
        }
    }

    private suspend fun youtube(app: Context, url: String) {
        val pl = Prefs.bool("share_playlist")
        val info = withContext(Dispatchers.IO) { Engine.fetchInfoRetry(app, url, pl, true) }
        val music = "music.youtube.com" in url && Prefs.bool("share_music_audio")
        val audio = Prefs.str("share_mode") == "Audio" || music
        enqueueYt(
            app, info,
            DlOptions(
                "youtube", audio, if (audio) null else wantedHeight(), Prefs.str("video_container"),
                Prefs.str("audio_format"), Prefs.str("audio_quality"), "", "", pl && info.playlistCount > 1
            )
        )
    }

    private suspend fun instagram(app: Context, url: String) {
        val story = "/stories/" in url
        val path = url.substringAfter("instagram.com/", "").substringBefore('?').substringBefore('#').trim('/')
        val segs = path.split('/').filter { it.isNotEmpty() }
        val reserved = listOf("p", "reel", "reels", "tv", "stories", "explore", "s")
        if (segs.size == 1 && segs[0] !in reserved) {
            val user = segs[0].removePrefix("@")
            val dp = withContext(Dispatchers.IO) { Scraper.instagramDp(app, user) }
                ?: throw Exception("Could not get the profile photo. If it is private, login in Settings first.")
            enqueueDirect(app, listOf(dp), null, "instagram_$user", "instagram", "image")
            return
        }
        val pl = (story && Prefs.bool("ig_story_all")) || (!story && Prefs.bool("ig_carousel_all"))
        try {
            val info = withContext(Dispatchers.IO) { Engine.fetchInfoRetry(app, url, pl, false) }
            enqueueYt(
                app, info,
                DlOptions("instagram", Prefs.bool("ig_audio_reel"), null, "Original", Prefs.str("audio_format"), Prefs.str("audio_quality"), "", "", pl)
            )
        } catch (t: Throwable) {
            val found = try { withContext(Dispatchers.IO) { Scraper.scan(url).filter { it.type != "audio" } } } catch (_: Throwable) { emptyList() }
            if (found.isEmpty()) throw t
            enqueueDirect(app, found.filter { it.type == "image" }.map { it.url }, url, "instagram_photo", "instagram", "image")
            enqueueDirect(app, found.filter { it.type == "video" }.map { it.url }, url, "instagram_video", "instagram", "video")
        }
    }

    private suspend fun web(app: Context, url: String) {
        if (Prefs.bool("share_web_video_first")) {
            try {
                val info = withContext(Dispatchers.IO) { Engine.fetchInfo(app, url, false, false, 0) }
                enqueueYt(
                    app, info,
                    DlOptions("web", false, wantedHeight(), Prefs.str("video_container"), Prefs.str("audio_format"), Prefs.str("audio_quality"))
                )
                return
            } catch (_: Throwable) {}
        }
        var list = withContext(Dispatchers.IO) { Scraper.filterBySize(Scraper.scan(url)) }
        if (list.isEmpty()) throw Exception("No media found on this page.")
        val lim = Prefs.str("share_web_limit").toIntOrNull()
        if (lim != null) list = list.take(lim)
        enqueueDirect(app, list.filter { it.type == "image" }.map { it.url }, url, "web_image", "web", "image")
        enqueueDirect(app, list.filter { it.type == "video" }.map { it.url }, url, "web_video", "web", "video")
        enqueueDirect(app, list.filter { it.type == "audio" }.map { it.url }, url, "web_audio", "web", "audio")
    }
}
