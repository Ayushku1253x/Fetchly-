package com.ayush.fetchly

/**
 * One row per download option. Each row becomes a setting AND is passed to the download engine,
 * so Settings and the engine can never get out of sync.
 */
class AOpt(val def: SDef, val flag: String, val prefix: String = "", val fixed: String? = null)

private fun t(key: String, title: String, flag: String, section: String, desc: String = "", fixed: String? = null) =
    AOpt(SDef(key, title, SType.TOGGLE, "false", section, emptyList(), desc), flag, "", fixed)

private fun c(key: String, title: String, flag: String, section: String, choices: List<String>, prefix: String = "", desc: String = "") =
    AOpt(SDef(key, title, SType.CHOICE, choices[0], section, choices, desc), flag, prefix)

private fun x(key: String, title: String, flag: String, section: String, prefix: String = "", desc: String = "") =
    AOpt(SDef(key, title, SType.TEXT, "", section, emptyList(), desc), flag, prefix)

private const val NET = "Network and speed"
private const val FILES = "Files and names"
private const val SEL = "Selection"
private const val POST = "Convert and edit"
private const val YT = "YouTube options"
private const val LOGIN = "Access and login"

val ADV_TABLE: List<AOpt> = listOf(
    // ---- Network and speed ----
    x("o_source_addr", "Source IP address", "--source-address", NET),
    x("o_geo_proxy", "Geo verification proxy", "--geo-verification-proxy", NET),
    c("o_throttled", "Retry if speed drops below", "--throttled-rate", NET, listOf("Default", "50K", "100K", "200K", "500K", "1M")),
    c("o_buffer", "Buffer size", "--buffer-size", NET, listOf("Default", "16K", "64K", "256K", "1M", "4M")),
    t("o_fixed_buffer", "Fixed buffer size", "--no-resize-buffer", NET),
    t("o_skip_frag", "Skip missing fragments", "--skip-unavailable-fragments", NET),
    t("o_abort_frag", "Stop if a fragment is missing", "--abort-on-unavailable-fragments", NET),
    t("o_hls_native", "Use built-in HLS downloader", "--hls-prefer-native", NET),
    t("o_hls_ffmpeg", "Use ffmpeg for HLS", "--hls-prefer-ffmpeg", NET),
    t("o_hls_split", "Split HLS at discontinuities", "--hls-split-discontinuity", NET),
    t("o_mpd", "Allow changing live streams (MPD)", "--allow-dynamic-mpd", NET),
    t("o_xattr_size", "Save file size info", "--xattr-set-filesize", NET),
    t("o_no_cache", "Do not use cache", "--no-cache-dir", NET),
    c("o_sleep_subs", "Pause before subtitles (sec)", "--sleep-subtitles", NET, listOf("Default", "1", "2", "5")),
    x("o_sections", "Download only a part (example *1:00-2:30)", "--download-sections", NET),
    x("o_dl_args", "Downloader arguments (example ffmpeg_i:-ss 10)", "--downloader-args", NET),
    t("o_multi_audio", "Keep every audio track", "--audio-multistreams", NET),
    t("o_multi_video", "Keep every video track", "--video-multistreams", NET),
    t("o_ignore_noformat", "Ignore the no formats error", "--ignore-no-formats-error", NET),
    t("o_check_all", "Check every format (slow)", "--check-all-formats", NET),
    t("o_sort_force", "My format sorting wins over everything", "--format-sort-force", NET),
    x("o_encoding", "Text encoding", "--encoding", NET),
    x("o_compat", "Compatibility options (example no-live-chat)", "--compat-options", NET),

    // ---- Files and names ----
    c("o_trim_names", "Longest file name", "--trim-filenames", FILES, listOf("Default", "50", "80", "100", "150", "200", "255")),
    x("o_na", "Text for missing info", "--output-na-placeholder", FILES),
    t("o_pl_meta", "Save playlist info files", "--write-playlist-metafiles", FILES),
    t("o_clean_info", "Clean the info file", "--clean-info-json", FILES),
    t("o_xattrs", "Write info into file attributes", "--xattrs", FILES),
    t("o_link", "Save a link file (.url)", "--write-url-link", FILES),
    t("o_webloc", "Save a link file for Apple (.webloc)", "--write-webloc-link", FILES),
    t("o_desktop", "Save a link file for Linux (.desktop)", "--write-desktop-link", FILES),
    c("o_concat", "Join playlist into one file", "--concat-playlist", FILES, listOf("Default", "never", "always", "multi_video")),
    t("o_skip_download", "Only save info, subtitles and thumbnails (no video)", "--skip-download", FILES),

    // ---- Selection ----
    c("o_pl_start", "Start from item number", "--playlist-start", SEL, listOf("Default", "1", "2", "5", "10", "20", "50")),
    c("o_pl_end", "Stop at item number", "--playlist-end", SEL, listOf("Default", "1", "5", "10", "20", "50", "100", "200")),
    x("o_date", "Uploaded exactly on (example 20240131)", "--date", SEL),
    x("o_break_filter", "Stop when this filter fails", "--break-match-filters", SEL),
    t("o_break_reject", "Stop at the first rejected video", "--break-on-reject", SEL),
    t("o_break_input", "Reset stop rules for each link", "--break-per-input", SEL),
    c("o_skip_pl_err", "Skip playlist after this many errors", "--skip-playlist-after-errors", SEL, listOf("Default", "1", "3", "5", "10")),
    t("o_mark_watched", "Mark as watched on YouTube (needs login)", "--mark-watched", SEL),
    x("o_use_extractors", "Only use these sites (example youtube,instagram)", "--use-extractors", SEL),

    // ---- Convert and edit ----
    c("o_remux", "Change container after download (fast)", "--remux-video", POST, listOf("Off", "mp4", "mkv", "mov", "webm", "avi", "flv")),
    c("o_recode", "Re-encode video (slow, plays everywhere)", "--recode-video", POST, listOf("Off", "mp4", "mkv", "mov", "webm", "avi", "flv")),
    x("o_pp_args", "FFmpeg arguments (example ffmpeg:-crf 23)", "--postprocessor-args", POST),
    x("o_parse_meta", "Edit info (example title:%(artist)s - %(title)s)", "--parse-metadata", POST),
    x("o_remove_chapters", "Remove chapters that match", "--remove-chapters", POST),
    x("o_sb_title", "SponsorBlock chapter title", "--sponsorblock-chapter-title", POST),
    x("o_sb_api", "SponsorBlock server", "--sponsorblock-api", POST),
    t("o_no_sb", "Turn SponsorBlock off completely", "--no-sponsorblock", POST),

    // ---- YouTube options ----
    c("o_yt_skip", "Skip YouTube parts", "--extractor-args", YT, listOf("Default", "dash", "hls", "dash,hls", "translated_subs", "dash,hls,translated_subs"), "youtube:skip="),
    c(
        "o_yt_lang", "YouTube language", "--extractor-args", YT,
        listOf("Default", "en", "hi", "bn", "ta", "te", "mr", "gu", "kn", "ml", "pa", "ur", "es", "fr", "de", "pt", "ru", "ja", "ko", "ar", "zh", "tr", "id", "vi", "th", "it", "nl", "pl"),
        "youtube:lang="
    ),
    t("o_yt_tab_fast", "Load playlists faster", "--extractor-args", YT, "Skips the web page when listing a playlist", "youtubetab:skip=webpage"),

    // ---- Access and login ----
    x("o_video_pw", "Video password", "--video-password", LOGIN, desc = "For password protected videos"),
)

val ADV_SETTINGS: List<SDef> = ADV_TABLE.map { it.def }
