package com.ayush.fetchly

import android.content.Context
import android.graphics.Typeface
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Fonts {
    var borel: FontFamily? = null
    var kalam: FontFamily? = null
    var kalamBold: FontFamily? = null
    var pacifico: FontFamily? = null
    var skeletal: FontFamily? = null
    var galada: FontFamily? = null
    var lateef: FontFamily? = null
    var amatic: FontFamily? = null
    // Inter: the UI font (YouTube, Instagram, Websites, Settings, Downloading and every other screen)
    var ui: FontFamily? = null

    fun load(ctx: Context) {
        borel = tf(ctx, "fonts/Borel-Regular.ttf")
        kalam = tf(ctx, "fonts/Kalam-Regular.ttf")
        kalamBold = tf(ctx, "fonts/Kalam-Bold.ttf")
        pacifico = tf(ctx, "fonts/Pacifico-Regular.ttf")
        galada = tf(ctx, "fonts/Galada-Regular.ttf")
        lateef = tf(ctx, "fonts/Lateef-Regular.ttf")
        amatic = tf(ctx, "fonts/AmaticSC-Regular.ttf")
        ui = try {
            FontFamily(
                Font("fonts/Inter-Regular.otf", ctx.assets, FontWeight.Normal),
                Font("fonts/Inter-Medium.otf", ctx.assets, FontWeight.Medium),
                Font("fonts/Inter-SemiBold.otf", ctx.assets, FontWeight.SemiBold),
                Font("fonts/Inter-Bold.otf", ctx.assets, FontWeight.Bold)
            )
        } catch (_: Throwable) {
            null
        }
        // Macintosh Skeletal Filled: put the font file in app/src/main/assets/fonts/ (any of these names)
        skeletal = listOf(
            "MacintoshSkeletalFilled.ttf", "MacintoshSkeletalFilled.otf",
            "Macintosh-Skeletal-Filled.ttf", "Macintosh Skeletal Filled.ttf",
            "MacintoshSkeletal-Filled.ttf", "MacintoshSkeletal.ttf"
        ).firstNotNullOfOrNull { tf(ctx, "fonts/$it") }
    }

    private fun tf(ctx: Context, path: String): FontFamily? = try {
        FontFamily(Typeface.createFromAsset(ctx.assets, path))
    } catch (_: Throwable) {
        null
    }
}

class Pal(
    val dark: Boolean, val bg: Color, val text: Color, val sub: Color, val glass: Color, val border: Color,
    val accent: Color, val accentSoft: Color, val radius: Dp, val solid: Color, val pad: Dp
)

val LocalPal = staticCompositionLocalOf<Pal> { error("Pal not provided") }

fun accentColor(name: String): Color = when (name) {
    "Indigo" -> Color(0xFF5B5BD6)
    "Purple" -> Color(0xFF8E5CF0)
    "Pink" -> Color(0xFFEC6BA0)
    "Red" -> Color(0xFFE5566D)
    "Orange" -> Color(0xFFF2842C)
    "Green" -> Color(0xFF3DBE7A)
    "Teal" -> Color(0xFF2BB3A8)
    else -> Color(0xFF6F93F0)
}

@Composable
fun rememberPal(): Pal {
    val sys = isSystemInDarkTheme()
    val mode = Prefs.str("theme_mode")
    val dark = mode == "Dark" || (mode == "Auto" && sys)
    val accent = accentColor(Prefs.str("accent"))
    val gi = when (Prefs.str("glass_strength")) {
        "Light" -> 0
        "Medium" -> 1
        "Thick" -> 2
        else -> 3
    }
    val lightA = listOf(0.42f, 0.56f, 0.70f, 0.84f)[gi]
    val darkA = listOf(0.07f, 0.11f, 0.16f, 0.23f)[gi]
    val r = when (Prefs.str("corner_style")) {
        "Round" -> 16.dp
        "Pill" -> 30.dp
        else -> 22.dp
    }
    val pad = if (Prefs.bool("compact_mode")) 10.dp else 14.dp
    return if (dark) {
        Pal(true, Color(0xFF0B0D17), Color(0xFFF1F3FF), Color(0xFF9AA3C7), Color.White.copy(alpha = darkA), Color.White.copy(alpha = 0.18f), accent, accent.copy(alpha = 0.28f), r, Color(0xFF1B1E2C), pad)
    } else {
        Pal(false, Color(0xFFF5F7FC), Color(0xFF1C2230), Color(0xFF5D6578), Color.White.copy(alpha = lightA), Color.White.copy(alpha = 0.95f), accent, accent.copy(alpha = 0.18f), r, Color.White, pad)
    }
}

@Composable
fun T(
    text: String, size: Float = 14f, color: Color? = null, weight: FontWeight = FontWeight.Normal,
    family: FontFamily? = null, align: TextAlign = TextAlign.Start, maxLines: Int = Int.MAX_VALUE, modifier: Modifier = Modifier
) {
    val pal = LocalPal.current
    BasicText(
        text, modifier,
        style = TextStyle(color = color ?: pal.text, fontSize = size.sp, fontWeight = weight, fontFamily = family ?: Fonts.ui, textAlign = align),
        maxLines = maxLines, overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun Modifier.tap(onClick: () -> Unit): Modifier {
    val hf = LocalHapticFeedback.current
    val src = remember { MutableInteractionSource() }
    return this.clickable(interactionSource = src, indication = null) {
        if (Prefs.bool("haptics")) hf.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        onClick()
    }
}

@Composable
fun Modifier.glass(radius: Dp? = null): Modifier {
    val p = LocalPal.current
    val shape = RoundedCornerShape(radius ?: p.radius)
    return this.background(p.glass, shape).border(1.dp, p.border, shape).clip(shape)
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    Column(modifier.fillMaxWidth().glass().padding(p.pad), content = content)
}

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val p = LocalPal.current
    val base = modifier.clip(RoundedCornerShape(p.radius)).background(if (enabled) p.accent else p.accent.copy(alpha = 0.35f))
    val m = if (enabled) base.tap(onClick) else base
    Box(m.padding(vertical = 14.dp, horizontal = 20.dp), contentAlignment = Alignment.Center) {
        T(text, 15f, Color.White, FontWeight.Medium, align = TextAlign.Center)
    }
}

@Composable
fun SoftButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val p = LocalPal.current
    Box(
        modifier.clip(RoundedCornerShape(p.radius)).background(p.accentSoft).tap(onClick).padding(vertical = 11.dp, horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) { T(text, 14f, p.accent, FontWeight.Medium, align = TextAlign.Center) }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier.clip(shape).background(if (selected) p.accentSoft else p.glass)
            .border(1.dp, if (selected) p.accent else p.border, shape).tap(onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) { T(text, 13f, if (selected) p.accent else p.text, if (selected) FontWeight.Medium else FontWeight.Normal) }
}

@Composable
fun Seg(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().glass(16.dp).padding(3.dp)) {
        options.forEachIndexed { i, s ->
            val on = i == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(13.dp))
                    .background(if (on) (if (p.dark) Color.White.copy(alpha = 0.22f) else Color.White) else Color.Transparent)
                    .tap { onSelect(i) }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) { T(s, 13f, if (on) p.text else p.sub, if (on) FontWeight.Medium else FontWeight.Normal, align = TextAlign.Center) }
        }
    }
}

@Composable
fun Toggle(on: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPal.current
    val x by animateDpAsState(if (on) 20.dp else 2.dp, tween(180), label = "tg")
    Box(
        Modifier.size(width = 46.dp, height = 28.dp).clip(RoundedCornerShape(14.dp))
            .background(if (on) Color(0xFF34C759) else (if (p.dark) Color.White.copy(alpha = 0.2f) else Color(0x33283C78)))
            .tap { onChange(!on) }
    ) { Box(Modifier.offset(x = x, y = 2.dp).size(24.dp).clip(RoundedCornerShape(12.dp)).background(Color.White)) }
}

@Composable
fun PrefToggle(title: String, key: String, desc: String = "") {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            T(title, 14f)
            if (desc.isNotEmpty()) T(desc, 12f, p.sub)
        }
        Spacer(Modifier.width(10.dp))
        Toggle(Prefs.bool(key)) { Prefs.setBool(key, it) }
    }
}

@Composable
fun Field(
    value: String, onValue: (String) -> Unit, hint: String, modifier: Modifier = Modifier,
    singleLine: Boolean = true, trailing: (@Composable () -> Unit)? = null
) {
    val p = LocalPal.current
    Row(modifier.fillMaxWidth().glass().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) T(hint, 14f, p.sub, maxLines = 1)
            BasicTextField(
                value, onValue, singleLine = singleLine,
                textStyle = TextStyle(color = p.text, fontSize = 14.sp, fontFamily = Fonts.ui),
                cursorBrush = SolidColor(p.accent), modifier = Modifier.fillMaxWidth()
            )
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            trailing()
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    val p = LocalPal.current
    Box(Modifier.padding(top = 10.dp, start = 4.dp)) { T(text.uppercase(), 12f, p.sub, FontWeight.Medium) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Flow(content: @Composable () -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        content()
    }
}

@Composable
fun AppBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val p = LocalPal.current
    val blobs = Prefs.bool("bg_blobs")
    val k = when (Prefs.str("blob_intensity")) {
        "Soft" -> 0.55f
        "Vivid" -> 1.25f
        else -> 0.9f
    }
    Box(modifier.background(p.bg).drawBehind {
        if (blobs) {
            val w = size.width
            val h = size.height
            val cols = if (p.dark) listOf(Color(0xFF1F6BFF), Color(0xFF8B3DFF), Color(0xFF00C2A8)) else listOf(Color(0xFFCFE0FF), Color(0xFFE6D8FF), Color(0xFFCDF1E8))
            val a = ((if (p.dark) 0.38f else 0.85f) * k).coerceIn(0f, 1f)
            fun blob(c: Color, cx: Float, cy: Float, r: Float) {
                drawCircle(
                    brush = Brush.radialGradient(listOf(c.copy(alpha = a), Color.Transparent), center = Offset(cx * w, cy * h), radius = r * w),
                    radius = r * w, center = Offset(cx * w, cy * h)
                )
            }
            blob(cols[0], 0.12f, 0.06f, 0.75f)
            blob(cols[1], 0.95f, 0.45f, 0.7f)
            blob(cols[2], 0.2f, 0.95f, 0.75f)
        }
    }, content = content)
}

@Composable
fun PlatformIcon(kind: String, dp: Dp, alpha: Float = 1f) {
    Canvas(Modifier.size(dp)) {
        val s = this.size.minDimension
        when (kind) {
            "youtube" -> {
                drawRoundRect(Color(0xFFFF2D3A).copy(alpha = alpha), Offset(0f, s * 0.2f), Size(s, s * 0.6f), CornerRadius(s * 0.18f, s * 0.18f))
                val tri = Path()
                tri.moveTo(s * 0.42f, s * 0.36f)
                tri.lineTo(s * 0.68f, s * 0.5f)
                tri.lineTo(s * 0.42f, s * 0.64f)
                tri.close()
                drawPath(tri, Color.White.copy(alpha = alpha))
            }
            "instagram" -> {
                drawRoundRect(
                    Brush.linearGradient(listOf(Color(0xFFFEDA75), Color(0xFFFA7E1E), Color(0xFFD62976), Color(0xFF962FBF), Color(0xFF4F5BD5)), start = Offset(0f, s), end = Offset(s, 0f)),
                    Offset.Zero, Size(s, s), CornerRadius(s * 0.28f, s * 0.28f), alpha = alpha
                )
                val w = Color.White.copy(alpha = alpha)
                drawRoundRect(w, Offset(s * 0.22f, s * 0.22f), Size(s * 0.56f, s * 0.56f), CornerRadius(s * 0.16f, s * 0.16f), style = Stroke(s * 0.07f))
                drawCircle(w, s * 0.13f, Offset(s / 2f, s / 2f), style = Stroke(s * 0.07f))
                drawCircle(w, s * 0.04f, Offset(s * 0.7f, s * 0.3f))
            }
            "web" -> {
                val c = Color(0xFF3B82F6).copy(alpha = alpha)
                val sw = s * 0.07f
                drawCircle(c, s * 0.4f, Offset(s / 2f, s / 2f), style = Stroke(sw))
                drawOval(c, Offset(s * 0.3f, s * 0.1f), Size(s * 0.4f, s * 0.8f), style = Stroke(sw))
                drawLine(c, Offset(s * 0.1f, s / 2f), Offset(s * 0.9f, s / 2f), strokeWidth = sw)
            }
            else -> {
                val c = Color(0xFF6F93F0).copy(alpha = alpha)
                val sw = s * 0.1f
                drawLine(c, Offset(s / 2f, s * 0.15f), Offset(s / 2f, s * 0.7f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(c, Offset(s * 0.28f, s * 0.5f), Offset(s / 2f, s * 0.72f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(c, Offset(s * 0.72f, s * 0.5f), Offset(s / 2f, s * 0.72f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(c, Offset(s * 0.2f, s * 0.88f), Offset(s * 0.8f, s * 0.88f), strokeWidth = sw, cap = StrokeCap.Round)
            }
        }
    }
}

private val SHAPES = listOf(
    floatArrayOf(48f, 17f, 65f, 15f, 79f, 30f, 77f, 48f, 75f, 67f, 60f, 80f, 44f, 76f, 27f, 72f, 17f, 57f, 21f, 41f, 24f, 27f, 36f, 19f, 48f, 17f),
    floatArrayOf(50f, 15f, 68f, 20f, 78f, 34f, 75f, 52f, 72f, 69f, 58f, 78f, 42f, 75f, 26f, 71f, 19f, 54f, 23f, 38f, 27f, 24f, 38f, 12f, 50f, 15f),
    floatArrayOf(48f, 16f, 66f, 18f, 78f, 33f, 76f, 50f, 74f, 68f, 58f, 79f, 42f, 75f, 26f, 71f, 18f, 57f, 22f, 41f, 25f, 27f, 34f, 14f, 48f, 16f)
)

private fun blobPath(a: FloatArray, s: Float): Path {
    val p = Path()
    p.moveTo(a[0] * s, a[1] * s)
    for (i in 0 until 4) {
        val o = 2 + i * 6
        p.cubicTo(a[o] * s, a[o + 1] * s, a[o + 2] * s, a[o + 3] * s, a[o + 4] * s, a[o + 5] * s)
    }
    p.close()
    return p
}

fun DrawScope.drawLogo(
    idx: Int, tile: Float = 1f, blobY: Float = 0f, blobA: Float = 1f, gloss: Float = 1f,
    arrow: Float = 1f, morph: Float = 0f, arrowDy: Float = 0f
) {
    val c = ICON_PAL[idx.coerceIn(0, ICON_PAL.size - 1)]
    val s = size.minDimension / 96f
    val center = Offset(size.width / 2f, size.height / 2f)
    scale(0.7f + 0.3f * tile, center) {
        drawRoundRect(c.bg.copy(alpha = tile.coerceIn(0f, 1f)), Offset.Zero, size, CornerRadius(24f * s, 24f * s))
    }
    if (blobA > 0.01f) {
        val a = SHAPES[idx % 3]
        val b = SHAPES[(idx + 1) % 3]
        val m = FloatArray(26) { a[it] * (1f - morph) + b[it] * morph }
        translate(0f, blobY * s) {
            drawPath(
                blobPath(m, s),
                Brush.linearGradient(0f to c.c1, 0.55f to c.c2, 1f to c.c3, start = Offset(21f * s, 17f * s), end = Offset(77f * s, 78f * s)),
                alpha = blobA.coerceIn(0f, 1f)
            )
            val g = Path()
            g.moveTo(32f * s, 34f * s)
            g.cubicTo(37f * s, 26f * s, 48f * s, 24f * s, 56f * s, 27f * s)
            g.cubicTo(48f * s, 28f * s, 38f * s, 32f * s, 34f * s, 40f * s)
            g.cubicTo(32f * s, 40f * s, 31f * s, 37f * s, 32f * s, 34f * s)
            g.close()
            drawPath(g, Color.White.copy(alpha = (0.4f * gloss * blobA).coerceIn(0f, 1f)))
            val dy = arrowDy * s
            val p1 = (arrow / 0.45f).coerceIn(0f, 1f)
            val p2 = ((arrow - 0.45f) / 0.55f).coerceIn(0f, 1f)
            val ac = c.arrow
            val sw = 5f * s
            if (p1 > 0f) drawLine(ac, Offset(48f * s, 36f * s + dy), Offset(48f * s, (36f + 23f * p1) * s + dy), strokeWidth = sw, cap = StrokeCap.Round)
            if (p2 > 0f) {
                val h1 = (p2 * 2f).coerceIn(0f, 1f)
                val h2 = (p2 * 2f - 1f).coerceIn(0f, 1f)
                drawLine(ac, Offset(39f * s, 51f * s + dy), Offset((39f + 9f * h1) * s, (51f + 9f * h1) * s + dy), strokeWidth = sw, cap = StrokeCap.Round)
                if (h2 > 0f) drawLine(ac, Offset(48f * s, 60f * s + dy), Offset((48f + 9f * h2) * s, (60f - 9f * h2) * s + dy), strokeWidth = sw, cap = StrokeCap.Round)
            }
        }
    }
}

@Composable
fun BlobIcon(idx: Int, dp: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(dp)) { drawLogo(idx) }
}

fun Modifier.featherMask(progress: Float): Modifier = this
    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
    .drawWithContent {
        drawContent()
        val p = progress.coerceIn(0f, 1f) * 1.25f - 0.25f
        val a = p.coerceIn(0f, 1f)
        val b = (p + 0.25f).coerceIn(0f, 1f)
        drawRect(
            brush = Brush.horizontalGradient(0f to Color.Black, a to Color.Black, b to Color.Transparent, 1f to Color.Transparent, startX = 0f, endX = size.width),
            blendMode = BlendMode.DstIn
        )
    }
