package com.ayush.fetchly

import android.app.Application
import java.io.File

class FetchlyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Prefs.set("launches", (Prefs.int("launches", 0) + 1).toString())
        Fonts.load(this)
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { File(filesDir, "crash.txt").writeText(e.stackTraceToString()) } catch (_: Throwable) {}
            old?.uncaughtException(t, e)
        }
        Manager.init(this)
        Engine.startInit(this)
    }
}
