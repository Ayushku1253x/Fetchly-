package com.ayush.fetchly

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateMapOf

object Prefs {
    private lateinit var sp: SharedPreferences
    val state = mutableStateMapOf<String, String>()
    private var inited = false

    fun init(ctx: Context) {
        if (inited) return
        sp = ctx.applicationContext.getSharedPreferences("fetchly", Context.MODE_PRIVATE)
        for ((k, v) in sp.all) {
            if (v != null) state[k] = v.toString()
        }
        inited = true
    }

    fun str(key: String): String = state[key] ?: SETTINGS_BY_KEY[key]?.def ?: ""
    fun bool(key: String): Boolean = str(key) == "true"
    fun int(key: String, def: Int = 0): Int = str(key).toIntOrNull() ?: def
    fun set(key: String, value: String) {
        state[key] = value
        sp.edit().putString(key, value).apply()
    }
    fun setBool(key: String, v: Boolean) = set(key, v.toString())
    fun reset() {
        state.clear()
        sp.edit().clear().apply()
    }
}

enum class SType { TOGGLE, CHOICE, TEXT }

class SDef(
    val key: String,
    val title: String,
    val type: SType,
    val def: String,
    val section: String,
    val choices: List<String> = emptyList(),
    val desc: String = ""
)

private fun tg(key: String, title: String, def: Boolean, section: String, desc: String = "") =
    SDef(key, title, SType.TOGGLE, def.toString(), section, emptyList(), desc)

private fun ch(key: String, title: String, def: String, choices: List<String>, section: String, desc: String = "") =
    SDef(key, title, SType.CHOICE, def, section, choices, desc)

private fun tx(key: String, title: String, def: String, section: String, desc: String = "") =
    SDef(key, title, SType.TEXT, def, section, emptyList(), desc)

val ACCENT_NAMES = listOf("Blue", "Indigo", "Purple", "Pink", "Red", "Orange", "Green", "Teal")

val SETTINGS: List<SDef> by lazy { BASE_SETTINGS + ADV_SETTINGS }

private val BASE_SETTINGS: List<SDef> = listOf(
    // ---------------- Appearance ----------------
    ch("theme_mode", "Theme", "Auto", listOf("Auto", "Light", "Dark"), "Appearance"),
    ch("accent", "Accent colour", "Blue", ACCENT_NAMES, "Appearance"),
    ch("glass_strength", "Glass thickness", "Thick", listOf("Light", "Medium", "Thick", "Extra thick"), "Appearance"),
    ch("corner_style", "Corner style", "Rounder", listOf("Round", "Rounder", "Pill"), "Appearance"),
    tg("bg_blobs", "Colour blobs in background", true, "Appearance"),
    ch("blob_intensity", "Blob intensity", "Normal", listOf("Soft", "Normal", "Vivid"), "Appearance"),
    ch("ui_scale", "Text and UI size", "Default", listOf("Small", "Default", "Large", "Extra large"), "Appearance"),
    tg("animations", "Animations", true, "Appearance"),
    tg("haptics", "Haptic feedback", true, "Appearance"),
    ch("show_intro", "Welcome intro", "First 2 launches", listOf("First 2 launches", "Always", "Never"), "Appearance"),
    tg("tab_labels", "Show tab labels", true, "Appearance"),
    tg("compact_mode", "Compact mode", false, "Appearance", "Smaller spacing"),
    tg("keep_screen_on", "Keep screen on while app is open", false, "Appearance"),
    tg("fetch_thumbs", "Show thumbnails in previews", true, "Appearance"),
    tg("clipboard_detect", "Detect copied links", true, "Appearance"),
    tg("show_mini_bar", "Show download mini-bar", true, "Appearance"),
    ch("start_tab", "Screen the app opens on", "YouTube", listOf("YouTube", "Instagram", "Web", "Settings"), "Appearance"),
    tg("show_export_overlay", "Show the export screen when a download starts", true, "Appearance"),

    // ---------------- Share & Auto ----------------
    tg("share_auto", "Auto-save shared links", true, "Share & Auto", "Share a link to Fetchly from any app and it saves in the background, no taps"),
    ch("share_mode", "What to save from a shared link", "Video", listOf("Video", "Audio", "Ask me (open app)"), "Share & Auto"),
    ch("share_quality", "Quality for shared links", "Same as default", listOf("Same as default") + listOf("Best", "8K", "4K", "1440p", "1080p", "720p", "480p", "360p", "240p", "144p"), "Share & Auto"),
    tg("share_music_audio", "YouTube Music links save as audio", true, "Share & Auto"),
    tg("share_playlist", "Save the whole playlist from a shared link", false, "Share & Auto"),
    tg("share_web_video_first", "Websites: try to save the video first", true, "Share & Auto", "If there is no video, photos and media on the page are saved"),
    ch("share_web_limit", "Websites: most files to save at once", "25", listOf("10", "25", "50", "100", "All"), "Share & Auto"),
    tg("share_toast", "Show a message when saving starts", true, "Share & Auto"),
    tg("share_open_after", "Open Fetchly after sharing", false, "Share & Auto"),
    tg("share_dedupe", "Ignore the same link shared twice in a minute", true, "Share & Auto"),

    // ---------------- Downloads ----------------
    ch("save_mode", "Save location", "Auto (Movies, Music, Pictures)", listOf("Auto (Movies, Music, Pictures)", "Downloads/Fetchly", "Custom folder"), "Downloads"),
    tg("platform_subfolders", "Sub-folder per platform", true, "Downloads", "YouTube, Instagram, Web"),
    ch("filename_template", "File name", "Title", listOf("Title", "Title + ID", "Uploader - Title", "Date - Title", "ID only"), "Downloads"),
    tg("restrict_filenames", "Simple file names (ASCII only)", false, "Downloads"),
    tg("turbo", "Turbo mode (fastest)", true, "Downloads", "Max connections, no speed limit, skips slow extras like chapters and SponsorBlock"),
    ch("max_concurrent", "Downloads at the same time", "3", listOf("1", "2", "3", "4", "5", "6", "8"), "Downloads"),
    ch("fragments", "Parallel connections per download", "16", listOf("1", "2", "4", "8", "16", "32", "64"), "Downloads"),
    ch("speed_limit", "Speed limit", "Unlimited", listOf("Unlimited", "500K", "1M", "2M", "5M", "10M", "20M"), "Downloads"),
    ch("retries", "Retries", "10", listOf("3", "5", "10", "20", "50"), "Downloads"),
    tg("auto_repair", "Auto-repair failed downloads", true, "Downloads", "Retries with other methods"),
    ch("repair_attempts", "Auto-repair attempts", "4", listOf("1", "2", "3", "4", "5"), "Downloads"),
    tg("auto_check_update", "Check for app updates on start", true, "Downloads", "Shows an Update button when a new version is ready"),
    tg("auto_update_engine", "Auto-update download engine", true, "Downloads"),
    ch("update_channel", "Engine update channel", "Stable", listOf("Stable", "Nightly"), "Downloads"),
    tg("wifi_only", "Wi-Fi only", false, "Downloads"),
    tg("auto_start", "Start downloads immediately", true, "Downloads"),
    ch("overwrite", "If file exists", "Rename", listOf("Rename", "Skip existing", "Overwrite"), "Downloads"),
    tg("single_video", "Single video only (ignore playlist)", true, "Downloads"),
    tx("playlist_items", "Playlist items (example 1-5)", "", "Downloads"),
    ch("max_filesize", "Maximum file size", "None", listOf("None", "50M", "100M", "500M", "1G", "2G"), "Downloads"),
    tg("write_info_json", "Save info file (.json)", false, "Downloads"),
    tg("write_description", "Save description file", false, "Downloads"),
    tg("write_thumb_file", "Save thumbnail as separate file", false, "Downloads"),
    ch("sleep_interval", "Pause between downloads (sec)", "None", listOf("None", "1", "2", "5", "10"), "Downloads"),
    tg("use_archive", "Skip already downloaded videos", false, "Downloads"),
    tg("set_mtime", "Use upload date as file date", false, "Downloads"),
    tg("open_when_done", "Open file when finished", false, "Downloads"),
    tg("delete_partial", "Delete temporary files on failure", true, "Downloads"),
    tg("save_history", "Save download history", true, "Downloads"),

    // ---------------- Playlist and filters ----------------
    tg("pl_reverse", "Playlist in reverse order", false, "Playlist and filters"),
    tg("pl_random", "Playlist in random order", false, "Playlist and filters"),
    tg("pl_lazy", "Start playlist downloads sooner", false, "Playlist and filters"),
    tg("pl_ignore_errors", "Skip videos that fail and continue", true, "Playlist and filters"),
    tg("pl_number_files", "Number playlist files (01 - Title)", false, "Playlist and filters"),
    tg("pl_break_existing", "Stop at the first already downloaded video", false, "Playlist and filters", "Works with Skip already downloaded videos"),
    ch("pl_max_downloads", "Most videos per link", "None", listOf("None", "1", "3", "5", "10", "25", "50", "100"), "Playlist and filters"),
    ch("f_min_size", "Smallest file to download", "None", listOf("None", "100K", "500K", "1M", "5M", "20M"), "Playlist and filters"),
    ch("f_min_duration", "Shortest video", "Any", listOf("Any", "30 sec", "1 min", "5 min", "10 min", "30 min"), "Playlist and filters"),
    ch("f_max_duration", "Longest video", "Any", listOf("Any", "1 min", "5 min", "10 min", "30 min", "1 hour", "3 hours"), "Playlist and filters"),
    ch("f_min_views", "Minimum views", "Any", listOf("Any", "1000", "10000", "100000", "1000000"), "Playlist and filters"),
    ch("f_age_limit", "Age limit", "Any", listOf("Any", "13", "16", "18"), "Playlist and filters"),
    tg("f_skip_live", "Skip live streams", false, "Playlist and filters"),
    tx("f_date_after", "Uploaded after (example 20240101)", "", "Playlist and filters"),
    tx("f_date_before", "Uploaded before (example 20251231)", "", "Playlist and filters"),
    tx("f_match_custom", "Custom filter (example like_count>100)", "", "Playlist and filters"),

    // ---------------- Video ----------------
    ch("video_quality", "Default video quality", "Best", listOf("Best", "8K", "4K", "1440p", "1080p", "720p", "480p", "360p", "240p", "144p"), "Video"),
    ch("video_container", "Video format", "MP4", listOf("MP4", "MKV", "WEBM", "MOV", "Original"), "Video"),
    tg("compat_mode", "Plays in every gallery (H.264)", true, "Video", "Fixes videos that show no thumbnail. Max 1080p on YouTube, turn off for 4K and 8K"),
    tg("apple_mode", "Apple mode (iPad, iPhone, Mac)", false, "Video", "MP4 + H.264 + AAC for video, M4A for audio"),
    ch("prefer_codec", "Preferred codec", "Any", listOf("Any", "H.264 (compatible)", "VP9", "AV1", "HEVC"), "Video"),
    ch("prefer_fps", "Frame rate", "Any", listOf("Any", "Max 30fps"), "Video"),
    ch("hdr", "HDR", "Allow", listOf("Allow", "Avoid"), "Video"),
    tg("embed_thumb_video", "Embed thumbnail in video", true, "Video"),
    tg("embed_metadata", "Embed title and info", true, "Video"),
    tg("embed_chapters", "Embed chapters", true, "Video"),
    tg("subtitles", "Download subtitles", false, "Video"),
    tx("sub_langs", "Subtitle languages (example en,hi)", "en,hi", "Video"),
    ch("sub_format", "Subtitle format", "srt", listOf("srt", "vtt", "ass", "best"), "Video"),
    tg("embed_subs", "Embed subtitles in video", false, "Video"),
    tg("auto_subs", "Include auto-generated subtitles", false, "Video"),
    tg("sponsorblock", "Remove sponsor segments (YouTube)", false, "Video"),
    ch("sb_categories", "Segments to remove", "Sponsor only", listOf("Sponsor only", "Sponsor + Self-promo", "All categories"), "Video"),
    tg("sb_mark", "Mark segments as chapters instead", false, "Video"),
    tg("split_chapters", "Split video by chapters", false, "Video"),
    tg("force_keyframes", "Accurate trimming (slower)", true, "Video"),

    // ---------------- Audio ----------------
    ch("audio_format", "Default audio format", "MP3", listOf("MP3", "M4A", "OPUS", "FLAC", "WAV", "AAC", "OGG", "ALAC", "Original"), "Audio"),
    ch("audio_quality", "Audio quality", "Best", listOf("Best", "320K", "256K", "192K", "128K", "96K", "64K"), "Audio"),
    tg("audio_embed_thumb", "Embed cover art (thumbnail)", true, "Audio", "Shows the source thumbnail in your music player"),
    tg("audio_embed_meta", "Embed title and artist", true, "Audio"),
    ch("audio_source", "Audio source", "Best", listOf("Best", "M4A source", "Opus source"), "Audio"),

    // ---------------- Network ----------------
    tx("proxy", "Proxy (optional)", "", "Network"),
    tg("force_ipv4", "Force IPv4", false, "Network"),
    tg("geo_bypass", "Bypass geo restriction", true, "Network"),
    tx("geo_country", "Fake country code (example IN)", "", "Network"),
    ch("user_agent", "Browser identity", "Default", listOf("Default", "Chrome Desktop", "Chrome Android", "Safari iPhone"), "Network"),
    ch("yt_client", "YouTube client", "Auto", listOf("Auto", "android", "ios", "web", "mweb", "tv"), "Network"),
    ch("socket_timeout", "Timeout (sec)", "30", listOf("10", "20", "30", "60", "120"), "Network"),
    tg("no_check_cert", "Skip certificate check", false, "Network"),
    tg("use_cookies", "Use logged-in cookies", true, "Network"),
    ch("chunk_size", "Download chunk size", "Default", listOf("Default", "5M", "10M", "25M"), "Network"),
    ch("extractor_retries", "Page fetch retries", "3", listOf("1", "3", "5", "10"), "Network"),

    // ---------------- Notifications ----------------
    tg("notify_enabled", "Notifications", true, "Notifications"),
    tg("notify_progress", "Show progress", true, "Notifications"),
    tg("notify_done", "Notify when finished", true, "Notifications"),
    tg("notify_error", "Notify on failure", true, "Notifications"),
    tg("toast_done", "Show a message when a file is saved", false, "Notifications"),
    tg("notify_sound", "Sound", false, "Notifications"),
    tg("notify_vibrate", "Vibrate", false, "Notifications"),

    // ---------------- Privacy ----------------
    tg("incognito", "Incognito (no history)", false, "Privacy"),
    tg("secure_window", "Hide app in recent apps and screenshots", false, "Privacy"),
    tg("auto_clear_cache", "Clear cache on start", false, "Privacy"),
    tg("clear_history_exit", "Clear history on start", false, "Privacy"),
    tg("hide_thumbs_history", "Hide thumbnails in history", false, "Privacy"),

    // ---------------- Instagram ----------------
    tg("ig_original", "Always original quality", true, "Instagram", "No limits, no re-encoding"),
    tg("ig_dp_hd", "Profile photo in highest size", true, "Instagram"),
    tg("ig_caption", "Save caption as text file", false, "Instagram"),
    tg("ig_story_all", "Download all stories of a user", true, "Instagram"),
    tg("ig_audio_reel", "Reels as audio by default", false, "Instagram"),
    tg("ig_carousel_all", "All items of a multi-photo post", true, "Instagram"),
    tg("ig_name_user", "Name files username_id", false, "Instagram"),
    ch("ig_sleep", "Pause between requests (sec)", "None", listOf("None", "1", "2", "3"), "Instagram"),

    // ---------------- YouTube ----------------
    ch("yt_default_mode", "Default mode", "Video", listOf("Video", "Audio"), "YouTube"),
    tg("yt_auto_thumb", "Also save thumbnail with every download", false, "YouTube"),
    tg("yt_trim_default", "Trimming on by default", false, "YouTube"),
    ch("yt_thumb_choice", "Thumbnail size", "Largest", listOf("Largest", "1280", "640", "320"), "YouTube"),
    tg("yt_copy_toast", "Show message after copying", true, "YouTube"),

    // ---------------- Website ----------------
    ch("web_min_size", "Minimum image size", "Any", listOf("Any", "100 KB", "300 KB", "1 MB"), "Website"),
    tg("web_images", "Find images", true, "Website"),
    tg("web_videos", "Find videos", true, "Website"),
    tg("web_audio", "Find audio", true, "Website"),
    tg("web_srcset", "Pick the largest image version", true, "Website"),
    tg("web_og", "Include social preview media", true, "Website"),
    ch("web_ua", "Website browser identity", "Chrome Desktop", listOf("Chrome Desktop", "Chrome Android", "Safari iPhone"), "Website"),
    tg("web_referer", "Send referer", true, "Website"),

    // ---------------- Advanced ----------------
    tg("adv_no_part", "Write directly to the final file", false, "Advanced"),
    tg("adv_no_continue", "Do not resume partial downloads", false, "Advanced"),
    tg("adv_keep_fragments", "Keep downloaded fragments", false, "Advanced"),
    tg("adv_keep_files", "Keep original files after merging", false, "Advanced"),
    tg("adv_check_formats", "Check that formats work first (slower)", false, "Advanced"),
    tg("adv_prefer_free", "Prefer free formats", false, "Advanced"),
    tg("adv_hls_ts", "Save live streams as .ts while downloading", false, "Advanced"),
    tg("adv_write_comments", "Save comments in the info file", false, "Advanced"),
    tg("adv_write_all_thumbs", "Save every thumbnail size", false, "Advanced"),
    tg("adv_live_start", "Record live streams from the start", false, "Advanced"),
    tg("adv_no_post_overwrites", "Do not overwrite converted files", false, "Advanced"),
    ch("adv_thumb_format", "Thumbnail format", "jpg", listOf("jpg", "png"), "Advanced"),
    ch("adv_convert_subs", "Convert subtitles to", "None", listOf("None", "srt", "vtt", "ass"), "Advanced"),
    ch("adv_fixup", "Fix broken files", "Default", listOf("Default", "Never", "Warn", "Force"), "Advanced"),
    ch("adv_retry_sleep", "Wait before retry (sec)", "None", listOf("None", "1", "3", "5", "10"), "Advanced"),
    ch("adv_sleep_requests", "Pause between requests (sec)", "None", listOf("None", "0.5", "1", "2"), "Advanced"),
    ch("adv_file_retries", "File access retries", "Default", listOf("Default", "1", "5", "10", "20"), "Advanced"),
    ch("adv_wait_video", "Wait for scheduled videos (sec)", "Off", listOf("Off", "5", "30", "60"), "Advanced"),
    tg("adv_ipv6", "Force IPv6", false, "Advanced"),
    tg("adv_legacy_ssl", "Allow old secure connections", false, "Advanced"),
    tg("adv_prefer_insecure", "Prefer plain http", false, "Advanced"),
    tx("adv_referer", "Custom referer", "", "Advanced"),
    tx("adv_add_header", "Extra header (Name: value)", "", "Advanced"),
    tx("adv_extractor_args", "Extractor options (example youtube:lang=hi)", "", "Advanced"),
    tx("adv_format", "Custom format (replaces quality)", "", "Advanced"),
    tx("adv_sort", "Custom format sorting", "", "Advanced"),
    tx("adv_name_template", "Custom file name template", "", "Advanced"),
    tx("adv_args", "Extra download options (for experts)", "", "Advanced"),

    // ---------------- Audio processing ----------------
    tg("a_loudnorm", "Even out loudness", false, "Audio"),
    ch("a_samplerate", "Sample rate", "Default", listOf("Default", "22050", "44100", "48000"), "Audio"),
    ch("a_channels", "Channels", "Default", listOf("Default", "Mono", "Stereo"), "Audio")
)

val SETTINGS_BY_KEY: Map<String, SDef> = SETTINGS.associateBy { it.key }
val SECTIONS: List<String> = SETTINGS.map { it.section }.distinct()
