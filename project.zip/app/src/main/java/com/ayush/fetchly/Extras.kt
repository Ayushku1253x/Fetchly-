package com.ayush.fetchly

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.io.File

@Composable
fun SupportScreen() {
    val ctx = LocalContext.current
    val p = LocalPal.current
    val clip = LocalClipboardManager.current
    BackHandler { SettingsState.sub = "" }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        BackRow("Support")
        GlassCard {
            T("Fetchly is free", 17f, weight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            T("Made by Ayush Kumar in India. If Fetchly saves you time, you can support its development. Every bit helps.", 13f, p.sub)
        }
        GlassCard {
            Image(
                painterResource(R.drawable.support_qr), null,
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)), contentScale = ContentScale.FillWidth
            )
            Spacer(Modifier.height(10.dp))
            T("UPI ID", 12f, p.sub)
            T(Links.UPI_ID, 16f, weight = FontWeight.Medium)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton("Pay with UPI app", Modifier.weight(1f)) {
                    try {
                        val uri = Uri.parse("upi://pay?pa=" + Links.UPI_ID + "&pn=" + Uri.encode(Links.UPI_NAME) + "&cu=INR")
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Throwable) {
                        Util.toast(ctx, "No UPI app found. Scan the QR from another phone or copy the ID.")
                    }
                }
                SoftButton("Copy ID", Modifier.weight(1f)) {
                    clip.setText(AnnotatedString(Links.UPI_ID))
                    Util.toast(ctx, "UPI ID copied")
                }
            }
        }
        if (Links.YOUTUBE.isNotBlank() || Links.TELEGRAM.isNotBlank()) {
            GlassCard {
                if (Links.YOUTUBE.isNotBlank()) ActionRow("Join our YouTube channel") { Util.openLink(ctx, Links.YOUTUBE) }
                if (Links.TELEGRAM.isNotBlank()) ActionRow("Join our Telegram channel") { Util.openLink(ctx, Links.TELEGRAM) }
            }
        }
        GlassCard {
            ActionRow("Share Fetchly with friends") {
                val text = "Try Fetchly, a free video, music and photo downloader." + (if (Links.APP_LINK.isNotBlank()) " " + Links.APP_LINK else "")
                try {
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                    ctx.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Throwable) {}
            }
            ActionRow("Report a problem", "Copies the last error so you can send it") {
                val f = File(ctx.filesDir, "crash.txt")
                clip.setText(AnnotatedString(if (f.exists()) f.readText() else "No crash report. Version " + Updater.currentName(ctx)))
                Util.toast(ctx, "Copied")
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun AppleScreen() {
    val p = LocalPal.current
    BackHandler { SettingsState.sub = "" }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        BackRow("iPad and iPhone")
        GlassCard {
            T("Files that open on Apple devices", 17f, weight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            T("Turn on Apple mode and Fetchly saves MP4 (H.264 + AAC) for video and M4A for audio, which open in Photos, Files and Music on iPad, iPhone and Mac.", 13f, p.sub)
            Spacer(Modifier.height(8.dp))
            PrefToggle("Apple mode (iPad, iPhone, Mac)", "apple_mode")
            PrefToggle("Plays in every gallery (H.264)", "compat_mode", "Fixes videos that show no thumbnail. Max 1080p on YouTube")
        }
        GlassCard {
            T("Video", 12f, p.sub)
            T("MP4, M4V, MOV (H.264 or HEVC video with AAC audio)", 14f)
            Spacer(Modifier.height(10.dp))
            T("Audio", 12f, p.sub)
            T("M4A (AAC), MP3, AAC, ALAC, WAV, AIFF", 14f)
            Spacer(Modifier.height(10.dp))
            T("Images", 12f, p.sub)
            T("JPG, PNG, HEIC, GIF, TIFF, WebP (iOS 14 and newer)", 14f)
            Spacer(Modifier.height(10.dp))
            T("Usually do not open", 12f, p.sub)
            T("WEBM, MKV, OGG, OPUS, AV1 video on older devices", 14f)
        }
        Spacer(Modifier.height(24.dp))
    }
}
