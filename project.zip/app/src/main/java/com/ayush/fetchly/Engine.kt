package com.ayush.fetchly

import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File

class Fmt(val id: String, val ext: String, val height: Int, val fps: Int, val vcodec: String, val acodec: String, val size: Long)
class Thumb(val url: String, val w: Int, val h: Int)

class MediaInfo(
    val url: String,
    val id: String,
    val title: String,
    val uploader: String,
    val duration: Int,
    val thumb: String?,
    val thumbs: List<Thumb>,
    val description: String,
    val tags: List<String>,
    val heights: List<Int>,
    val formats: List<Fmt>,
    val extractor: String,
    val playlistCount: Int,
    val webUrl: String
)

class DlOptions(
    val site: String,
    val audioOnly: Boolean,
    val height: Int?,
    val container: String,
    val audioFormat: String,
    val audioQuality: String,
    val trimStart: String = "",
    val trimEnd: String = "",
    val playlist: Boolean = false
)

object Cookies {
    fun file(ctx: Context, site: String) = File(ctx.filesDir, "cookies_$site.txt")

    fun has(ctx: Context, site: String): Boolean {
        val f = file(ctx, site)
        return f.exists() && f.length() > 60
    }

    fun saveFromWebView(ctx: Context, site: String, urls: List<String>): Int {
        val cm = CookieManager.getInstance()
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        var count = 0
        for (u in urls) {
            val raw = cm.getCookie(u) ?: continue
            val host = Uri.parse(u).host ?: continue
            val domain = "." + host.removePrefix("www.")
            for (pair in raw.split(";")) {
                val i = pair.indexOf('=')
                if (i > 0) {
                    val n = pair.substring(0, i).trim()
                    val v = pair.substring(i + 1).trim()
                    sb.append(domain).append("\tTRUE\t/\tTRUE\t2147483647\t").append(n).append('\t').append(v).append('\n')
                    count++
                }
            }
        }
        file(ctx, site).writeText(sb.toString())
        return count
    }

    fun merged(ctx: Context): File? {
        val parts = listOf("instagram", "youtube").map { file(ctx, it) }.filter { it.exists() && it.length() > 60 }
        if (parts.isEmpty()) return null
        val out = File(ctx.filesDir, "cookies_all.txt")
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        for (p in parts) {
            for (line in p.readLines()) {
                if (line.isNotBlank() && !line.startsWith("#")) sb.append(line).append('\n')
            }
        }
        out.writeText(sb.toString())
        return out
    }

    fun header(ctx: Context, domain: String): String? {
        val f = file(ctx, if (domain.contains("instagram")) "instagram" else "youtube")
        if (!f.exists()) return null
        val parts = ArrayList<String>()
        for (line in f.readLines()) {
            val cols = line.split("\t")
            if (cols.size >= 7 && cols[0].contains(domain)) parts.add(cols[5] + "=" + cols[6])
        }
        return if (parts.isEmpty()) null else parts.joinToString("; ")
    }

    fun clear(ctx: Context) {
        listOf("instagram", "youtube").forEach { file(ctx, it).delete() }
        File(ctx.filesDir, "cookies_all.txt").delete()
        try { CookieManager.getInstance().removeAllCookies(null) } catch (_: Throwable) {}
    }
}

object Engine {
    var status by mutableStateOf("Starting engine...")
    var version by mutableStateOf("")
    @Volatile
    var ready = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun startInit(ctx: Context) {
        scope.launch {
            try {
                YoutubeDL.getInstance().init(ctx)
                try { FFmpeg.getInstance().init(ctx) } catch (_: Throwable) {}
                ready = true
                status = "Ready"
                version = versionString(ctx)
                if (Prefs.bool("auto_update_engine")) {
                    status = "Updating engine..."
                    update(ctx)
                    version = versionString(ctx)
                    status = "Ready"
                }
            } catch (t: Throwable) {
                status = "Engine error: " + (t.message ?: t.toString())
            }
        }
    }

    fun updateAsync(ctx: Context, done: (String) -> Unit) {
        scope.launch {
            status = "Updating engine..."
            val r = update(ctx)
            version = versionString(ctx)
            status = "Ready"
            done(r)
        }
    }

    // Uses reflection so it works with every version of the library.
    fun update(ctx: Context): String {
        return try {
            val yd = YoutubeDL.getInstance()
            val ms = yd.javaClass.methods.filter { it.name == "updateYoutubeDL" }.sortedBy { it.parameterTypes.size }
            var res = "Update method not found"
            for (m in ms) {
                try {
                    val r: Any? = when (m.parameterTypes.size) {
                        1 -> m.invoke(yd, ctx)
                        2 -> m.invoke(yd, ctx, channelObj(m.parameterTypes[1]))
                        else -> null
                    }
                    res = r?.toString() ?: "Updated"
                    break
                } catch (t: Throwable) {
                    res = t.cause?.message ?: t.message ?: "Update failed"
                }
            }
            res
        } catch (t: Throwable) {
            t.message ?: "Update failed"
        }
    }

    private fun channelObj(c: Class<*>): Any? {
        val wanted = if (Prefs.str("update_channel") == "Nightly") listOf("NIGHTLY", "_NIGHTLY") else listOf("STABLE", "_STABLE")
        for (n in wanted) {
            try { return c.getField(n).get(null) } catch (_: Throwable) {}
        }
        for (n in wanted) {
            try {
                val k = c.classes.firstOrNull { it.simpleName.equals(n.trim('_'), true) }
                if (k != null) return k.getField("INSTANCE").get(null)
            } catch (_: Throwable) {}
        }
        try {
            if (c.isEnum) return c.enumConstants?.firstOrNull { it.toString().equals(wanted[0], true) }
        } catch (_: Throwable) {}
        return null
    }

    fun versionString(ctx: Context): String {
        return try {
            val yd = YoutubeDL.getInstance()
            val m = yd.javaClass.methods.firstOrNull { it.name == "version" }
            val r: Any? = if (m == null) null else if (m.parameterTypes.size == 1) m.invoke(yd, ctx) else m.invoke(yd)
            r?.toString() ?: ""
        } catch (t: Throwable) {
            ""
        }
    }

    fun cancel(processId: String) {
        try { YoutubeDL.getInstance().destroyProcessById(processId) } catch (_: Throwable) {}
    }

    private fun uaFor(key: String): String? = when (key) {
        "Chrome Desktop" -> Http.UA_DESKTOP
        "Chrome Android" -> Http.UA_ANDROID
        "Safari iPhone" -> Http.UA_IPHONE
        else -> null
    }

    // Arguments shared by "fetch info" and "download".
    private fun commonArgs(r: YoutubeDLRequest, ctx: Context, attempt: Int) {
        r.addOption("--no-warnings")
        r.addOption("--socket-timeout", Prefs.str("socket_timeout"))
        r.addOption("--extractor-retries", Prefs.str("extractor_retries"))
        val px = Prefs.str("proxy").trim()
        if (px.isNotEmpty()) r.addOption("--proxy", px)
        if (Prefs.bool("force_ipv4")) r.addOption("-4")
        if (Prefs.bool("geo_bypass")) r.addOption("--geo-bypass")
        val gc = Prefs.str("geo_country").trim()
        if (gc.isNotEmpty()) r.addOption("--xff", gc)
        uaFor(Prefs.str("user_agent"))?.let { r.addOption("--user-agent", it) }
        if (Prefs.bool("no_check_cert")) r.addOption("--no-check-certificates")
        if (Prefs.bool("use_cookies")) {
            Cookies.merged(ctx)?.let { r.addOption("--cookies", it.absolutePath) }
        }
        val client = Prefs.str("yt_client")
        if (client != "Auto" && attempt == 0) r.addOption("--extractor-args", "youtube:player_client=$client")
        // Auto-repair strategies
        when (attempt) {
            2 -> r.addOption("--extractor-args", "youtube:player_client=ios")
            3 -> {
                r.addOption("--extractor-args", "youtube:player_client=tv,mweb")
                r.addOption("-4")
            }
            4 -> {
                r.addOption("--extractor-args", "youtube:player_client=android,web")
                r.addOption("--geo-bypass")
                r.addOption("--no-check-certificates")
            }
            5 -> {
                r.addOption("--extractor-args", "youtube:player_client=web_safari,mweb")
                r.addOption("-4")
            }
        }
    }

    fun fetchInfo(ctx: Context, url: String, playlist: Boolean, flat: Boolean, attempt: Int): MediaInfo {
        if (!ready) throw Exception("Engine is still starting. Wait a few seconds and try again.")
        val r = YoutubeDLRequest(url)
        r.addOption("-J")
        if (playlist) {
            r.addOption("--yes-playlist")
            if (flat) r.addOption("--flat-playlist")
        } else {
            r.addOption("--no-playlist")
        }
        commonArgs(r, ctx, attempt)
        val resp = YoutubeDL.getInstance().execute(r)
        return parse(url, resp.out)
    }

    fun fetchInfoRetry(ctx: Context, url: String, playlist: Boolean, flat: Boolean): MediaInfo {
        val max = if (Prefs.bool("auto_repair")) Prefs.int("repair_attempts", 4).coerceIn(1, 6) else 1
        var last: Throwable? = null
        for (a in 0 until max) {
            try {
                if (a == 1) update(ctx)
                return fetchInfo(ctx, url, playlist, flat, a)
            } catch (t: Throwable) {
                last = t
            }
        }
        throw last ?: Exception("Could not fetch info")
    }

    private fun JSONObject.s(k: String): String = if (isNull(k)) "" else optString(k, "")

    fun parse(url: String, json: String): MediaInfo {
        var o = JSONObject(json.trim())
        var count = 0
        val entries = o.optJSONArray("entries")
        if (entries != null && entries.length() > 0) {
            count = entries.length()
            val first = entries.optJSONObject(0)
            if (first != null) {
                // keep playlist title if the first entry has none
                val pt = o.s("title")
                o = first
                if (o.s("title").isEmpty() && pt.isNotEmpty()) o.put("title", pt)
            }
        }
        val thumbs = ArrayList<Thumb>()
        val ta = o.optJSONArray("thumbnails")
        if (ta != null) {
            for (i in 0 until ta.length()) {
                val t = ta.optJSONObject(i) ?: continue
                val u = t.s("url")
                if (u.isNotEmpty()) thumbs.add(Thumb(u, t.optInt("width", 0), t.optInt("height", 0)))
            }
        }
        val sorted = thumbs.filter { it.w > 0 }.sortedByDescending { it.w }
        val mainThumb: String? = (sorted.firstOrNull()?.url) ?: o.s("thumbnail").ifEmpty { thumbs.lastOrNull()?.url ?: "" }.ifEmpty { null }
        val fmts = ArrayList<Fmt>()
        val fa = o.optJSONArray("formats")
        if (fa != null) {
            for (i in 0 until fa.length()) {
                val f = fa.optJSONObject(i) ?: continue
                val size = if (f.has("filesize") && !f.isNull("filesize")) f.optLong("filesize", 0) else f.optLong("filesize_approx", 0)
                fmts.add(Fmt(f.s("format_id"), f.s("ext"), f.optInt("height", 0), f.optInt("fps", 0), f.s("vcodec"), f.s("acodec"), size))
            }
        }
        val heights = fmts.filter { it.vcodec != "none" && it.vcodec.isNotEmpty() && it.height > 0 }.map { it.height }.distinct().sortedDescending()
        val tags = ArrayList<String>()
        val tg = o.optJSONArray("tags")
        if (tg != null) for (i in 0 until tg.length()) tags.add(tg.optString(i))
        return MediaInfo(
            url = url,
            id = o.s("id"),
            title = o.s("title").ifEmpty { o.s("fulltitle") },
            uploader = o.s("uploader").ifEmpty { o.s("channel") },
            duration = o.optInt("duration", 0),
            thumb = mainThumb,
            thumbs = sorted.ifEmpty { thumbs },
            description = o.s("description"),
            tags = tags,
            heights = heights,
            formats = fmts,
            extractor = o.s("extractor_key"),
            playlistCount = count,
            webUrl = o.s("webpage_url")
        )
    }

    private fun template(p: Boolean, site: String = ""): String {
        val custom = Prefs.str("adv_name_template").trim()
        if (custom.isNotEmpty()) return custom
        if (site == "instagram" && Prefs.bool("ig_name_user")) return "%(uploader)s_%(id)s"
        if (p) return (if (Prefs.bool("pl_number_files")) "%(playlist_index)s - " else "") + "%(title).100B [%(id)s]"
        return when (Prefs.str("filename_template")) {
            "Title + ID" -> "%(title).120B [%(id)s]"
            "Uploader - Title" -> "%(uploader).60B - %(title).120B"
            "Date - Title" -> "%(upload_date)s - %(title).150B"
            "ID only" -> "%(id)s"
            else -> "%(title).150B"
        }
    }

    private val TIME_RE = Regex("^\\d{1,2}(:\\d{1,2}){0,2}(\\.\\d+)?$")

    fun download(
        ctx: Context, url: String, o: DlOptions, dir: File, processId: String, attempt: Int,
        onProgress: (Float, Long, String) -> Unit
    ) {
        if (!ready) throw Exception("Engine is still starting. Wait a few seconds and try again.")
        val safe = attempt >= 2
        val r = YoutubeDLRequest(url)
        commonArgs(r, ctx, attempt)
        r.addOption("--newline")
        r.addOption("--windows-filenames")
        if (Prefs.bool("restrict_filenames")) r.addOption("--restrict-filenames")
        r.addOption("-o", dir.absolutePath + "/" + template(o.playlist, o.site) + ".%(ext)s")
        if (o.playlist) {
            r.addOption("--yes-playlist")
            val pi = Prefs.str("playlist_items").trim()
            if (pi.isNotEmpty()) r.addOption("--playlist-items", pi)
        } else {
            r.addOption("--no-playlist")
        }
        val turbo = Prefs.bool("turbo")
        val lite = safe || turbo
        val apple = Prefs.bool("apple_mode")
        r.addOption("-N", if (turbo) "64" else Prefs.str("fragments"))
        val rl = Prefs.str("speed_limit")
        if (!turbo && rl != "Unlimited") r.addOption("-r", rl)
        if (turbo) {
            r.addOption("--throttled-rate", "100K")
            r.addOption("--buffer-size", "1M")
        }
        r.addOption("--retries", Prefs.str("retries"))
        r.addOption("--fragment-retries", Prefs.str("retries"))
        when (Prefs.str("overwrite")) {
            "Skip existing" -> r.addOption("--no-overwrites")
            "Overwrite" -> r.addOption("--force-overwrites")
        }
        val ms = Prefs.str("max_filesize")
        if (ms != "None") r.addOption("--max-filesize", ms)
        if (Prefs.bool("write_info_json")) r.addOption("--write-info-json")
        if (Prefs.bool("write_description") || (o.site == "instagram" && Prefs.bool("ig_caption"))) r.addOption("--write-description")
        if (Prefs.bool("write_thumb_file") || (o.site == "youtube" && Prefs.bool("yt_auto_thumb"))) r.addOption("--write-thumbnail")
        val sl = Prefs.str("sleep_interval")
        if (sl != "None" && !turbo) r.addOption("--sleep-interval", sl)
        if (Prefs.bool("use_archive")) r.addOption("--download-archive", File(ctx.filesDir, "archive.txt").absolutePath)
        if (!Prefs.bool("set_mtime")) r.addOption("--no-mtime")
        val ck = Prefs.str("chunk_size")
        if (ck != "Default") r.addOption("--http-chunk-size", ck) else if (turbo) r.addOption("--http-chunk-size", "10M")
        Adv.apply(r, o, lite)

        if (o.audioOnly) {
            val src = when (Prefs.str("audio_source")) {
                "M4A source" -> "ba[ext=m4a]/ba/b"
                "Opus source" -> "ba[ext=webm]/ba/b"
                else -> "ba/b"
            }
            r.addOption("-f", src)
            r.addOption("-x")
            val fmt0 = when (o.audioFormat) {
                "MP3" -> "mp3"
                "M4A" -> "m4a"
                "OPUS" -> "opus"
                "FLAC" -> "flac"
                "WAV" -> "wav"
                "AAC" -> "aac"
                "OGG" -> "vorbis"
                "ALAC" -> "alac"
                else -> "best"
            }
            val fmt = if (apple && fmt0 !in listOf("mp3", "m4a", "aac", "alac", "wav")) "m4a" else fmt0
            r.addOption("--audio-format", fmt)
            val lossy = fmt in listOf("mp3", "m4a", "opus", "aac", "vorbis")
            if (o.audioQuality != "Best" && lossy) r.addOption("--audio-quality", o.audioQuality)
            if (Prefs.bool("audio_embed_thumb") && !safe && fmt != "wav" && fmt != "best") {
                r.addOption("--embed-thumbnail")
                r.addOption("--convert-thumbnails", Adv.thumbFmt())
            }
            if (Prefs.bool("audio_embed_meta")) r.addOption("--embed-metadata")
        } else {
            val h = if (o.height != null && !(o.site == "instagram" && Prefs.bool("ig_original"))) "[height<=${o.height}]" else ""
            val hdr = if (Prefs.str("hdr") == "Avoid") "[dynamic_range?=SDR]" else ""
            val fps = if (Prefs.str("prefer_fps") == "Max 30fps") "[fps?<=30]" else ""
            r.addOption("-f", "bv*$h$hdr$fps+ba/b$h")
            val container = if (apple && o.container in listOf("MKV", "WEBM", "Original")) "MP4" else o.container
            val codec0 = when (Prefs.str("prefer_codec")) {
                "H.264 (compatible)" -> "vcodec:h264,acodec:m4a"
                "VP9" -> "vcodec:vp9"
                "AV1" -> "vcodec:av01"
                "HEVC" -> "vcodec:hevc"
                else -> ""
            }
            val codec = if (apple && (codec0.contains("vp9") || codec0.contains("av01"))) "" else codec0
            val compat = apple || Prefs.bool("compat_mode")
            if (codec.isNotEmpty()) r.addOption("-S", "res,$codec")
            else if (compat && container != "WEBM") r.addOption("-S", "vcodec:h264,res,ext:mp4:m4a")
            else if (container == "MP4") r.addOption("-S", "res,ext:mp4:m4a")
            when (container) {
                "MOV" -> r.addOption("--merge-output-format", "mov")
                "MP4" -> r.addOption("--merge-output-format", "mp4")
                "MKV" -> r.addOption("--merge-output-format", "mkv")
                "WEBM" -> r.addOption("--merge-output-format", "webm")
            }
            if (Prefs.bool("embed_thumb_video") && !safe && container != "WEBM") {
                r.addOption("--embed-thumbnail")
                r.addOption("--convert-thumbnails", Adv.thumbFmt())
            }
            if (Prefs.bool("embed_metadata")) r.addOption("--embed-metadata")
            if (Prefs.bool("embed_chapters") && !lite) r.addOption("--embed-chapters")
            if (Prefs.bool("subtitles")) {
                r.addOption("--write-subs")
                if (Prefs.bool("auto_subs")) r.addOption("--write-auto-subs")
                val langs = Prefs.str("sub_langs").trim()
                if (langs.isNotEmpty()) r.addOption("--sub-langs", langs)
                val sf = Prefs.str("sub_format")
                r.addOption("--sub-format", if (sf == "best") "best" else "$sf/best")
                if (Prefs.bool("embed_subs") && !safe) r.addOption("--embed-subs")
            }
            if (Prefs.bool("split_chapters") && !lite) r.addOption("--split-chapters")
        }
        if (o.site == "youtube" && !lite) {
            val cat = when (Prefs.str("sb_categories")) {
                "Sponsor + Self-promo" -> "sponsor,selfpromo"
                "All categories" -> "all"
                else -> "sponsor"
            }
            if (Prefs.bool("sponsorblock")) {
                if (Prefs.bool("sb_mark")) r.addOption("--sponsorblock-mark", cat) else r.addOption("--sponsorblock-remove", cat)
            }
        }
        val ts = o.trimStart.trim()
        val te = o.trimEnd.trim()
        if (!safe && (ts.isNotEmpty() || te.isNotEmpty())) {
            val a = if (ts.isEmpty()) "0" else ts
            val b = if (te.isEmpty()) "inf" else te
            if (TIME_RE.matches(a) && (b == "inf" || TIME_RE.matches(b))) {
                r.addOption("--download-sections", "*$a-$b")
                if (Prefs.bool("force_keyframes") && !turbo) r.addOption("--force-keyframes-at-cuts")
            }
        }
        Adv.late(r, o)
        YoutubeDL.getInstance().execute(r, processId) { p, e, l -> onProgress(p, e.toLong(), l ?: "") }
    }

    fun friendly(msg: String): String {
        val m = msg.trim()
        val low = m.lowercase()
        val line = m.lines().lastOrNull { it.contains("ERROR", true) } ?: m.lines().lastOrNull { it.isNotBlank() } ?: m
        val clean = line.replace("ERROR:", "").replace(Regex("\\[[^\\]]+\\]"), "").trim().take(220)
        return when {
            "sign in to confirm" in low || "not a bot" in low -> "YouTube wants a login check. Open Settings > Login YouTube, then try again."
            "login required" in low || "rate-limit" in low || "empty media response" in low || "private" in low && "instagram" in low -> "Instagram needs a login for this. Open Settings > Login Instagram, then try again."
            "requested format is not available" in low -> "That quality is not available. Choose Best and try again."
            "unsupported url" in low -> "This link is not supported."
            "ffmpeg" in low && "not found" in low -> "Media tools are missing. Update the engine in Settings."
            "unable to resolve host" in low || "network is unreachable" in low || "timed out" in low -> "No internet connection."
            else -> clean.ifEmpty { "Download failed" }
        }
    }
}
