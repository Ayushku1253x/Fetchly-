package com.ayush.fetchly

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

enum class DStatus { QUEUED, FETCHING, DOWNLOADING, PROCESSING, SAVING, DONE, FAILED, CANCELED }

class DlItem(val id: String, val title: String, val url: String, val thumb: String?, val kind: String, val site: String) {
    var status by mutableStateOf(DStatus.QUEUED)
    var progress by mutableStateOf(0f)
    var eta by mutableStateOf(-1L)
    var speed by mutableStateOf("")
    var message by mutableStateOf("")
    var savedUri by mutableStateOf("")
    var mime by mutableStateOf("")
    var samples by mutableStateOf(listOf<Float>())
    @Volatile
    var canceled = false
    val processId: String = id
    var runner: (suspend (DlItem) -> Unit)? = null

    fun isActive() = status == DStatus.FETCHING || status == DStatus.DOWNLOADING || status == DStatus.PROCESSING || status == DStatus.SAVING
    fun isFinished() = status == DStatus.DONE || status == DStatus.FAILED || status == DStatus.CANCELED
}

class HistItem(
    val id: String, val title: String, val site: String, val kind: String, val uri: String,
    val mime: String, val size: Long, val time: Long, val thumb: String, val url: String
)

object History {
    val items = mutableStateListOf<HistItem>()
    private var file: File? = null

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "history.json")
        if (Prefs.bool("clear_history_exit")) {
            file?.delete()
            return
        }
        try {
            val f = file ?: return
            if (!f.exists()) return
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(
                    HistItem(
                        o.optString("id"), o.optString("title"), o.optString("site"), o.optString("kind"),
                        o.optString("uri"), o.optString("mime"), o.optLong("size"), o.optLong("time"),
                        o.optString("thumb"), o.optString("url")
                    )
                )
            }
        } catch (_: Throwable) {}
    }

    fun add(h: HistItem) {
        if (Prefs.bool("incognito") || !Prefs.bool("save_history")) return
        items.add(0, h)
        save()
    }

    fun remove(h: HistItem) {
        items.remove(h)
        save()
    }

    fun clear() {
        items.clear()
        save()
    }

    private fun save() {
        try {
            val arr = JSONArray()
            for (h in items) {
                val o = JSONObject()
                o.put("id", h.id); o.put("title", h.title); o.put("site", h.site); o.put("kind", h.kind)
                o.put("uri", h.uri); o.put("mime", h.mime); o.put("size", h.size); o.put("time", h.time)
                o.put("thumb", h.thumb); o.put("url", h.url)
                arr.put(o)
            }
            file?.writeText(arr.toString())
        } catch (_: Throwable) {}
    }
}

object Saver {
    private val EXT_MIME = mapOf(
        "mkv" to "video/x-matroska", "webm" to "video/webm", "mp4" to "video/mp4", "mov" to "video/quicktime",
        "mp3" to "audio/mpeg", "m4a" to "audio/mp4", "opus" to "audio/ogg", "ogg" to "audio/ogg",
        "flac" to "audio/flac", "wav" to "audio/x-wav", "aac" to "audio/aac",
        "jpg" to "image/jpeg", "jpeg" to "image/jpeg", "png" to "image/png", "webp" to "image/webp", "gif" to "image/gif",
        "srt" to "application/x-subrip", "vtt" to "text/vtt", "json" to "application/json", "description" to "text/plain"
    )

    fun mimeOf(f: File): String {
        val e = f.extension.lowercase()
        return EXT_MIME[e] ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(e) ?: "application/octet-stream"
    }

    fun save(ctx: Context, f: File, site: String): Pair<String, String> {
        val mime = mimeOf(f)
        val mode = Prefs.str("save_mode")
        val sub = if (Prefs.bool("platform_subfolders")) "/" + site.replaceFirstChar { it.uppercase() } else ""
        val kind = when {
            mime.startsWith("video") -> "video"
            mime.startsWith("audio") -> "audio"
            mime.startsWith("image") -> "image"
            else -> "other"
        }

        if (mode == "Custom folder") {
            val tree = Prefs.str("custom_tree")
            if (tree.isNotEmpty()) {
                try {
                    var dir = DocumentFile.fromTreeUri(ctx, Uri.parse(tree))
                    if (dir != null && sub.isNotEmpty()) {
                        val name = sub.removePrefix("/")
                        dir = dir.findFile(name) ?: dir.createDirectory(name)
                    }
                    if (dir != null) {
                        val target = dir.createFile(mime, f.nameWithoutExtension)
                        if (target != null) {
                            ctx.contentResolver.openOutputStream(target.uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
                            return Pair(target.uri.toString(), mime)
                        }
                    }
                } catch (_: Throwable) {}
            }
        }

        val downloads = mode == "Downloads/Fetchly"
        val base = if (downloads) "Download/Fetchly" else when (kind) {
            "video" -> "Movies/Fetchly"
            "audio" -> "Music/Fetchly"
            "image" -> "Pictures/Fetchly"
            else -> "Download/Fetchly"
        }
        val rel = base + sub

        if (Build.VERSION.SDK_INT >= 29) {
            val collection: Uri = if (downloads) MediaStore.Downloads.EXTERNAL_CONTENT_URI else when (kind) {
                "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                "image" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI
            }
            val values = ContentValues()
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
            values.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val uri = ctx.contentResolver.insert(collection, values) ?: throw Exception("Could not create file in storage")
            ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            val done = ContentValues()
            done.put(MediaStore.MediaColumns.IS_PENDING, 0)
            ctx.contentResolver.update(uri, done, null, null)
            return Pair(uri.toString(), mime)
        } else {
            val root = when {
                downloads || kind == "other" -> Environment.DIRECTORY_DOWNLOADS
                kind == "video" -> Environment.DIRECTORY_MOVIES
                kind == "audio" -> Environment.DIRECTORY_MUSIC
                else -> Environment.DIRECTORY_PICTURES
            }
            val dir = File(Environment.getExternalStoragePublicDirectory(root), "Fetchly" + sub)
            dir.mkdirs()
            val target = File(dir, f.name)
            f.inputStream().use { i -> target.outputStream().use { o -> i.copyTo(o) } }
            MediaScannerConnection.scanFile(ctx, arrayOf(target.absolutePath), arrayOf(mime), null)
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".provider", target)
            return Pair(uri.toString(), mime)
        }
    }
}

object Notifier {
    const val CH = "fetchly_dl"
    private var counter = 2000

    fun channel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CH) == null) {
                nm.createNotificationChannel(NotificationChannel(CH, "Downloads", NotificationManager.IMPORTANCE_LOW))
            }
        }
    }

    fun canNotify(ctx: Context): Boolean {
        if (!Prefs.bool("notify_enabled")) return false
        if (Build.VERSION.SDK_INT >= 33) {
            return ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        }
        return true
    }

    fun build(ctx: Context, title: String, text: String, progress: Int, ongoing: Boolean): Notification {
        channel(ctx)
        val open = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = android.app.PendingIntent.getActivity(ctx, 0, open, android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
        val b = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setSilent(!Prefs.bool("notify_sound"))
        if (progress in 0..100 && Prefs.bool("notify_progress")) b.setProgress(100, progress, false)
        if (Prefs.bool("notify_vibrate")) b.setVibrate(longArrayOf(0, 200))
        return b.build()
    }

    fun progress(ctx: Context, text: String, pct: Int) {
        if (!canNotify(ctx)) return
        try { NotificationManagerCompat.from(ctx).notify(1, build(ctx, "Fetchly", text, pct, true)) } catch (_: Throwable) {}
    }

    fun finished(ctx: Context, title: String, ok: Boolean, msg: String) {
        if (ok && Prefs.bool("toast_done")) toastMain(ctx, "Saved: $title")
        if (!canNotify(ctx)) return
        if (ok && !Prefs.bool("notify_done")) return
        if (!ok && !Prefs.bool("notify_error")) return
        try {
            counter++
            NotificationManagerCompat.from(ctx).notify(counter, build(ctx, if (ok) "Saved" else "Failed", if (ok) title else "$title: $msg", -1, false))
        } catch (_: Throwable) {}
    }
}

class DownloadService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val n = Notifier.build(this, "Fetchly", "Downloading...", -1, true)
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(1, n)
            }
        } catch (_: Throwable) {}
        return START_NOT_STICKY
    }
}

object Manager {
    val items = mutableStateListOf<DlItem>()
    var overlay by mutableStateOf(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Any()
    private var active = 0
    private lateinit var app: Context
    private var lastNotify = 0L

    fun init(ctx: Context) {
        app = ctx.applicationContext
        Notifier.channel(app)
        History.init(app)
        try {
            val d = File(app.cacheDir, "dl")
            if (Prefs.bool("auto_clear_cache") || d.exists()) d.deleteRecursively()
        } catch (_: Throwable) {}
    }

    fun clearCache(ctx: Context): String {
        var n = 0L
        try {
            val d = File(ctx.cacheDir, "dl")
            if (d.exists()) { n = d.walk().filter { it.isFile }.sumOf { it.length() }; d.deleteRecursively() }
        } catch (_: Throwable) {}
        return Util.size(n).ifEmpty { "0 KB" }
    }

    private fun newId(): String = UUID.randomUUID().toString().take(12)

    fun activeCount(): Int = items.count { it.isActive() }

    fun enqueueYt(ctx: Context, info: MediaInfo, o: DlOptions) {
        val kind = if (o.audioOnly) "audio" else "video"
        val title = info.title.ifBlank { info.url }
        val item = DlItem(newId(), title, info.url, info.thumb, kind, o.site)
        item.runner = { it -> runYt(it, info.url, o) }
        add(item)
    }

    fun enqueueDirect(ctx: Context, urls: List<String>, referer: String?, title: String, site: String, kind: String) {
        for ((i, u) in urls.withIndex()) {
            val name = if (urls.size > 1) "$title ${i + 1}" else title
            val item = DlItem(newId(), name, u, if (kind == "image") u else null, kind, site)
            item.runner = { it -> runDirect(it, u, referer) }
            add(item)
        }
    }

    private fun add(item: DlItem) {
        items.add(0, item)
        if (Prefs.bool("show_export_overlay")) overlay = true
        if (Prefs.bool("auto_start")) schedule(item) else item.message = "Waiting. Tap Start."
    }

    fun start(item: DlItem) {
        if (item.status == DStatus.QUEUED) schedule(item)
    }

    fun retry(item: DlItem) {
        item.canceled = false
        item.status = DStatus.QUEUED
        item.progress = 0f
        item.message = ""
        schedule(item)
    }

    fun cancel(item: DlItem) {
        item.canceled = true
        Engine.cancel(item.processId)
        if (item.status == DStatus.QUEUED) {
            item.status = DStatus.CANCELED
            item.message = "Cancelled"
        }
    }

    fun remove(item: DlItem) {
        if (item.isActive()) cancel(item)
        items.remove(item)
    }

    fun clearFinished() {
        items.removeAll { it.isFinished() }
    }

    private fun tryAcquire(): Boolean = synchronized(lock) {
        val max = Prefs.int("max_concurrent", 2).coerceAtLeast(1)
        if (active < max) { active++; true } else false
    }

    private fun release() {
        val now = synchronized(lock) { active--; active }
        if (now <= 0) {
            try { app.stopService(Intent(app, DownloadService::class.java)) } catch (_: Throwable) {}
        }
    }

    private fun onWifi(): Boolean {
        return try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
        } catch (_: Throwable) { true }
    }

    private fun schedule(item: DlItem) {
        scope.launch {
            item.status = DStatus.QUEUED
            item.message = "Waiting in queue"
            while (!tryAcquire()) {
                if (item.canceled) { item.status = DStatus.CANCELED; item.message = "Cancelled"; return@launch }
                delay(400)
            }
            try {
                if (activeNow() == 1) {
                    try { ContextCompat.startForegroundService(app, Intent(app, DownloadService::class.java)) } catch (_: Throwable) {}
                }
                if (Prefs.bool("wifi_only") && !onWifi()) {
                    item.status = DStatus.FAILED
                    item.message = "Wi-Fi only is on. Connect to Wi-Fi and tap Retry."
                    return@launch
                }
                if (item.canceled) { item.status = DStatus.CANCELED; item.message = "Cancelled"; return@launch }
                item.runner?.invoke(item)
            } catch (t: Throwable) {
                if (!item.isFinished()) {
                    item.status = DStatus.FAILED
                    item.message = Engine.friendly(t.message ?: t.toString())
                }
            } finally {
                release()
            }
        }
    }

    private fun activeNow(): Int = synchronized(lock) { active }

    private fun tick(item: DlItem, pct: Float, eta: Long, speed: String) {
        item.progress = pct.coerceIn(0f, 100f)
        item.eta = eta
        if (speed.isNotEmpty()) {
            item.speed = speed
            val v = Regex("([\\d.]+)\\s*([KMG]i?B)/s").find(speed)
            if (v != null) {
                val num = v.groupValues[1].toFloatOrNull() ?: 0f
                val mb = when (v.groupValues[2].first()) { 'K' -> num / 1024f; 'G' -> num * 1024f; else -> num }
                item.samples = (item.samples + mb).takeLast(60)
            }
        }
        val now = System.currentTimeMillis()
        if (now - lastNotify > 1200) {
            lastNotify = now
            Notifier.progress(app, item.title.take(40), item.progress.toInt())
        }
    }

    private suspend fun runYt(item: DlItem, url: String, o: DlOptions) {
        val dir = File(app.cacheDir, "dl/" + item.id)
        dir.mkdirs()
        item.status = DStatus.DOWNLOADING
        item.message = "Starting..."
        val max = if (Prefs.bool("auto_repair")) Prefs.int("repair_attempts", 4).coerceIn(1, 6) else 1
        var ok = false
        var lastErr = ""
        for (attempt in 0 until max) {
            if (item.canceled) break
            if (attempt > 0) {
                item.message = "Auto-repair: trying another way (" + (attempt + 1) + "/" + max + ")"
                if (attempt == 1) Engine.update(app)
            }
            try {
                Engine.download(app, url, o, dir, item.processId, attempt) { p, eta, line ->
                    if (item.status != DStatus.PROCESSING) {
                        val sp = Regex("at\\s+([\\d.]+\\s*[KMG]i?B/s)").find(line)?.groupValues?.get(1) ?: ""
                        if (line.contains("[download]") || p > 0f) {
                            item.message = ""
                            tick(item, p, eta, sp)
                        } else if (line.contains("[Merger]") || line.contains("[ExtractAudio]") || line.contains("[EmbedThumbnail]") || line.contains("[Metadata]")) {
                            item.status = DStatus.PROCESSING
                            item.message = "Processing..."
                        }
                    }
                }
                ok = true
                break
            } catch (t: Throwable) {
                lastErr = t.message ?: t.toString()
                if (item.canceled) break
                item.status = DStatus.DOWNLOADING
            }
        }
        if (item.canceled) {
            item.status = DStatus.CANCELED
            item.message = "Cancelled"
            dir.deleteRecursively()
            return
        }
        if (!ok) {
            item.status = DStatus.FAILED
            item.message = Engine.friendly(lastErr)
            if (Prefs.bool("delete_partial")) dir.deleteRecursively()
            Notifier.finished(app, item.title, false, item.message)
            return
        }
        finish(item, dir)
    }

    private fun finish(item: DlItem, dir: File) {
        item.status = DStatus.SAVING
        item.message = "Saving to your phone..."
        item.progress = 100f
        val tmpExt = listOf("part", "ytdl", "tmp", "temp")
        val files = dir.walk().filter { it.isFile && it.extension.lowercase() !in tmpExt && it.length() > 0 }.toList()
        if (files.isEmpty()) {
            item.status = DStatus.FAILED
            item.message = "No file was produced"
            return
        }
        var primary: Pair<String, String>? = null
        var primarySize = -1L
        try {
            for (f in files) {
                val r = Saver.save(app, f, item.site)
                val isMedia = r.second.startsWith("video") || r.second.startsWith("audio") || r.second.startsWith("image")
                if (isMedia && f.length() > primarySize) { primarySize = f.length(); primary = r }
                if (primary == null) primary = r
            }
        } catch (t: Throwable) {
            item.status = DStatus.FAILED
            item.message = "Could not save: " + (t.message ?: "storage error")
            return
        }
        dir.deleteRecursively()
        val p = primary ?: return
        item.savedUri = p.first
        item.mime = p.second
        item.status = DStatus.DONE
        item.message = if (files.size > 1) "Saved " + files.size + " files" else "Saved"
        History.add(HistItem(item.id, item.title, item.site, item.kind, p.first, p.second, primarySize.coerceAtLeast(0), System.currentTimeMillis(), item.thumb ?: "", item.url))
        Notifier.finished(app, item.title, true, "")
        if (Prefs.bool("open_when_done")) Util.open(app, p.first, p.second)
    }

    private fun safeName(s: String): String = s.replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_").trim().take(120)

    private fun runDirect(item: DlItem, url: String, referer: String?) {
        val dir = File(app.cacheDir, "dl/" + item.id)
        dir.mkdirs()
        item.status = DStatus.DOWNLOADING
        item.message = ""
        try {
            val ua = Http.ua(Prefs.str("web_ua"))
            val c = Http.open(url, ua, if (Prefs.bool("web_referer")) referer else null)
            if (c.responseCode >= 400) throw Exception("HTTP " + c.responseCode)
            val total = c.contentLengthLong
            val ct = (c.contentType ?: "").substringBefore(';').trim().lowercase()
            var name = ""
            val cd = c.getHeaderField("Content-Disposition")
            if (cd != null) {
                val m = Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(cd)
                if (m != null) name = Uri.decode(m.groupValues[1])
            }
            if (name.isEmpty()) name = Uri.decode(url.substringBefore('?').substringAfterLast('/'))
            if (name.isEmpty()) name = "file"
            var ext = name.substringAfterLast('.', "").lowercase()
            if (ext.isEmpty() || ext.length > 5) {
                ext = when (ct) {
                    "image/jpeg" -> "jpg"; "image/png" -> "png"; "image/webp" -> "webp"; "image/gif" -> "gif"; "image/avif" -> "avif"
                    "video/mp4" -> "mp4"; "video/webm" -> "webm"; "audio/mpeg" -> "mp3"; "audio/mp4" -> "m4a"; "audio/ogg" -> "ogg"
                    else -> "bin"
                }
                name = safeName(name.substringBeforeLast('.')) + "." + ext
            }
            name = safeName(name)
            val out = File(dir, name)
            var done = 0L
            var lastT = System.currentTimeMillis()
            var lastB = 0L
            c.inputStream.use { ins ->
                out.outputStream().use { os ->
                    val buf = ByteArray(32768)
                    while (true) {
                        if (item.canceled) throw Exception("Cancelled")
                        val n = ins.read(buf)
                        if (n < 0) break
                        os.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - lastT >= 700) {
                            val sp = (done - lastB) / ((now - lastT) / 1000.0) / 1048576.0
                            lastT = now; lastB = done
                            val pct = if (total > 0) done * 100f / total else 0f
                            val eta = if (total > 0 && sp > 0.01) ((total - done) / (sp * 1048576.0)).toLong() else -1L
                            tick(item, pct, eta, "%.1fMiB/s".format(sp))
                        }
                    }
                }
            }
            c.disconnect()
            finish(item, dir)
        } catch (t: Throwable) {
            if (item.canceled) {
                item.status = DStatus.CANCELED
                item.message = "Cancelled"
            } else {
                item.status = DStatus.FAILED
                item.message = Engine.friendly(t.message ?: t.toString())
                Notifier.finished(app, item.title, false, item.message)
            }
            dir.deleteRecursively()
        }
    }
}
