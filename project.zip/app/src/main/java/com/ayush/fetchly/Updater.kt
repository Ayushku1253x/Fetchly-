package com.ayush.fetchly

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * In-app updater. The GitHub workflow publishes every successful build as a release named "build-N"
 * (N = run number = versionCode). The app asks GitHub for the latest release, and if N is higher than
 * the installed versionCode it offers to download and install the APK.
 * The repo must be PUBLIC for this to work without a token.
 */
object Updater {
    // owner/repo of the GitHub repository that builds the app. Change here if the repo is renamed.
    const val REPO = "Ayushku1253x/Fetchly-"

    class Info(val code: Int, val name: String, val notes: String, val apkUrl: String)

    var available by mutableStateOf<Info?>(null)
    var show by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var checking by mutableStateOf(false)
    var progress by mutableFloatStateOf(0f)
    private var autoChecked = false

    fun currentCode(ctx: Context): Long = try {
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
    } catch (_: Throwable) { 0L }

    fun currentName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (_: Throwable) { "" }

    fun autoCheck(ctx: Context, scope: CoroutineScope) {
        if (autoChecked || !Prefs.bool("auto_check_update")) return
        autoChecked = true
        check(ctx, scope, false)
    }

    fun check(ctx: Context, scope: CoroutineScope, manual: Boolean) {
        if (checking) return
        checking = true
        scope.launch(Dispatchers.IO) {
            var msg: String? = null
            var found: Info? = null
            try {
                val c = URL("https://api.github.com/repos/$REPO/releases/latest").openConnection() as HttpURLConnection
                c.connectTimeout = 10000
                c.readTimeout = 15000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                c.setRequestProperty("User-Agent", "Fetchly")
                val rc = c.responseCode
                if (rc != 200) {
                    msg = if (rc == 404) "No update found. Make sure the GitHub repo is public and a build finished." else "Update check failed ($rc)"
                } else {
                    val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                    val tag = o.optString("tag_name")
                    val code = Regex("(\\d+)").find(tag)?.value?.toIntOrNull() ?: 0
                    var apk = ""
                    val assets = o.optJSONArray("assets")
                    if (assets != null) {
                        for (i in 0 until assets.length()) {
                            val a = assets.getJSONObject(i)
                            if (a.optString("name").endsWith(".apk")) { apk = a.optString("browser_download_url"); break }
                        }
                    }
                    if (code > currentCode(ctx) && apk.isNotEmpty()) {
                        found = Info(code, o.optString("name").ifEmpty { tag }, o.optString("body"), apk)
                    } else {
                        msg = "You have the latest version"
                    }
                }
            } catch (t: Throwable) {
                msg = "Update check failed: " + (t.message ?: "no internet")
            }
            withContext(Dispatchers.Main) {
                checking = false
                if (found != null) { available = found; show = true }
                else if (manual && msg != null) Util.toast(ctx, msg)
                Unit
            }
        }
    }

    fun downloadAndInstall(ctx: Context, scope: CoroutineScope) {
        val info = available ?: return
        if (busy) return
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            Util.toast(ctx, "Allow \"Install unknown apps\" for Fetchly, come back and tap Update again")
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Throwable) {}
            return
        }
        busy = true
        progress = 0f
        scope.launch(Dispatchers.IO) {
            var err: String? = null
            var file: File? = null
            try {
                val dir = File(ctx.cacheDir, "updates")
                dir.mkdirs()
                dir.listFiles()?.forEach { it.delete() }
                val f = File(dir, "fetchly-update.apk")
                val c = URL(info.apkUrl).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.instanceFollowRedirects = true
                val total = c.contentLengthLong
                c.inputStream.use { inp ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        var read = 0L
                        while (true) {
                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            read += n
                            if (total > 0) progress = read.toFloat() / total.toFloat()
                        }
                    }
                }
                file = f
            } catch (t: Throwable) {
                err = "Update download failed: " + (t.message ?: "")
            }
            withContext(Dispatchers.Main) {
                busy = false
                if (file != null) install(ctx, file) else if (err != null) Util.toast(ctx, err)
                Unit
            }
        }
    }

    private fun install(ctx: Context, f: File) {
        try {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".provider", f)
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (t: Throwable) {
            Util.toast(ctx, "Could not open installer: " + (t.message ?: ""))
        }
    }
}

@Composable
fun UpdateOverlay() {
    val info = Updater.available
    if (info == null || !Updater.show) return
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = LocalPal.current
    Box(
        Modifier.fillMaxSize().background(Color(0x66000000)).pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        val shape = RoundedCornerShape(p.radius + 6.dp)
        Column(
            Modifier.padding(28.dp).fillMaxWidth().clip(shape).background(p.solid).border(1.dp, p.border, shape).padding(20.dp)
        ) {
            T("Update available", 20f, weight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            T(info.name, 13f, p.sub)
            if (info.notes.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                T(info.notes.trim().take(300), 13f, p.sub)
            }
            Spacer(Modifier.height(16.dp))
            if (Updater.busy) {
                Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(p.accent.copy(alpha = 0.2f))) {
                    Box(Modifier.fillMaxWidth(Updater.progress.coerceIn(0f, 1f)).height(8.dp).background(p.accent))
                }
                Spacer(Modifier.height(16.dp))
            }
            PrimaryButton(
                if (Updater.busy) "Downloading " + (Updater.progress * 100).toInt() + "%" else "Update now",
                Modifier.fillMaxWidth(), !Updater.busy
            ) { Updater.downloadAndInstall(ctx, scope) }
            if (!Updater.busy) {
                Spacer(Modifier.height(10.dp))
                SoftButton("Later", Modifier.fillMaxWidth()) { Updater.show = false }
            }
        }
    }
}
