package com.ayush.fetchly

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * Invisible share target. Share a link to Fetchly from any app: if auto-save is on, the download starts
 * in the background and you stay in the app you shared from. Otherwise the normal Fetchly screen opens.
 */
class ShareActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT) ?: ""
        val url = Util.extractUrl(text)
        if (url == null) {
            Util.toast(this, "Fetchly: no link found in what you shared")
            finish()
            return
        }
        if (AutoShare.enabled()) {
            AutoShare.start(applicationContext, url)
            if (Prefs.bool("share_open_after")) openApp(text)
        } else {
            openApp(text)
        }
        finish()
    }

    private fun openApp(text: String) {
        val i = Intent(this, MainActivity::class.java)
            .setAction(Intent.ACTION_SEND)
            .setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, text)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(i)
    }
}
