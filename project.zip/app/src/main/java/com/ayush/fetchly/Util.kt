package com.ayush.fetchly

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object Util {
    fun toast(ctx: Context, msg: String) {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }

    fun detect(url: String): String {
        val u = url.lowercase()
        return when {
            "youtube.com" in u || "youtu.be" in u -> "youtube"
            "instagram.com" in u || "instagr.am" in u -> "instagram"
            else -> "web"
        }
    }

    fun extractUrl(s: String): String? = Regex("https?://[^\\s]+").find(s)?.value

    fun dur(sec: Int): String {
        if (sec <= 0) return ""
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    fun size(b: Long): String {
        if (b <= 0) return ""
        val kb = b / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1 -> "%.2f GB".format(gb)
            mb >= 1 -> "%.1f MB".format(mb)
            else -> "%.0f KB".format(kb)
        }
    }

    fun eta(sec: Long): String {
        if (sec < 0) return "--:--"
        val m = sec / 60
        val s = sec % 60
        return "%d:%02d".format(m, s)
    }

    fun open(ctx: Context, uri: String, mime: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(Uri.parse(uri), mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (t: Throwable) {
            toast(ctx, "No app found to open this file")
        }
    }

    fun share(ctx: Context, uri: String, mime: String) {
        try {
            val i = Intent(Intent.ACTION_SEND)
                .setType(mime)
                .putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val c = Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(c)
        } catch (t: Throwable) {
            toast(ctx, "Cannot share this file")
        }
    }

    fun openLink(ctx: Context, url: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (t: Throwable) {
            toast(ctx, "Cannot open link")
        }
    }
}
