package com.ayush.fetchly

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object Shared {
    val link = mutableStateOf<String?>(null)
}

object YtState {
    var url by mutableStateOf("")
    var info by mutableStateOf<MediaInfo?>(null)
    var loading by mutableStateOf(false)
    var error by mutableStateOf("")
    var mode by mutableIntStateOf(0)
    var height by mutableIntStateOf(0)
    var container by mutableStateOf("")
    var audioFmt by mutableStateOf("")
    var audioQ by mutableStateOf("")
    var trim by mutableStateOf(Prefs.bool("yt_trim_default"))
    var tStart by mutableStateOf("")
    var tEnd by mutableStateOf("")
}

object IgState {
    var input by mutableStateOf("")
    var mode by mutableIntStateOf(0)
    var info by mutableStateOf<MediaInfo?>(null)
    var dpUrl by mutableStateOf("")
    var images by mutableStateOf(listOf<WebMedia>())
    var loading by mutableStateOf(false)
    var error by mutableStateOf("")
    var audio by mutableStateOf(false)
}

object WebState {
    var url by mutableStateOf("")
    var loading by mutableStateOf(false)
    var error by mutableStateOf("")
    var media by mutableStateOf(listOf<WebMedia>())
    var selected by mutableStateOf(setOf<String>())
    var vid by mutableStateOf<MediaInfo?>(null)
    var scanned by mutableStateOf(false)
}

fun hLabel(h: Int): String = when {
    h >= 4320 -> "8K"
    h >= 2160 -> "4K"
    else -> h.toString() + "p"
}

fun ytFetch(ctx: Context, scope: CoroutineScope) {
    val u = Util.extractUrl(YtState.url) ?: YtState.url.trim()
    if (u.isBlank()) return
    YtState.loading = true
    YtState.error = ""
    YtState.info = null
    scope.launch {
        try {
            val info = withContext(Dispatchers.IO) {
                Engine.fetchInfoRetry(ctx, u, !Prefs.bool("single_video"), true)
            }
            YtState.info = info
            YtState.height = 0
            if (Prefs.str("yt_default_mode") == "Audio") YtState.mode = 1
        } catch (t: Throwable) {
            YtState.error = Engine.friendly(t.message ?: t.toString())
        }
        YtState.loading = false
    }
}

fun igUser(input: String): String {
    val u = Util.extractUrl(input)
    val parts = if (u != null) u.substringAfter("instagram.com/").substringBefore('?').substringBefore('#').split('/') else listOf(input.trim())
    val skip = listOf("stories", "p", "reel", "reels", "tv", "highlights")
    return parts.firstOrNull { it.isNotEmpty() && it !in skip }?.removePrefix("@") ?: ""
}

fun igFetch(ctx: Context, scope: CoroutineScope) {
    val raw = IgState.input.trim()
    if (raw.isEmpty()) return
    IgState.loading = true
    IgState.error = ""
    IgState.info = null
    IgState.dpUrl = ""
    IgState.images = emptyList()
    IgState.audio = Prefs.bool("ig_audio_reel")
    scope.launch {
        try {
            if (IgState.mode == 2) {
                val user = igUser(raw)
                val dp = withContext(Dispatchers.IO) { Scraper.instagramDp(ctx, user) }
                if (dp == null) IgState.error = "Could not get the profile photo. Check the username. If it is private, login in Settings first."
                else IgState.dpUrl = dp
            } else {
                val url = if (IgState.mode == 1 && Util.extractUrl(raw) == null) "https://www.instagram.com/stories/" + igUser(raw) + "/" else (Util.extractUrl(raw) ?: raw)
                val pl = (IgState.mode == 1 && Prefs.bool("ig_story_all")) || (IgState.mode == 0 && Prefs.bool("ig_carousel_all"))
                try {
                    IgState.info = withContext(Dispatchers.IO) { Engine.fetchInfoRetry(ctx, url, pl, false) }
                } catch (t: Throwable) {
                    val found = if (IgState.mode == 0) {
                        try { withContext(Dispatchers.IO) { Scraper.scan(url).filter { it.type != "audio" } } } catch (_: Throwable) { emptyList() }
                    } else emptyList()
                    if (found.isNotEmpty()) IgState.images = found
                    else IgState.error = Engine.friendly(t.message ?: t.toString())
                }
            }
        } catch (t: Throwable) {
            IgState.error = Engine.friendly(t.message ?: t.toString())
        }
        IgState.loading = false
    }
}

fun webScan(ctx: Context, scope: CoroutineScope) {
    val u = Util.extractUrl(WebState.url) ?: WebState.url.trim()
    if (u.isBlank()) return
    val full = if (u.startsWith("http")) u else "https://$u"
    WebState.loading = true
    WebState.error = ""
    WebState.media = emptyList()
    WebState.selected = emptySet()
    WebState.vid = null
    WebState.scanned = false
    scope.launch {
        try {
            val list = withContext(Dispatchers.IO) { Scraper.filterBySize(Scraper.scan(full)) }
            WebState.media = list
            WebState.scanned = true
            if (list.isEmpty()) WebState.error = "No media found on this page. Try \"Try as video\"."
        } catch (t: Throwable) {
            WebState.error = Engine.friendly(t.message ?: t.toString())
        }
        WebState.loading = false
    }
}

fun webVideo(ctx: Context, scope: CoroutineScope) {
    val u = Util.extractUrl(WebState.url) ?: WebState.url.trim()
    if (u.isBlank()) return
    val full = if (u.startsWith("http")) u else "https://$u"
    WebState.loading = true
    WebState.error = ""
    WebState.vid = null
    scope.launch {
        try {
            WebState.vid = withContext(Dispatchers.IO) { Engine.fetchInfoRetry(ctx, full, false, false) }
        } catch (t: Throwable) {
            WebState.error = Engine.friendly(t.message ?: t.toString())
        }
        WebState.loading = false
    }
}

@Composable
fun ScreenFrame(title: String, icon: @Composable () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.padding(top = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            icon()
            Spacer(Modifier.width(10.dp))
            T(title, 30f, weight = FontWeight.SemiBold)
        }
        content()
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun PasteButton(onText: (String) -> Unit) {
    val p = LocalPal.current
    val clip = LocalClipboardManager.current
    Box(
        Modifier.clip(RoundedCornerShape(12.dp)).background(p.accentSoft)
            .tap { val t = clip.getText()?.text ?: ""; if (t.isNotEmpty()) onText(Util.extractUrl(t) ?: t) }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) { T("Paste", 12f, p.accent, FontWeight.Medium) }
}

@Composable
fun ClipBanner(site: String, current: String, onUse: (String) -> Unit) {
    if (!Prefs.bool("clipboard_detect") || current.isNotEmpty()) return
    val clip = LocalClipboardManager.current
    val txt = clip.getText()?.text ?: return
    val u = Util.extractUrl(txt) ?: return
    if (Util.detect(u) != site) return
    val p = LocalPal.current
    GlassCard(Modifier.tap { onUse(u) }) {
        T("Copied link found. Tap to use it", 13f, p.accent, FontWeight.Medium)
        T(u, 12f, p.sub, maxLines = 1)
    }
}

@Composable
fun InfoCard(info: MediaInfo) {
    val p = LocalPal.current
    GlassCard {
        if (Prefs.bool("fetch_thumbs") && info.thumb != null) {
            AsyncImage(
                model = info.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(16.dp))
            )
            Spacer(Modifier.height(10.dp))
        }
        T(info.title.ifBlank { info.url }, 16f, weight = FontWeight.Medium, maxLines = 3)
        val meta = listOf(info.uploader, Util.dur(info.duration)).filter { it.isNotEmpty() }.joinToString("  \u00B7  ")
        if (meta.isNotEmpty()) T(meta, 13f, p.sub)
        if (info.playlistCount > 1) T(info.playlistCount.toString() + " items in this link", 13f, p.accent)
    }
}

@Composable
fun ErrorCard(msg: String, onRetry: () -> Unit) {
    GlassCard {
        T(msg, 14f, Color(0xFFE5566D))
        Spacer(Modifier.height(10.dp))
        SoftButton("Try again", Modifier.fillMaxWidth()) { onRetry() }
    }
}

@Composable
fun YouTubeScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = LocalPal.current
    val clip = LocalClipboardManager.current
    ScreenFrame("YouTube", { PlatformIcon("youtube", 34.dp) }) {
        ClipBanner("youtube", YtState.url) { YtState.url = it }
        Field(YtState.url, { YtState.url = it }, "Paste YouTube link", trailing = { PasteButton { YtState.url = it } })
        PrimaryButton(if (YtState.loading) "Fetching..." else "Fetch", Modifier.fillMaxWidth(), !YtState.loading) { ytFetch(ctx, scope) }
        if (YtState.error.isNotEmpty()) ErrorCard(YtState.error) { ytFetch(ctx, scope) }
        val info = YtState.info
        if (info != null) {
            InfoCard(info)
            Seg(listOf("Video", "Audio", "Thumbnail", "Info"), YtState.mode) { YtState.mode = it }
            fun copy(text: String) {
                clip.setText(AnnotatedString(text))
                if (Prefs.bool("yt_copy_toast")) Util.toast(ctx, "Copied")
            }
            when (YtState.mode) {
                0 -> {
                    val cont = if (YtState.container.isEmpty()) Prefs.str("video_container") else YtState.container
                    GlassCard {
                        T("Quality", 13f, p.sub)
                        Spacer(Modifier.height(8.dp))
                        Flow {
                            Chip("Best", YtState.height == 0) { YtState.height = 0 }
                            info.heights.forEach { h -> Chip(hLabel(h), YtState.height == h) { YtState.height = h } }
                        }
                        Spacer(Modifier.height(14.dp))
                        T("Format", 13f, p.sub)
                        Spacer(Modifier.height(8.dp))
                        Flow { listOf("MP4", "MKV", "WEBM", "MOV", "Original").forEach { Chip(it, cont == it) { YtState.container = it } } }
                    }
                    GlassCard {
                        PrefToggle("Embed thumbnail in video", "embed_thumb_video")
                        PrefToggle("Download subtitles", "subtitles")
                        PrefToggle("Remove sponsor segments", "sponsorblock")
                        PrefToggle("Trim video", "yt_trim_default")
                        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(Modifier.weight(1f)) { Field(YtState.tStart, { YtState.tStart = it; YtState.trim = true }, "Start 0:30") }
                            Box(Modifier.weight(1f)) { Field(YtState.tEnd, { YtState.tEnd = it; YtState.trim = true }, "End 1:45") }
                        }
                    }
                    PrimaryButton("Download video", Modifier.fillMaxWidth()) {
                        val useTrim = Prefs.bool("yt_trim_default") || YtState.tStart.isNotEmpty() || YtState.tEnd.isNotEmpty()
                        Manager.enqueueYt(
                            ctx, info,
                            DlOptions(
                                "youtube", false, if (YtState.height == 0) null else YtState.height, cont,
                                Prefs.str("audio_format"), Prefs.str("audio_quality"),
                                if (useTrim) YtState.tStart else "", if (useTrim) YtState.tEnd else "",
                                !Prefs.bool("single_video") && info.playlistCount > 1
                            )
                        )
                    }
                }
                1 -> {
                    val af = if (YtState.audioFmt.isEmpty()) Prefs.str("audio_format") else YtState.audioFmt
                    val aq = if (YtState.audioQ.isEmpty()) Prefs.str("audio_quality") else YtState.audioQ
                    GlassCard {
                        T("Audio format", 13f, p.sub)
                        Spacer(Modifier.height(8.dp))
                        Flow { SETTINGS_BY_KEY["audio_format"]!!.choices.forEach { Chip(it, af == it) { YtState.audioFmt = it } } }
                        Spacer(Modifier.height(14.dp))
                        T("Quality", 13f, p.sub)
                        Spacer(Modifier.height(8.dp))
                        Flow { SETTINGS_BY_KEY["audio_quality"]!!.choices.forEach { Chip(it, aq == it) { YtState.audioQ = it } } }
                    }
                    GlassCard {
                        PrefToggle("Embed thumbnail as cover art", "audio_embed_thumb", "Shows the YouTube thumbnail in your music app")
                        PrefToggle("Embed title and artist", "audio_embed_meta")
                    }
                    PrimaryButton("Download audio", Modifier.fillMaxWidth()) {
                        Manager.enqueueYt(
                            ctx, info,
                            DlOptions("youtube", true, null, "MP4", af, aq, "", "", !Prefs.bool("single_video") && info.playlistCount > 1)
                        )
                    }
                }
                2 -> {
                    val list = info.thumbs.take(8)
                    GlassCard {
                        T("Thumbnails", 13f, p.sub)
                        Spacer(Modifier.height(8.dp))
                        if (list.isEmpty()) T("No thumbnails found", 14f)
                        list.forEach { th ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                T(if (th.w > 0) th.w.toString() + " x " + th.h else "Thumbnail", 14f, modifier = Modifier.weight(1f))
                                SoftButton("Save") {
                                    Manager.enqueueDirect(ctx, listOf(th.url), null, info.title.ifBlank { "thumbnail" } + " thumbnail", "youtube", "image")
                                }
                            }
                        }
                    }
                }
                else -> {
                    GlassCard {
                        Flow {
                            Chip("Copy title", false) { copy(info.title) }
                            Chip("Copy description", false) { copy(info.description) }
                            Chip("Copy tags", false) { copy(info.tags.joinToString(", ")) }
                            Chip("Copy link", false) { copy(info.url) }
                            Chip("Open on YouTube", false) { Util.openLink(ctx, info.url) }
                        }
                    }
                    if (info.description.isNotBlank()) GlassCard {
                        T("Description", 13f, p.sub)
                        Spacer(Modifier.height(6.dp))
                        T(info.description.take(900), 13f)
                    }
                    if (info.tags.isNotEmpty()) GlassCard {
                        T("Tags", 13f, p.sub)
                        Spacer(Modifier.height(8.dp))
                        Flow { info.tags.take(40).forEach { Chip(it, false) { copy(it) } } }
                    }
                }
            }
        }
    }
}

@Composable
fun InstagramScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = LocalPal.current
    ScreenFrame("Instagram", { PlatformIcon("instagram", 34.dp) }) {
        ClipBanner("instagram", IgState.input) { IgState.input = it }
        Seg(listOf("Post / Reel", "Story", "Profile photo"), IgState.mode) {
            IgState.mode = it
            IgState.info = null
            IgState.dpUrl = ""
            IgState.images = emptyList()
            IgState.error = ""
        }
        val hint = when (IgState.mode) {
            0 -> "Paste post or reel link"
            1 -> "Paste story link or username"
            else -> "Username or profile link"
        }
        Field(IgState.input, { IgState.input = it }, hint, trailing = { PasteButton { IgState.input = it } })
        if (IgState.mode == 1 && !Cookies.has(ctx, "instagram")) {
            GlassCard {
                T("Stories need a login. Open Settings and tap Login Instagram, then come back.", 13f, p.sub)
            }
        }
        PrimaryButton(if (IgState.loading) "Fetching..." else "Fetch", Modifier.fillMaxWidth(), !IgState.loading) { igFetch(ctx, scope) }
        if (IgState.error.isNotEmpty()) ErrorCard(IgState.error) { igFetch(ctx, scope) }

        val info = IgState.info
        if (info != null) {
            InfoCard(info)
            GlassCard {
                T("Original quality, nothing is changed or compressed.", 13f, p.sub)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    T("Save as audio (MP3)", 14f, modifier = Modifier.weight(1f))
                    Toggle(IgState.audio) { IgState.audio = it }
                }
                PrefToggle("Save caption as text file", "ig_caption")
            }
            PrimaryButton(if (IgState.audio) "Download audio" else "Download", Modifier.fillMaxWidth()) {
                val pl = (IgState.mode == 1 && Prefs.bool("ig_story_all")) || (IgState.mode == 0 && Prefs.bool("ig_carousel_all"))
                Manager.enqueueYt(
                    ctx, info,
                    DlOptions("instagram", IgState.audio, null, "Original", Prefs.str("audio_format"), Prefs.str("audio_quality"), "", "", pl)
                )
            }
        }
        if (IgState.dpUrl.isNotEmpty()) {
            GlassCard {
                if (Prefs.bool("fetch_thumbs")) {
                    AsyncImage(
                        model = IgState.dpUrl, contentDescription = null, contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(16.dp))
                    )
                    Spacer(Modifier.height(10.dp))
                }
                T("Profile photo found", 14f)
            }
            PrimaryButton("Save profile photo", Modifier.fillMaxWidth()) {
                Manager.enqueueDirect(ctx, listOf(IgState.dpUrl), null, "instagram_" + igUser(IgState.input), "instagram", "image")
            }
        }
        if (IgState.images.isNotEmpty()) {
            GlassCard {
                T(IgState.images.size.toString() + " item(s) found on this post", 14f)
            }
            PrimaryButton("Download all", Modifier.fillMaxWidth()) {
                val imgs = IgState.images
                Manager.enqueueDirect(ctx, imgs.filter { it.type == "image" }.map { it.url }, Util.extractUrl(IgState.input), "instagram_photo", "instagram", "image")
                Manager.enqueueDirect(ctx, imgs.filter { it.type == "video" }.map { it.url }, Util.extractUrl(IgState.input), "instagram_video", "instagram", "video")
            }
        }
    }
}

@Composable
fun MediaCell(m: WebMedia, selected: Boolean, modifier: Modifier, onTap: () -> Unit) {
    val p = LocalPal.current
    Box(modifier.clip(RoundedCornerShape(14.dp)).background(p.glass).tap(onTap)) {
        if (m.type == "image" && Prefs.bool("fetch_thumbs")) {
            AsyncImage(model = m.url, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (m.type == "video") Image(Icons.Default.PlayArrow, null, Modifier.size(34.dp), colorFilter = ColorFilter.tint(p.accent))
                else T(if (m.type == "audio") "AUDIO" else "IMAGE", 12f, p.sub)
            }
        }
        if (selected) {
            Box(Modifier.fillMaxSize().background(p.accent.copy(alpha = 0.28f)))
            Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(24.dp).clip(RoundedCornerShape(12.dp)).background(p.accent), contentAlignment = Alignment.Center) {
                Image(Icons.Default.Check, null, Modifier.size(16.dp), colorFilter = ColorFilter.tint(Color.White))
            }
        }
    }
}

@Composable
fun WebScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = LocalPal.current
    val rows = WebState.media.chunked(3)
    LazyColumn(
        Modifier.fillMaxSize().imePadding().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.padding(top = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                PlatformIcon("web", 34.dp)
                Spacer(Modifier.width(10.dp))
                T("Websites", 30f, weight = FontWeight.SemiBold)
            }
        }
        item { ClipBanner("web", WebState.url) { WebState.url = it } }
        item { Field(WebState.url, { WebState.url = it }, "Paste any website link", trailing = { PasteButton { WebState.url = it } }) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton(if (WebState.loading) "Working..." else "Scan page", Modifier.weight(1f), !WebState.loading) { webScan(ctx, scope) }
                SoftButton("Try as video", Modifier.weight(1f)) { if (!WebState.loading) webVideo(ctx, scope) }
            }
        }
        if (WebState.error.isNotEmpty()) item { GlassCard { T(WebState.error, 14f, Color(0xFFE5566D)) } }
        val vid = WebState.vid
        if (vid != null) {
            item { InfoCard(vid) }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PrimaryButton("Download video", Modifier.weight(1f)) {
                        Manager.enqueueYt(ctx, vid, DlOptions("web", false, null, Prefs.str("video_container"), Prefs.str("audio_format"), Prefs.str("audio_quality")))
                    }
                    SoftButton("Audio", Modifier.weight(1f)) {
                        Manager.enqueueYt(ctx, vid, DlOptions("web", true, null, "MP4", Prefs.str("audio_format"), Prefs.str("audio_quality")))
                    }
                }
            }
        }
        if (WebState.media.isNotEmpty()) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    T(WebState.media.size.toString() + " found  \u00B7  " + WebState.selected.size + " selected", 13f, p.sub, modifier = Modifier.weight(1f))
                    Chip("All", false) { WebState.selected = WebState.media.map { it.url }.toSet() }
                    Spacer(Modifier.width(6.dp))
                    Chip("None", false) { WebState.selected = emptySet() }
                }
            }
            item {
                PrimaryButton("Download selected (" + WebState.selected.size + ")", Modifier.fillMaxWidth(), WebState.selected.isNotEmpty()) {
                    val chosen = WebState.media.filter { it.url in WebState.selected }
                    val ref = Util.extractUrl(WebState.url) ?: WebState.url
                    Manager.enqueueDirect(ctx, chosen.filter { it.type == "image" }.map { it.url }, ref, "web_image", "web", "image")
                    Manager.enqueueDirect(ctx, chosen.filter { it.type == "video" }.map { it.url }, ref, "web_video", "web", "video")
                    Manager.enqueueDirect(ctx, chosen.filter { it.type == "audio" }.map { it.url }, ref, "web_audio", "web", "audio")
                }
            }
            items(rows) { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { m ->
                        MediaCell(m, m.url in WebState.selected, Modifier.weight(1f).aspectRatio(1f)) {
                            WebState.selected = if (m.url in WebState.selected) WebState.selected - m.url else WebState.selected + m.url
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun MiniBar() {
    if (!Prefs.bool("show_mini_bar") || Manager.overlay) return
    val cur = Manager.items.firstOrNull { it.isActive() } ?: return
    val p = LocalPal.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).glass(20.dp).tap { Manager.overlay = true }.padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            T(cur.title, 13f, maxLines = 1)
            Spacer(Modifier.height(5.dp))
            Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(p.accentSoft)) {
                Box(Modifier.fillMaxWidth(cur.progress / 100f).height(4.dp).background(p.accent))
            }
        }
        Spacer(Modifier.width(12.dp))
        T(cur.progress.toInt().toString() + "%", 13f, p.accent, FontWeight.Medium)
    }
}

@Composable
fun ExportOverlay() {
    val ctx = LocalContext.current
    val p = LocalPal.current
    BackHandler { Manager.overlay = false }
    val cur = Manager.items.firstOrNull { it.isActive() } ?: Manager.items.firstOrNull()
    AppBackground(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp)) {
            Row(Modifier.padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                T(if (cur != null && cur.status == DStatus.DONE) "Saved" else "Downloading", 28f, weight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                SoftButton("Minimize") { Manager.overlay = false }
            }
            if (cur == null) {
                Spacer(Modifier.height(40.dp))
                T("Nothing here yet", 15f, p.sub)
            } else {
                Spacer(Modifier.height(18.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    val frac = (cur.progress / 100f).coerceIn(0f, 1f)
                    val track = p.accentSoft
                    val col = p.accent
                    Canvas(Modifier.size(210.dp)) {
                        val stroke = 16.dp.toPx()
                        val inset = stroke / 2f
                        val path = Path()
                        path.addRoundRect(RoundRect(inset, inset, size.width - inset, size.height - inset, CornerRadius(58.dp.toPx(), 58.dp.toPx())))
                        drawPath(path, track, style = Stroke(stroke, cap = StrokeCap.Round))
                        val pm = PathMeasure()
                        pm.setPath(path, false)
                        val seg = Path()
                        pm.getSegment(0f, pm.length * frac, seg, true)
                        drawPath(seg, col, style = Stroke(stroke, cap = StrokeCap.Round))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        T(cur.progress.toInt().toString() + "%", 44f, weight = FontWeight.SemiBold)
                        T(
                            when (cur.status) {
                                DStatus.DONE -> "Done"
                                DStatus.FAILED -> "Failed"
                                DStatus.CANCELED -> "Cancelled"
                                DStatus.PROCESSING -> "Processing"
                                DStatus.SAVING -> "Saving"
                                else -> "About " + Util.eta(cur.eta) + " left"
                            }, 13f, p.sub
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                T(cur.title, 15f, weight = FontWeight.Medium, align = TextAlign.Center, maxLines = 2, modifier = Modifier.fillMaxWidth())
                if (cur.speed.isNotEmpty() && cur.isActive()) T(cur.speed, 13f, p.sub, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                if (cur.message.isNotEmpty()) T(cur.message, 13f, if (cur.status == DStatus.FAILED) Color(0xFFE5566D) else p.sub, align = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                Spacer(Modifier.height(12.dp))
                GlassCard {
                    val s = cur.samples
                    val line = p.accent
                    Canvas(Modifier.fillMaxWidth().height(64.dp)) {
                        if (s.size >= 2) {
                            val mx = (s.maxOrNull() ?: 1f).coerceAtLeast(0.1f)
                            val path = Path()
                            s.forEachIndexed { i, v ->
                                val x = size.width * i / (s.size - 1)
                                val y = size.height - (v / mx) * size.height * 0.9f - 4f
                                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                            }
                            drawPath(path, line, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
                        }
                    }
                    T("Speed", 12f, p.sub)
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    when (cur.status) {
                        DStatus.DONE -> {
                            PrimaryButton("Open", Modifier.weight(1f)) { Util.open(ctx, cur.savedUri, cur.mime) }
                            SoftButton("Share", Modifier.weight(1f)) { Util.share(ctx, cur.savedUri, cur.mime) }
                        }
                        DStatus.FAILED, DStatus.CANCELED -> {
                            PrimaryButton("Retry", Modifier.weight(1f)) { Manager.retry(cur) }
                            SoftButton("Remove", Modifier.weight(1f)) { Manager.remove(cur) }
                        }
                        DStatus.QUEUED -> {
                            PrimaryButton("Start", Modifier.weight(1f)) { Manager.start(cur) }
                            SoftButton("Cancel", Modifier.weight(1f)) { Manager.cancel(cur) }
                        }
                        else -> SoftButton("Cancel", Modifier.fillMaxWidth()) { Manager.cancel(cur) }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            if (Manager.items.size > 1) {
                T("Queue", 12f, p.sub, modifier = Modifier.padding(start = 4.dp))
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(Manager.items.toList()) { it2 ->
                        Row(Modifier.fillMaxWidth().glass(16.dp).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                T(it2.title, 13f, maxLines = 1)
                                T(it2.status.name.lowercase().replaceFirstChar { c -> c.uppercase() } + (if (it2.isActive()) "  " + it2.progress.toInt() + "%" else ""), 12f, p.sub)
                            }
                            if (it2.isFinished()) SoftButton("Clear") { Manager.remove(it2) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NavBar(tab: Int, onTab: (Int) -> Unit) {
    val p = LocalPal.current
    val labels = Prefs.bool("tab_labels")
    Row(
        Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp).glass(30.dp).padding(6.dp)
    ) {
        val names = listOf("YouTube", "Instagram", "Web", "Settings")
        names.forEachIndexed { i, n ->
            val on = tab == i
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
                    .background(if (on) (if (p.dark) Color.White.copy(alpha = 0.2f) else Color.White) else Color.Transparent)
                    .tap { onTab(i) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val a = if (on) 1f else 0.55f
                when (i) {
                    0 -> PlatformIcon("youtube", 24.dp, a)
                    1 -> PlatformIcon("instagram", 24.dp, a)
                    2 -> PlatformIcon("web", 24.dp, a)
                    else -> Image(Icons.Default.Settings, null, Modifier.size(24.dp), colorFilter = ColorFilter.tint(if (on) p.accent else p.sub))
                }
                if (labels) T(n, 10f, if (on) p.accent else p.sub, if (on) FontWeight.Medium else FontWeight.Normal)
            }
        }
    }
}

@Composable
fun MainScreen() {
    var tab by remember { mutableIntStateOf(listOf("YouTube", "Instagram", "Web", "Settings").indexOf(Prefs.str("start_tab")).coerceAtLeast(0)) }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val shared = Shared.link.value
    LaunchedEffect(Unit) { Updater.autoCheck(ctx, scope) }
    LaunchedEffect(shared) {
        if (shared != null) {
            when (Util.detect(shared)) {
                "youtube" -> { tab = 0; YtState.url = shared; ytFetch(ctx, scope) }
                "instagram" -> { tab = 1; IgState.input = shared; IgState.mode = 0; igFetch(ctx, scope) }
                else -> { tab = 2; WebState.url = shared; webScan(ctx, scope) }
            }
            Shared.link.value = null
        }
    }
    AppBackground(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    0 -> YouTubeScreen()
                    1 -> InstagramScreen()
                    2 -> WebScreen()
                    else -> SettingsScreen()
                }
            }
            MiniBar()
            NavBar(tab) { tab = it }
        }
        if (Manager.overlay) ExportOverlay()
        UpdateOverlay()
    }
}
