package com.ayush.fetchly

import com.yausername.youtubedl_android.YoutubeDLRequest

/** Extra download options that are controlled from Settings (filters, playlist, advanced, audio processing). */
object Adv {
    fun thumbFmt(): String = Prefs.str("adv_thumb_format").ifEmpty { "jpg" }

    private fun off(v: String) = v.isEmpty() || v == "None" || v == "Any" || v == "Default" || v == "Off"

    private fun secs(label: String): Int? = when (label) {
        "30 sec" -> 30
        "1 min" -> 60
        "5 min" -> 300
        "10 min" -> 600
        "30 min" -> 1800
        "1 hour" -> 3600
        "3 hours" -> 10800
        else -> null
    }

    private fun flag(r: YoutubeDLRequest, key: String, opt: String) {
        if (Prefs.bool(key)) r.addOption(opt)
    }

    private fun choice(r: YoutubeDLRequest, key: String, opt: String) {
        val v = Prefs.str(key)
        if (!off(v)) r.addOption(opt, v)
    }

    private fun text(r: YoutubeDLRequest, key: String, opt: String) {
        val v = Prefs.str(key).trim()
        if (v.isNotEmpty()) r.addOption(opt, v)
    }

    fun apply(r: YoutubeDLRequest, o: DlOptions, lite: Boolean) {
        // playlist
        flag(r, "pl_reverse", "--playlist-reverse")
        flag(r, "pl_random", "--playlist-random")
        flag(r, "pl_lazy", "--lazy-playlist")
        flag(r, "pl_ignore_errors", "--ignore-errors")
        flag(r, "pl_break_existing", "--break-on-existing")
        choice(r, "pl_max_downloads", "--max-downloads")
        // filters
        choice(r, "f_min_size", "--min-filesize")
        text(r, "f_date_after", "--dateafter")
        text(r, "f_date_before", "--datebefore")
        choice(r, "f_age_limit", "--age-limit")
        val f = ArrayList<String>()
        if (Prefs.bool("f_skip_live")) f.add("!is_live")
        secs(Prefs.str("f_min_duration"))?.let { f.add("duration >=? $it") }
        secs(Prefs.str("f_max_duration"))?.let { f.add("duration <=? $it") }
        val mv = Prefs.str("f_min_views")
        if (!off(mv)) f.add("view_count >=? $mv")
        val cm = Prefs.str("f_match_custom").trim()
        if (cm.isNotEmpty()) f.add(cm)
        if (f.isNotEmpty()) r.addOption("--match-filter", f.joinToString(" & "))
        // advanced
        flag(r, "adv_no_part", "--no-part")
        flag(r, "adv_no_continue", "--no-continue")
        flag(r, "adv_keep_fragments", "--keep-fragments")
        flag(r, "adv_keep_files", "-k")
        flag(r, "adv_check_formats", "--check-formats")
        flag(r, "adv_prefer_free", "--prefer-free-formats")
        flag(r, "adv_hls_ts", "--hls-use-mpegts")
        flag(r, "adv_write_comments", "--write-comments")
        flag(r, "adv_write_all_thumbs", "--write-all-thumbnails")
        flag(r, "adv_live_start", "--live-from-start")
        flag(r, "adv_ipv6", "-6")
        flag(r, "adv_legacy_ssl", "--legacy-server-connect")
        flag(r, "adv_prefer_insecure", "--prefer-insecure")
        flag(r, "adv_no_post_overwrites", "--no-post-overwrites")
        val fix = Prefs.str("adv_fixup")
        if (!off(fix)) r.addOption("--fixup", fix.lowercase())
        choice(r, "adv_retry_sleep", "--retry-sleep")
        choice(r, "adv_sleep_requests", "--sleep-requests")
        choice(r, "adv_file_retries", "--file-access-retries")
        choice(r, "adv_wait_video", "--wait-for-video")
        text(r, "adv_add_header", "--add-header")
        text(r, "adv_referer", "--referer")
        text(r, "adv_extractor_args", "--extractor-args")
        if (!lite) {
            val cs = Prefs.str("adv_convert_subs")
            if (!off(cs)) r.addOption("--convert-subs", cs)
        }
        for (o in ADV_TABLE) {
            val v = Prefs.str(o.def.key)
            when (o.def.type) {
                SType.TOGGLE -> if (v == "true") { if (o.fixed != null) r.addOption(o.flag, o.fixed) else r.addOption(o.flag) }
                SType.CHOICE -> if (!off(v)) r.addOption(o.flag, o.prefix + v)
                SType.TEXT -> if (v.trim().isNotEmpty()) r.addOption(o.flag, o.prefix + v.trim())
            }
        }
        // instagram
        if (o.site == "instagram") choice(r, "ig_sleep", "--sleep-requests")
    }

    /** Options that must come last so they win over the automatic ones. */
    fun late(r: YoutubeDLRequest, o: DlOptions) {
        text(r, "adv_format", "-f")
        text(r, "adv_sort", "-S")
        if (o.audioOnly) {
            val parts = ArrayList<String>()
            if (Prefs.bool("a_loudnorm")) parts.add("-af loudnorm=I=-16:TP=-1.5:LRA=11")
            val sr = Prefs.str("a_samplerate")
            if (!off(sr)) parts.add("-ar $sr")
            when (Prefs.str("a_channels")) {
                "Mono" -> parts.add("-ac 1")
                "Stereo" -> parts.add("-ac 2")
            }
            if (parts.isNotEmpty()) r.addOption("--postprocessor-args", "ExtractAudio:" + parts.joinToString(" "))
        }
        val extra = Prefs.str("adv_args").trim()
        if (extra.isNotEmpty()) {
            val toks = Regex("\"([^\"]*)\"|(\\S+)").findAll(extra).map { it.groupValues[1].ifEmpty { it.groupValues[2] } }.toList()
            var i = 0
            while (i < toks.size) {
                val t = toks[i]
                if (t.startsWith("-") && i + 1 < toks.size && !toks[i + 1].startsWith("-")) {
                    r.addOption(t, toks[i + 1])
                    i += 2
                } else {
                    r.addOption(t)
                    i += 1
                }
            }
        }
    }
}
