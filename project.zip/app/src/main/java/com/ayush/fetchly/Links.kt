package com.ayush.fetchly

/**
 * Edit this file to add your links. A row only shows in Settings when its link is not empty,
 * so you can leave them blank now and fill them in a later update.
 */
object Links {
    val YOUTUBE: String = ""   // example: "https://youtube.com/@yourchannel"
    val TELEGRAM: String = ""  // example: "https://t.me/yourchannel"
    val APP_LINK: String = ""  // link people get when they tap "Share Fetchly"

    const val UPI_ID = "ayushku92sk@okicici"
    const val UPI_NAME = "Ayush"
}
