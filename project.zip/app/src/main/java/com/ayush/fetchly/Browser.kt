package com.ayush.fetchly

import android.annotation.SuppressLint
import android.net.Uri
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * In-app browser: open any site, log in, solve the captcha, press play.
 * Fetchly watches the page's network and offers every stream it sees (not DRM) for download,
 * using the same cookies, referer and user-agent as this browser.
 */
object BrowserState {
    var open by mutableStateOf(false)
    var startUrl by mutableStateOf("")
    var message by mutableStateOf("")
    val hits = mutableStateListOf<String>()
    var pageUrl by mutableStateOf("")
    var pageTitle by mutableStateOf("")
    var ua = Http.UA_DESKTOP

    fun launch(url: String) {
        hits.clear()
        message = ""
        pageUrl = ""
        pageTitle = ""
        startUrl = if (url.isBlank()) "https://www.google.com" else if (url.startsWith("http")) url else "https://$url"
        open = true
    }

    fun close() {
        open = false
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserOverlay() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = LocalPal.current
    var address by remember { mutableStateOf(BrowserState.startUrl) }
    var web by remember { mutableStateOf<WebView?>(null) }
    BackHandler {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else BrowserState.close()
    }
    Column(Modifier.fillMaxSize().background(p.bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            SoftButton("Close", Modifier) { BrowserState.close() }
            Spacer(Modifier.width(8.dp))
            Field(address, { address = it }, "Search or paste link", Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            PrimaryButton("Go", Modifier) {
                val a = address.trim()
                val u = if (a.startsWith("http")) a else if (a.contains(".") && !a.contains(" ")) "https://$a" else "https://www.google.com/search?q=" + Uri.encode(a)
                web?.loadUrl(u)
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    WebView(c).apply {
                        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.javaScriptCanOpenWindowsAutomatically = true
                        settings.setSupportMultipleWindows(false)
                        settings.userAgentString = BrowserState.ua
                        try {
                            CookieManager.getInstance().setAcceptCookie(true)
                            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        } catch (_: Throwable) {}
                        webViewClient = object : WebViewClient() {
                            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                                val u = request?.url?.toString() ?: return null
                                if (Sniffer.isMedia(u)) {
                                    view?.post { if (!BrowserState.hits.contains(u)) BrowserState.hits.add(u) }
                                }
                                return null
                            }

                            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                                if (url != null) {
                                    BrowserState.pageUrl = url
                                    address = url
                                }
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                BrowserState.pageTitle = view?.title ?: ""
                                if (url != null) BrowserState.pageUrl = url
                            }
                        }
                        loadUrl(BrowserState.startUrl)
                        web = this
                    }
                },
                onRelease = { w -> try { w.stopLoading(); w.destroy() } catch (_: Throwable) {} ; web = null }
            )
        }
        Column(Modifier.fillMaxWidth().padding(12.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (BrowserState.message.isNotEmpty()) T(BrowserState.message, 13f, p.sub)
            val n = BrowserState.hits.size
            T(
                if (n == 0) "Play the video. Fetchly will catch it here." else "$n video stream(s) found on this page",
                13f, p.sub
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton("Download video", Modifier.weight(1f), n > 0) {
                    val w = web
                    val page = BrowserState.pageUrl
                    val title = BrowserState.pageTitle
                    val chosen = Sniffer.best(BrowserState.hits.toList())
                    if (chosen != null) {
                        val cookie = try { CookieManager.getInstance().getCookie(page) ?: "" } catch (_: Throwable) { "" }
                        val ua = w?.settings?.userAgentString ?: BrowserState.ua
                        val hit = Sniffer.Hit(chosen, page, ua, cookie, title)
                        BrowserState.message = "Reading video..."
                        scope.launch {
                            try {
                                val info = withContext(Dispatchers.IO) { Engine.fetchFromHit(ctx, hit) }
                                Manager.enqueueYt(ctx, info, DlOptions("web", false, null, Prefs.str("video_container"), Prefs.str("audio_format"), Prefs.str("audio_quality")))
                                BrowserState.message = "Added to downloads."
                            } catch (t: Throwable) {
                                BrowserState.message = Engine.friendly(t.message ?: t.toString())
                            }
                        }
                    }
                }
                SoftButton("Clear", Modifier.weight(1f)) { BrowserState.hits.clear(); BrowserState.message = "" }
            }
        }
    }
}
