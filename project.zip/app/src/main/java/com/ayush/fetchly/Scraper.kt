package com.ayush.fetchly

import android.content.Context
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Http {
    const val UA_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    const val UA_ANDROID = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    const val UA_IPHONE = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"

    fun ua(key: String): String = when (key) {
        "Chrome Android" -> UA_ANDROID
        "Safari iPhone" -> UA_IPHONE
        else -> UA_DESKTOP
    }

    fun open(url: String, ua: String, referer: String?, cookie: String? = null, extra: Map<String, String> = emptyMap(), method: String = "GET", timeout: Int = 20000): HttpURLConnection {
        var u = url
        var hops = 0
        while (true) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = timeout
            c.readTimeout = timeout
            c.requestMethod = method
            c.setRequestProperty("User-Agent", ua)
            c.setRequestProperty("Accept", "*/*")
            if (!referer.isNullOrEmpty()) c.setRequestProperty("Referer", referer)
            if (!cookie.isNullOrEmpty()) c.setRequestProperty("Cookie", cookie)
            for ((k, v) in extra) c.setRequestProperty(k, v)
            val code = c.responseCode
            if (code in 300..399 && hops < 6) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc.isNullOrEmpty()) return c
                u = URL(URL(u), loc).toString()
                hops++
                continue
            }
            return c
        }
    }

    fun text(url: String, ua: String, referer: String?, cookie: String? = null, extra: Map<String, String> = emptyMap(), maxBytes: Int = 4_000_000): String {
        val c = open(url, ua, referer, cookie, extra)
        val stream = if (c.responseCode >= 400) (c.errorStream ?: throw Exception("HTTP " + c.responseCode)) else c.inputStream
        val out = java.io.ByteArrayOutputStream()
        stream.use { s ->
            val buf = ByteArray(16384)
            while (out.size() < maxBytes) {
                val n = s.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
            }
        }
        if (c.responseCode >= 400) throw Exception("HTTP " + c.responseCode)
        return out.toString("UTF-8")
    }
}

class WebMedia(val url: String, val type: String)

object Scraper {
    private val IMG = listOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "avif")
    private val VID = listOf("mp4", "webm", "mov", "mkv", "m4v")
    private val AUD = listOf("mp3", "m4a", "aac", "ogg", "opus", "wav", "flac")

    private fun extOf(u: String): String {
        val p = u.substringBefore('?').substringBefore('#')
        val d = p.substringAfterLast('.', "")
        return if (d.length in 2..5) d.lowercase() else ""
    }

    private fun typeOf(u: String, fallback: String?): String? {
        val e = extOf(u)
        return when {
            e in IMG -> "image"
            e in VID -> "video"
            e in AUD -> "audio"
            else -> fallback
        }
    }

    private fun attr(tag: String, name: String): String? {
        val m = Regex("\\b" + name + "\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))", RegexOption.IGNORE_CASE).find(tag) ?: return null
        return m.groups[1]?.value ?: m.groups[2]?.value ?: m.groups[3]?.value
    }

    private fun resolve(base: String, ref: String): String? {
        val r = ref.trim().replace("&amp;", "&")
        if (r.isEmpty() || r.startsWith("data:") || r.startsWith("javascript:") || r.startsWith("#") || r.startsWith("blob:")) return null
        return try { URL(URL(base), r).toString() } catch (_: Throwable) { null }
    }

    private fun bestFromSrcset(set: String): String? {
        var best: String? = null
        var bw = -1.0
        for (part in set.split(",")) {
            val bits = part.trim().split(Regex("\\s+"))
            if (bits.isEmpty() || bits[0].isEmpty()) continue
            var w = 1.0
            if (bits.size > 1) {
                val d = bits[1]
                w = d.dropLast(1).toDoubleOrNull() ?: 1.0
            }
            if (w >= bw) { bw = w; best = bits[0] }
        }
        return best
    }

    fun scan(pageUrl: String): List<WebMedia> {
        val ua = Http.ua(Prefs.str("web_ua"))
        val ref = if (Prefs.bool("web_referer")) pageUrl else null
        val html = Http.text(pageUrl, ua, ref)
        val found = LinkedHashMap<String, String>()
        fun add(raw: String?, fallback: String?) {
            if (raw == null) return
            val u = resolve(pageUrl, raw) ?: return
            val t = typeOf(u, fallback) ?: return
            if (u.contains(".m3u8") || u.contains(".mpd")) return
            if (!found.containsKey(u)) found[u] = t
        }
        val wImg = Prefs.bool("web_images")
        val wVid = Prefs.bool("web_videos")
        val wAud = Prefs.bool("web_audio")

        for (m in Regex("<(img|source|video|audio|embed)\\b[^>]*>", RegexOption.IGNORE_CASE).findAll(html)) {
            val tag = m.value
            val name = m.groupValues[1].lowercase()
            val fb = when (name) { "img" -> "image"; "video" -> "video"; "audio" -> "audio"; else -> null }
            if (Prefs.bool("web_srcset")) {
                val ss = attr(tag, "srcset") ?: attr(tag, "data-srcset")
                if (ss != null) bestFromSrcset(ss)?.let { add(it, "image") }
            }
            for (a in listOf("src", "data-src", "data-lazy-src", "data-original", "poster")) {
                add(attr(tag, a), if (a == "poster") "image" else fb)
            }
        }
        for (m in Regex("<a\\b[^>]*>", RegexOption.IGNORE_CASE).findAll(html)) {
            val h = attr(m.value, "href")
            if (h != null && typeOf(h, null) != null) add(h, null)
        }
        if (Prefs.bool("web_og")) {
            for (m in Regex("<meta\\b[^>]*>", RegexOption.IGNORE_CASE).findAll(html)) {
                val tag = m.value
                val key = (attr(tag, "property") ?: attr(tag, "name") ?: "").lowercase()
                val content = attr(tag, "content")
                when (key) {
                    "og:image", "og:image:url", "og:image:secure_url", "twitter:image" -> add(content, "image")
                    "og:video", "og:video:url", "og:video:secure_url" -> add(content, "video")
                    "og:audio" -> add(content, "audio")
                }
            }
        }
        val un = html.replace("\\/", "/")
        for (m in Regex("https?://[^\"'\\s<>\\\\]+?\\.(?:mp4|webm|jpg|jpeg|png|webp|mp3|m4a)(?:\\?[^\"'\\s<>\\\\]*)?").findAll(un)) {
            add(m.value, null)
        }
        return found.entries
            .filter { (it.value == "image" && wImg) || (it.value == "video" && wVid) || (it.value == "audio" && wAud) }
            .map { WebMedia(it.key, it.value) }
    }

    private fun minBytes(): Long = when (Prefs.str("web_min_size")) {
        "100 KB" -> 100_000L
        "300 KB" -> 300_000L
        "1 MB" -> 1_000_000L
        else -> 0L
    }

    suspend fun filterBySize(list: List<WebMedia>): List<WebMedia> {
        val min = minBytes()
        if (min <= 0L) return list
        val ua = Http.ua(Prefs.str("web_ua"))
        return coroutineScope {
            list.chunked(8).flatMap { chunk ->
                chunk.map { w ->
                    async {
                        if (w.type != "image") return@async w
                        try {
                            val c = Http.open(w.url, ua, null, null, emptyMap(), "HEAD", 5000)
                            val len = c.contentLengthLong
                            c.disconnect()
                            if (len in 1 until min) null else w
                        } catch (_: Throwable) { w }
                    }
                }.awaitAll().filterNotNull()
            }
        }
    }

    fun instagramDp(ctx: Context, username: String): String? {
        val user = username.trim().removePrefix("@").trim('/')
        if (user.isEmpty()) return null
        val cookie = Cookies.header(ctx, "instagram.com")
        val headers = mapOf("X-IG-App-ID" to "936619743392459", "Accept" to "application/json")
        val api = "https://i.instagram.com/api/v1/users/web_profile_info/?username=$user"
        try {
            val body = Http.text(api, "Instagram 275.0.0.27.98 Android (33/13; 420dpi; 1080x2400; Google; Pixel 7; panther; tensor; en_US; 458229237)", null, cookie, headers)
            val u = JSONObject(body).getJSONObject("data").getJSONObject("user")
            val hd = if (u.isNull("profile_pic_url_hd")) "" else u.optString("profile_pic_url_hd", "")
            val sd = if (u.isNull("profile_pic_url")) "" else u.optString("profile_pic_url", "")
            if (Prefs.bool("ig_dp_hd") && hd.isNotEmpty()) return hd
            if (sd.isNotEmpty()) return sd
            if (hd.isNotEmpty()) return hd
        } catch (_: Throwable) {}
        // fallback: public page preview image
        return try {
            val html = Http.text("https://www.instagram.com/$user/", Http.UA_DESKTOP, null, cookie)
            val m = Regex("property=\"og:image\"\\s+content=\"([^\"]+)\"").find(html)
            m?.groupValues?.get(1)?.replace("&amp;", "&")
        } catch (_: Throwable) { null }
    }
}
