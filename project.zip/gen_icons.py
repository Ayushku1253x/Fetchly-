import os
R='app/src/main/res'
pal=[['#111216','#ff9a5c','#ff4d7a','#6b5bff','#ffffff'],['#0a0b10','#ffb347','#ff4d6d','#5b6cff','#ffffff'],['#f5f5f7','#ffb347','#ff6b8b','#6b7bff','#1c1c22'],['#0d1b2a','#4cc9f0','#4361ee','#7209b7','#ffffff'],['#10221a','#b6f26b','#2dd4a0','#0ea5e9','#ffffff'],['#1a1024','#f9a8d4','#c084fc','#6366f1','#ffffff'],['#fff4e6','#ffd166','#ff8a5c','#ef476f','#3a2310'],['#0b132b','#5eead4','#38bdf8','#818cf8','#ffffff'],['#1f1a14','#f6d365','#fda085','#f093fb','#ffffff'],['#e8f0ff','#7aa2ff','#9b7bff','#ff8ad4','#1c2230'],['#14110f','#ff6b6b','#ffa94d','#ffe066','#ffffff'],['#0f172a','#22d3ee','#6366f1','#ec4899','#ffffff'],['#eafaf1','#34d399','#10b981','#3b82f6','#0b2e22'],['#2b1055','#ff7eb3','#ff758c','#ffb199','#ffffff'],['#021b1a','#00f5a0','#00d9f5','#7c3aed','#ffffff'],['#fef2f2','#fb7185','#f43f5e','#a855f7','#3b0a14'],['#1c1c1e','#ffffff','#d1d5db','#9ca3af','#1c1c1e'],['#111827','#fbbf24','#f59e0b','#ef4444','#ffffff'],['#f0f9ff','#38bdf8','#0ea5e9','#6366f1','#ffffff'],['#1a1a2e','#e94560','#7b2cbf','#3a86ff','#ffffff']]
P=['M48,17C65,15 79,30 77,48C75,67 60,80 44,76C27,72 17,57 21,41C24,27 36,19 48,17Z',
   'M50,15C68,20 78,34 75,52C72,69 58,78 42,75C26,71 19,54 23,38C27,24 38,12 50,15Z',
   'M48,16C66,18 78,33 76,50C74,68 58,79 42,75C26,71 18,57 22,41C25,27 34,14 48,16Z']
colors=['<?xml version="1.0" encoding="utf-8"?>','<resources>','    <color name="bg_splash">#F5F7FC</color>']
for i,c in enumerate(pal):
    n=i+1
    colors.append('    <color name="ic_bg_%d">%s</color>'%(n,c[0]))
    fg=f'''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:aapt="http://schemas.android.com/aapt"
    android:width="108dp" android:height="108dp"
    android:viewportWidth="108" android:viewportHeight="108">
    <group android:scaleX="0.8" android:scaleY="0.8" android:pivotX="48" android:pivotY="48" android:translateX="6" android:translateY="6">
        <path android:pathData="{P[i%3]}">
            <aapt:attr name="android:fillColor">
                <gradient android:startX="21" android:startY="17" android:endX="77" android:endY="78" android:type="linear">
                    <item android:offset="0" android:color="{c[1]}"/>
                    <item android:offset="0.55" android:color="{c[2]}"/>
                    <item android:offset="1" android:color="{c[3]}"/>
                </gradient>
            </aapt:attr>
        </path>
        <path android:pathData="M32,34C37,26 48,24 56,27C48,28 38,32 34,40C32,40 31,37 32,34Z" android:fillColor="#FFFFFF" android:fillAlpha="0.4"/>
        <path android:pathData="M48,36L48,59M39,51L48,60L57,51" android:strokeColor="{c[4]}" android:strokeWidth="5" android:strokeLineCap="round" android:strokeLineJoin="round"/>
    </group>
</vector>
'''
    open(f'{R}/drawable/ic_blob_fg_{n}.xml','w').write(fg)
    ad=f'''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_bg_{n}"/>
    <foreground android:drawable="@drawable/ic_blob_fg_{n}"/>
</adaptive-icon>
'''
    open(f'{R}/mipmap-anydpi-v26/ic_blob_{n}.xml','w').write(ad)
colors.append('</resources>')
open(f'{R}/values/colors.xml','w').write('\n'.join(colors)+'\n')
open(f'{R}/values/strings.xml','w').write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="app_name">Fetchly</string>\n</resources>\n')
open(f'{R}/values/themes.xml','w').write('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.Fetchly" parent="android:Theme.Material.Light.NoActionBar">
        <item name="android:windowBackground">@color/bg_splash</item>
        <item name="android:statusBarColor">@android:color/transparent</item>
        <item name="android:navigationBarColor">@android:color/transparent</item>
    </style>
</resources>
''')
open(f'{R}/xml/file_paths.xml','w').write('<?xml version="1.0" encoding="utf-8"?>\n<paths>\n    <external-path name="ext" path="." />\n    <cache-path name="cache" path="." />\n</paths>\n')
open(f'{R}/drawable/ic_stat.xml','w').write('''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">
    <path android:pathData="M12,4L12,15M7,11L12,16L17,11M6,19L18,19" android:strokeColor="#FFFFFF" android:strokeWidth="2.2" android:strokeLineCap="round" android:strokeLineJoin="round"/>
</vector>
''')
aliases=''
for i in range(1,21):
    aliases+=f'''        <activity-alias
            android:name=".Alias{i}"
            android:targetActivity=".MainActivity"
            android:enabled="{'true' if i==1 else 'false'}"
            android:exported="true"
            android:icon="@mipmap/ic_blob_{i}"
            android:label="@string/app_name">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity-alias>
'''
manifest=f'''<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />

    <application
        android:name=".FetchlyApp"
        android:label="@string/app_name"
        android:icon="@mipmap/ic_blob_1"
        android:allowBackup="false"
        android:extractNativeLibs="true"
        android:usesCleartextTraffic="true"
        android:largeHeap="true"
        android:supportsRtl="true"
        android:theme="@style/Theme.Fetchly">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTask"
            android:windowSoftInputMode="adjustResize"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden|smallestScreenSize|uiMode|density|fontScale">
            <intent-filter>
                <action android:name="android.intent.action.SEND" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="text/plain" />
            </intent-filter>
        </activity>

{aliases}
        <service
            android:name=".DownloadService"
            android:exported="false"
            android:foregroundServiceType="dataSync" />

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="${{applicationId}}.provider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>
    </application>
</manifest>
'''
open('app/src/main/AndroidManifest.xml','w').write(manifest)
def h(x): return '0xFF'+x[1:].upper()
rows=',\n'.join('    IconColors(%s, %s, %s, %s, %s)'%tuple(h(x) for x in c) for c in pal)
open('app/src/main/java/com/ayush/fetchly/IconData.kt','w').write('''package com.ayush.fetchly

import androidx.compose.ui.graphics.Color

class IconColors(bg: Long, c1: Long, c2: Long, c3: Long, arrow: Long) {
    val bg = Color(bg)
    val c1 = Color(c1)
    val c2 = Color(c2)
    val c3 = Color(c3)
    val arrow = Color(arrow)
}

val ICON_PAL: List<IconColors> = listOf(
'''+rows+'''
)
''')
open('app/src/main/assets/fonts/README.txt','w').write('Fonts (Borel, Kalam) are downloaded by the GitHub workflow. If missing, the app uses the system font.\n')
print('generated')
