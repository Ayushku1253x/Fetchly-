# Fetchly - features

Counted from the code: **170 settings**, **about 470 selectable options**, 20 app icons, 60 hello languages, plus the features below.

## YouTube
- Paste or share a link, fetch title, thumbnail, uploader, duration, playlist count
- Quality: Best, 8K, 4K, 1440p, 1080p, 720p, 480p, 360p, 240p, 144p (whatever the video offers)
- Formats: MP4, MKV, WEBM, Original
- Audio: MP3, M4A, OPUS, FLAC, WAV, AAC, OGG, Original with 7 quality levels
- Thumbnail embedded as cover art in audio and video
- Trim (start and end time), accurate or fast
- Subtitles (language list, format, embed), SponsorBlock remove or mark, chapters embed or split
- Copy title, description, tags, link; save thumbnails in every size; open on YouTube

## Instagram
- Post, reel, story (all stories of a user), profile photo (largest available)
- Original quality, no re-encoding; save reel as audio; save caption
- Login inside the app (Settings) for stories and harder links

## Websites
- Scan any page for images, videos and audio (img, srcset, social preview, links)
- Select all/none/individual, minimum image size filter, download in original quality
- "Try as video" for pages with embedded video (no DRM)

## Share and auto-save
- Share a link from any app to Fetchly: it saves in the background in the best format, no taps, and you stay in the app you shared from
- YouTube, YouTube Music (as audio), Instagram (post, reel, story, profile photo) and any website
- Settings: video or audio, quality, whole playlist, website file limit, duplicate-link guard, open app after

## Downloads and engine
- Queue with parallel downloads, retries, speed limit, parallel connections, Turbo mode (64 connections, no limits)
- In-app update: checks GitHub for a new build, downloads and installs it
- Auto-repair: failed downloads retry with other methods and update the engine
- Engine (yt-dlp) auto-update on start and on demand
- Export screen with squircle progress, percent, ETA, speed graph; mini-bar
- Foreground service and notifications (progress, finished, failed)
- Saves to Movies / Music / Pictures (or Downloads/Fetchly, or a folder you pick), sub-folder per platform
- History with open, share, remove; incognito; clear cache and history

## Look and feel
- Minimal Apple-style liquid glass, light and dark, 8 accent colours, 4 glass thicknesses, 3 corner styles
- Hello intro in 60 languages (Hindi first), animated logo welcome page
- 20 app icons + your own photo and name on the home screen
- Step-by-step guide with pointing finger

Made by Ayush Kumar, designed by Claude. Made in India.

## Latest additions
- 54 more yt-dlp options (Network, Files and names, Selection, Convert and edit, YouTube, Access) -> total about 230 settings
- Support screen (UPI ayushku92sk@okicici, QR, Pay with UPI, Copy ID)
- YouTube / Telegram join rows: hidden until you fill Links.kt
- Compatibility mode (H.264, gallery thumbnail fix) and iPad/iPhone mode, MOV and ALAC formats
- Real app icon change (20 icons) plus app name change (10 names)

## Any-website fallback and auto-update
- If yt-dlp has no extractor for a site, Fetchly opens the page in a hidden browser, finds the real stream (.m3u8 / .mpd / .mp4) and downloads it with the same referer, user-agent and cookies. DRM videos are never attempted.
- Engine (yt-dlp) updates itself every 12 hours, before downloads, and when a download needs repair. Default channel is Nightly.
- In-app browser (Websites tab, "Open in browser"): log in, solve captchas, press play. Fetchly catches the stream and downloads it with the browser's cookies. DRM is never attempted.
